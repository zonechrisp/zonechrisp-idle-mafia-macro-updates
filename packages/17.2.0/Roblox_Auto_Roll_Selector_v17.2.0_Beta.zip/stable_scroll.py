"""A stationary, clipped viewport for CustomTkinter pages on Windows.

Tk Canvas scrolling copies existing pixels before its embedded native controls
finish repainting. Large pages of CTk controls can consequently leave trails.
This frame retains CTk's styling and scrollbar but moves its native content
frame with ``place`` inside a stationary canvas, using normal parent clipping.
"""

import sys
import tkinter as tk

import customtkinter as ctk


class StableScrollableFrame(ctk.CTkScrollableFrame):
    """Vertical CTk page with coalesced scrolling and no Canvas pixel scrolling."""

    FRAME_DELAY_MS = 16

    def __init__(self, master, *, on_scroll=None, **kwargs):
        if kwargs.get("orientation", "vertical") != "vertical":
            raise ValueError("StableScrollableFrame supports vertical pages only")
        self._scroll_callback = on_scroll
        self._scroll_job = None
        self._layout_job = None
        self._scroll_offset = 0
        self._target_offset = 0.0
        self._viewport_height = 1
        self._content_height = 1
        self._placed_geometry = None
        self._last_content_size = None
        self._stable_ready = False
        self._stable_destroyed = False
        super().__init__(master, **kwargs)

        # Keep the canvas itself fixed. A normal child window is clipped by
        # this viewport without invoking Tk Canvas's pixel-copy scroll path.
        self._parent_canvas.delete(self._create_window_id)
        self._parent_canvas.configure(yscrollcommand="", scrollregion="")
        tk.Frame.place(self, x=0, y=0, width=1)
        self._parent_canvas.yview = self._logical_yview
        self._parent_canvas.yview_scroll = self._logical_yview_scroll
        self._parent_canvas.yview_moveto = self._logical_yview_moveto
        self._scrollbar.configure(command=self._logical_yview)

        # Replace the inherited bbox/scrollregion binding. Natural requested
        # height remains controlled by packed/gridded children; width follows
        # the viewport. Position-only Configure events need no new layout.
        self.bind("<Configure>", self._content_configured)
        self.bind("<Map>", self._content_mapped, add="+")
        self.bind("<Unmap>", self._content_unmapped, add="+")
        self._stable_ready = True
        self._schedule_layout()

    def _fit_frame_dimensions_to_canvas(self, _event=None):
        if self._stable_ready:
            self._schedule_layout()

    def _content_configured(self, event):
        size = (event.width, event.height)
        if size != self._last_content_size:
            self._last_content_size = size
            self._schedule_layout()

    def _content_mapped(self, _event=None):
        self._schedule_layout()

    def _content_unmapped(self, _event=None):
        self._cancel_pending_scroll()

    def _schedule_layout(self):
        if self._stable_ready and not self._stable_destroyed and self._layout_job is None:
            self._layout_job = self.after_idle(self._layout_viewport)

    def _layout_viewport(self):
        self._layout_job = None
        if self._stable_destroyed:
            return
        width = max(1, self._parent_canvas.winfo_width())
        self._viewport_height = max(1, self._parent_canvas.winfo_height())
        self._content_height = max(1, self.winfo_reqheight())
        maximum = self._maximum_offset()
        self._target_offset = min(maximum, max(0.0, self._target_offset))
        self._scroll_offset = min(maximum, max(0, self._scroll_offset))
        self._place_content(width)
        self._update_scrollbar()

    def _maximum_offset(self):
        return max(0, self._content_height - self._viewport_height)

    def _place_content(self, width=None):
        if width is None:
            width = max(1, self._parent_canvas.winfo_width())
        geometry = (width, -self._scroll_offset)
        if geometry != self._placed_geometry:
            # Calling tkinter.Frame explicitly avoids CTkScrollableFrame's
            # place override, which positions the outer styled frame.
            tk.Frame.place_configure(self, x=0, y=geometry[1], width=width)
            self._placed_geometry = geometry

    def _update_scrollbar(self):
        self._scrollbar.set(*self._logical_yview())

    def _logical_yview(self, *args):
        if not args:
            if self._content_height <= self._viewport_height:
                return (0.0, 1.0)
            return (
                self._scroll_offset / self._content_height,
                min(1.0, (self._scroll_offset + self._viewport_height) / self._content_height),
            )
        if args[0] == "moveto" and len(args) == 2:
            self._queue_offset(float(args[1]) * self._content_height)
        elif args[0] == "scroll" and len(args) == 3:
            self._logical_yview_scroll(float(args[1]), args[2])
        else:
            raise tk.TclError('expected "moveto fraction" or "scroll number units|pages"')

    def _logical_yview_moveto(self, fraction):
        self._logical_yview("moveto", fraction)

    def _logical_yview_scroll(self, number, what):
        if what == "units":
            # Explicit one-pixel logical units, independent of any legacy
            # code changing the unused native canvas scroll increment.
            distance = float(number)
        elif what == "pages":
            distance = float(number) * max(1, self._viewport_height * 0.9)
        else:
            raise tk.TclError('bad argument: must be "units" or "pages"')
        self._queue_offset(self._target_offset + distance)

    def _queue_offset(self, offset):
        if self._stable_destroyed:
            return
        target = min(float(self._maximum_offset()), max(0.0, float(offset)))
        if target == self._target_offset:
            return
        self._target_offset = target
        if self._scroll_callback is not None:
            self._scroll_callback()
        if self._scroll_job is None:
            self._scroll_job = self.after(self.FRAME_DELAY_MS, self._flush_scroll)

    def _flush_scroll(self):
        self._scroll_job = None
        if self._stable_destroyed:
            return
        self._scroll_offset = min(self._maximum_offset(), max(0, round(self._target_offset)))
        self._place_content()
        self._update_scrollbar()

    def _mouse_wheel_all(self, event):
        if not self._stable_ready or self._stable_destroyed:
            return
        try:
            if not self.winfo_ismapped() or not self._check_if_valid_scroll(event.widget):
                return
        except (AttributeError, tk.TclError):
            return
        if self._shift_pressed:
            return
        if sys.platform.startswith("win"):
            distance = -float(event.delta) / 6.0
        elif sys.platform == "darwin":
            distance = -float(event.delta) * 8.0
        else:
            distance = -30.0 if getattr(event, "num", None) == 4 else 30.0
        self._logical_yview_scroll(distance, "units")

    def _cancel_pending_scroll(self):
        if self._scroll_job is not None:
            try:
                self.after_cancel(self._scroll_job)
            except tk.TclError:
                pass
            self._scroll_job = None
        # A hidden page keeps the position actually visible before hiding.
        self._target_offset = float(self._scroll_offset)

    def grid_remove(self, **kwargs):
        self._cancel_pending_scroll()
        super().grid_remove(**kwargs)

    def grid_forget(self, **kwargs):
        self._cancel_pending_scroll()
        super().grid_forget(**kwargs)

    def pack_forget(self):
        self._cancel_pending_scroll()
        super().pack_forget()

    def place_forget(self, **kwargs):
        self._cancel_pending_scroll()
        super().place_forget(**kwargs)

    def destroy(self):
        self._stable_destroyed = True
        self._cancel_pending_scroll()
        if self._layout_job is not None:
            try:
                self.after_cancel(self._layout_job)
            except tk.TclError:
                pass
            self._layout_job = None
        super().destroy()
