import ctypes
import importlib.util
import json
import math
import os
import sys
import shutil
import threading
import time
from pathlib import Path

from PIL import Image, ImageDraw, ImageTk
import customtkinter as ctk
import tkinter as tk
from tkinter import filedialog

APP_VERSION = "17.2.0"
THIS_DIR = Path(__file__).resolve().parent
ROOT = Path(os.environ.get("IDLE_MAFIA_ROOT", str(THIS_DIR.parent.parent))).resolve()
BASE_DIR = ROOT / "versions" / "14.0.0"
APP_ID = "zonechrisp.RobloxAutoRollSelector.App"


def _set_app_id():
    if sys.platform == "win32":
        try:
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
        except Exception:
            pass


def _set_thread_below_normal():
    """Keep capture/detection from competing with Roblox for CPU time."""
    if sys.platform != "win32":
        return
    try:
        THREAD_PRIORITY_BELOW_NORMAL = -1
        kernel32 = ctypes.windll.kernel32
        kernel32.SetThreadPriority(kernel32.GetCurrentThread(), THREAD_PRIORITY_BELOW_NORMAL)
    except Exception:
        pass


def _load_base():
    base_main = BASE_DIR / "main.py"
    if not base_main.exists():
        raise RuntimeError(
            "Roblox Auto Roll Selector requires the installed v14.0.0 compatibility base. Reinstall v14.0.0 from Update Center, then install this version again."
        )
    if str(THIS_DIR) not in sys.path:
        sys.path.insert(0, str(THIS_DIR))
    if str(BASE_DIR) not in sys.path:
        sys.path.insert(1, str(BASE_DIR))
    spec = importlib.util.spec_from_file_location("idle_mafia_v14_base", base_main)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


base = _load_base()

# OpenCV's internal worker pool is unnecessary for a tiny rarity crop and can steal CPU/GPU
# scheduling time from Roblox. One OpenCV worker is both faster for this workload and calmer.
try:
    base.cv2.setNumThreads(1)
except Exception:
    pass
try:
    base.cv2.ocl.setUseOpenCL(False)
except Exception:
    pass


def efficient_wait_until(deadline_ns, stop_event, high_precision=True):
    """Low-CPU precision wait.

    v14 spent much of the last ~4 ms before every movement repeatedly yielding in a Python
    loop. At 240 generated events/s that can keep a CPU core unnecessarily busy. v15 sleeps
    for the bulk of every wait and only uses a very short final yield window.
    """
    while not stop_event.is_set():
        now = time.perf_counter_ns()
        remaining = deadline_ns - now
        if remaining <= 0:
            return True
        if not high_precision:
            stop_event.wait(remaining / 1_000_000_000)
            continue
        if remaining > 2_000_000:
            # Leave ~0.55 ms for scheduler jitter instead of spinning for several ms.
            stop_event.wait(max(0.0, (remaining - 550_000) / 1_000_000_000))
        elif remaining > 450_000:
            time.sleep(max(0.0, (remaining - 180_000) / 1_000_000_000))
        else:
            time.sleep(0)
    return False


# Base methods call this module global. Swap it once so even inherited code uses the low-CPU wait.
base.precise_wait_until = efficient_wait_until


def _all_widgets(widget):
    for child in widget.winfo_children():
        yield child
        yield from _all_widgets(child)


def _make_icon():
    """Universal Roblox Auto Roll Selector icon: target + cursor, no game-specific branding."""
    s = 128
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((4, 4, 124, 124), radius=28, fill=(15, 18, 21, 255), outline=(139, 92, 246, 255), width=4)
    d.rounded_rectangle((10, 10, 118, 118), radius=23, outline=(82, 50, 132, 220), width=2)
    red = (168, 85, 247, 255)
    light = (245, 247, 249, 255)
    # Target rings
    d.ellipse((29, 29, 99, 99), outline=red, width=5)
    d.ellipse((44, 44, 84, 84), outline=(196, 132, 252, 255), width=4)
    d.line((64, 17, 64, 39), fill=red, width=4)
    d.line((64, 89, 64, 111), fill=red, width=4)
    d.line((17, 64, 39, 64), fill=red, width=4)
    d.line((89, 64, 111, 64), fill=red, width=4)
    # Cursor arrow
    d.polygon([(54, 49), (54, 88), (64, 79), (73, 98), (81, 94), (72, 76), (88, 75)], fill=light, outline=(170, 176, 182, 255))
    return img

def _write_ico(pil):
    try:
        data_dir = ROOT / "data"
        data_dir.mkdir(parents=True, exist_ok=True)
        path = data_dir / "roblox_auto_roll_selector_purple_v1711.ico"
        pil.save(path, format="ICO", sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128)])
        return path
    except Exception:
        return None


def _force_taskbar_icon(app, ico_path):
    if sys.platform != "win32" or not ico_path:
        return
    try:
        user32 = ctypes.windll.user32
        IMAGE_ICON, LR_LOADFROMFILE, WM_SETICON = 1, 0x10, 0x80
        ICON_SMALL, ICON_BIG, GA_ROOT = 0, 1, 2
        GCLP_HICON, GCLP_HICONSM = -14, -34
        app.update_idletasks()
        tk_hwnd = int(app.winfo_id())
        root_hwnd = int(user32.GetAncestor(tk_hwnd, GA_ROOT)) or tk_hwnd
        parent_hwnd = int(user32.GetParent(tk_hwnd)) or root_hwnd
        targets = {tk_hwnd, root_hwnd, parent_hwnd}
        big = user32.LoadImageW(None, str(ico_path), IMAGE_ICON, 64, 64, LR_LOADFROMFILE)
        small = user32.LoadImageW(None, str(ico_path), IMAGE_ICON, 32, 32, LR_LOADFROMFILE)
        if not big or not small:
            return
        app._taskbar_hicons = (big, small)
        for hwnd in targets:
            if hwnd:
                user32.SendMessageW(hwnd, WM_SETICON, ICON_BIG, big)
                user32.SendMessageW(hwnd, WM_SETICON, ICON_SMALL, small)
                try:
                    user32.SetClassLongPtrW(hwnd, GCLP_HICON, big)
                    user32.SetClassLongPtrW(hwnd, GCLP_HICONSM, small)
                except Exception:
                    pass
    except Exception:
        pass


def _apply_icon(app):
    pil = _make_icon()
    app._v15_icon_photo = ImageTk.PhotoImage(pil.resize((64, 64), Image.Resampling.LANCZOS))
    app.iconphoto(True, app._v15_icon_photo)
    app.wm_iconphoto(True, app._v15_icon_photo)
    ico_path = _write_ico(pil)
    if ico_path:
        try:
            app.iconbitmap(default=str(ico_path))
        except Exception:
            pass
    app._v15_brand_image = ctk.CTkImage(light_image=pil, dark_image=pil, size=(42, 42))
    for widget in _all_widgets(app):
        if isinstance(widget, ctk.CTkLabel):
            try:
                if str(widget.cget("text")) == "IM":
                    widget.configure(text="", image=app._v15_brand_image, fg_color="transparent")
                    break
            except Exception:
                pass

    def force():
        _set_app_id()
        _force_taskbar_icon(app, ico_path)

    app.after(50, force)
    app.after(500, force)
    app.after(1500, force)


class V15App(base.IdleMafiaMacroApp):
    """v15 performance layer on top of the stable v14 UI/data format."""

    def __init__(self):
        self._v15_last_injected_pos = None
        self._v15_button_down_at = {}
        self._v15_last_loop_ui = 0.0
        self._v15_migrated = False
        super().__init__()
        self.title(f"Roblox Auto Roll Selector v{APP_VERSION}")
        self._apply_v15_migration()
        self._refresh_performance_vars()

    # ---------- v15 settings / UI ----------
    def build_settings_page(self):
        super().build_settings_page()
        page = self.pages.get("Settings")
        if page is None:
            return
        self.game_compat_var = tk.BooleanVar(value=bool(self.cfg.get("game_compatibility_mode", True)))
        self.click_settle_var = tk.IntVar(value=int(self.cfg.get("click_settle_ms", 6)))
        self.min_click_hold_var = tk.IntVar(value=int(self.cfg.get("min_click_hold_ms", 24)))
        self.template_stride_var = tk.IntVar(value=int(self.cfg.get("template_scan_stride", 12)))
        self.performance_status_var = tk.StringVar(value="")

        card = ctk.CTkFrame(page, fg_color=base.SURFACE, corner_radius=15, border_width=1, border_color=base.BORDER)
        # Insert near the top even though CustomTkinter pack doesn't expose a stable before-widget here.
        card.pack(fill="x", pady=(0, 14))
        ctk.CTkLabel(card, text="Game performance / Roblox compatibility", text_color=base.TEXT,
                     font=ctk.CTkFont(size=15, weight="bold")).pack(anchor="w", padx=20, pady=(16, 4))
        ctk.CTkLabel(
            card,
            text=("Reduces screen-capture, OpenCV and synthetic-mouse load so the game keeps more CPU/GPU time. "
                  "Recorded anchor coordinates are still replayed exactly; only generated in-between movement is rate-limited."),
            text_color=base.MUTED, wraplength=900, justify="left"
        ).pack(anchor="w", padx=20, pady=(0, 10))
        ctk.CTkSwitch(card, text="Game Compatibility Mode (recommended)", variable=self.game_compat_var,
                      command=self._on_game_mode_toggle, progress_color=base.ACCENT,
                      button_color="white", button_hover_color="#ddd").pack(anchor="w", padx=20, pady=(0, 10))
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x", padx=20, pady=(0, 8))
        for label, var, width in [
            ("Hover settle (ms)", self.click_settle_var, 82),
            ("Minimum click hold (ms)", self.min_click_hold_var, 82),
            ("Template scan every N frames", self.template_stride_var, 82),
        ]:
            ctk.CTkLabel(row, text=label, text_color=base.MUTED).pack(side="left", padx=(0, 6))
            ctk.CTkEntry(row, textvariable=var, width=width, fg_color=base.SURFACE_2, border_color=base.BORDER).pack(side="left", padx=(0, 18))
        ctk.CTkLabel(card, textvariable=self.performance_status_var, text_color=base.SUCCESS,
                     wraplength=900, justify="left").pack(anchor="w", padx=20, pady=(3, 16))

    def _refresh_performance_vars(self):
        if not hasattr(self, "game_compat_var"):
            return
        self.game_compat_var.set(bool(self.cfg.get("game_compatibility_mode", True)))
        self.click_settle_var.set(int(self.cfg.get("click_settle_ms", 6)))
        self.min_click_hold_var.set(int(self.cfg.get("min_click_hold_ms", 24)))
        self.template_stride_var.set(int(self.cfg.get("template_scan_stride", 12)))
        mode = bool(self.cfg.get("game_compatibility_mode", True))
        effective_hz = min(int(self.cfg.get("replay_hz", 120)), 120) if mode else int(self.cfg.get("replay_hz", 120))
        effective_scan = max(int(self.cfg.get("scan_interval_ms", 30)), 30) if mode else int(self.cfg.get("scan_interval_ms", 30))
        self.performance_status_var.set(
            f"Effective while running: generated movement ≤ {effective_hz} Hz • detector ≥ {effective_scan} ms • "
            f"OpenCV 1 thread • {'input coalescing ON' if mode else 'custom SendInput mode'}"
        )

    def _on_game_mode_toggle(self):
        enabled = bool(self.game_compat_var.get())
        self.cfg["game_compatibility_mode"] = enabled
        if enabled:
            # Update visible base controls to sane, game-friendly values as well.
            if int(self.replay_hz_var.get()) > 120:
                self.replay_hz_var.set(120)
            if int(self.scan_interval_var.get()) < 30:
                self.scan_interval_var.set(30)
            self.no_coalesce_var.set(False)
            self.cfg["replay_hz"] = int(self.replay_hz_var.get())
            self.cfg["scan_interval_ms"] = int(self.scan_interval_var.get())
            self.cfg["no_coalesce"] = False
        base.save_config(self.cfg)
        self._refresh_performance_vars()

    def _apply_v15_migration(self):
        if int(self.cfg.get("performance_profile_version", 0)) >= 15:
            return
        # Migrate old aggressive defaults that can contend with a game. Preserve deliberately
        # slower/custom settings and all macro coordinates/timings.
        self.cfg["game_compatibility_mode"] = True
        if int(self.cfg.get("replay_hz", 240)) >= 200:
            self.cfg["replay_hz"] = 120
            self.replay_hz_var.set(120)
        if int(self.cfg.get("scan_interval_ms", 12)) <= 20:
            self.cfg["scan_interval_ms"] = 30
            self.scan_interval_var.set(30)
        self.cfg["no_coalesce"] = False
        self.no_coalesce_var.set(False)
        self.cfg.setdefault("click_settle_ms", 6)
        self.cfg.setdefault("min_click_hold_ms", 24)
        self.cfg.setdefault("template_scan_stride", 12)
        self.cfg["performance_profile_version"] = 15
        base.save_config(self.cfg)
        self.log_activity("v15 Game Compatibility profile enabled: 120 Hz movement cap, 30 ms detector floor, low-CPU waits", "info")

    def save_settings(self):
        ok = super().save_settings()
        if hasattr(self, "game_compat_var"):
            settle = int(self.click_settle_var.get())
            hold = int(self.min_click_hold_var.get())
            stride = int(self.template_stride_var.get())
            if not 0 <= settle <= 50:
                raise ValueError("Hover settle must be between 0 and 50 ms.")
            if not 8 <= hold <= 100:
                raise ValueError("Minimum click hold must be between 8 and 100 ms.")
            if not 2 <= stride <= 60:
                raise ValueError("Template scan stride must be between 2 and 60 frames.")
            self.cfg["game_compatibility_mode"] = bool(self.game_compat_var.get())
            self.cfg["click_settle_ms"] = settle
            self.cfg["min_click_hold_ms"] = hold
            self.cfg["template_scan_stride"] = stride
            self.cfg["performance_profile_version"] = 15
            base.save_config(self.cfg)
            self._refresh_performance_vars()
        return ok

    # ---------- low-overhead UI ----------
    def animation_tick(self):
        try:
            enabled = bool(self.ui_animations_var.get())
            self._anim_phase = (self._anim_phase + 1) % 40
            game_mode = self.running and bool(self.cfg.get("game_compatibility_mode", True))
            if enabled and self.running:
                if game_mode:
                    # Static live indicator while playing: no continuous color animation fighting the game.
                    if hasattr(self, "header_live_dot"):
                        self.header_live_dot.configure(text_color=base.WARNING)
                    if hasattr(self, "header_pill") and self._rare_flash_remaining <= 0:
                        self.header_pill.configure(fg_color=base.SURFACE_2)
                else:
                    wave = (math.sin(self._anim_phase / 40.0 * math.tau) + 1.0) / 2.0
                    pulse = self._mix_hex(base.WARNING, base.TEXT, 0.15 + wave * 0.35)
                    if hasattr(self, "header_live_dot"):
                        self.header_live_dot.configure(text_color=pulse)
            else:
                if hasattr(self, "header_live_dot"):
                    idle_color = base.CYAN if self._rare_flash_remaining > 0 else (base.ACCENT if self.recording else base.MUTED)
                    self.header_live_dot.configure(text_color=idle_color)
            if self._rare_flash_remaining > 0 and enabled:
                bright = self._rare_flash_remaining % 2 == 0
                color = "#b8ffff" if bright else base.CYAN
                self.header_pill.configure(fg_color="#173f40" if bright else base.SURFACE_2, text_color=color)
                if hasattr(self, "hero_status"):
                    self.hero_status.configure(text_color=color)
                self._rare_flash_remaining -= 1
        except Exception:
            pass
        self.after(420 if (self.running and bool(self.cfg.get("game_compatibility_mode", True))) else 120, self.animation_tick)

    def set_scan_animation(self, active):
        # Indeterminate CTk progress bars redraw constantly. Avoid that during Roblox playback.
        if active and bool(self.cfg.get("game_compatibility_mode", True)):
            if hasattr(self, "scan_progress"):
                try:
                    self.scan_progress.stop()
                    self.scan_progress.set(0.72)
                except Exception:
                    pass
            return
        super().set_scan_animation(active)

    def ui_tick(self):
        if self.running and self.session_start:
            elapsed = max(0, time.perf_counter() - self.session_start)
            h = int(elapsed // 3600)
            m = int((elapsed % 3600) // 60)
            s = int(elapsed % 60)
            self.elapsed_var.set(f"{h:02d}:{m:02d}:{s:02d}")
            if elapsed > 3 and self.cycles > 0:
                self.loops_hour_var.set(str(int(round(self.cycles * 3600 / elapsed))))
        self.session_cycles_var.set(str(self.cycles))
        self.lifetime_cycles_var.set(str(int(self.cfg.get("lifetime_cycles", 0))))
        self.rare_finds_var.set(str(int(self.cfg.get("rare_finds", 0))))
        self.last_rare_var.set(str(self.cfg.get("last_rare", "Never")))
        self.secret_px_var.set(f"{self.last_secret_px} px")
        self.mythic_px_var.set(f"{self.last_mythic_px} px")
        if self.current_page == "Analytics" and hasattr(self, "chart"):
            self.chart.set_values(self.loop_durations)
        if hasattr(self, "dashboard_macro"):
            self.dashboard_macro.configure(
                text=f"{self.macro_duration_var.get()}\n{self.macro_moves_var.get()} move anchors • {self.macro_clicks_var.get()} clicks\n{self.macro_sample_var.get()}"
            )
        if self._stats_dirty and (time.monotonic() - self._last_stats_save) >= 3.0:
            try:
                base.save_config(self.cfg)
                self._stats_dirty = False
                self._last_stats_save = time.monotonic()
            except Exception:
                pass
        delay = 600 if (self.running and bool(self.cfg.get("game_compatibility_mode", True))) else 250
        self.after(delay, self.ui_tick)

    # ---------- optimized detector ----------
    def detector_loop(self, secret_templates, mythic_templates):
        try:
            _set_thread_below_normal()
            required = max(1, int(self.cfg.get("stable_frames", 2)))
            game_mode = bool(self.cfg.get("game_compatibility_mode", True))
            configured = int(self.cfg.get("scan_interval_ms", 30))
            interval = max(0.030 if game_mode else 0.008, configured / 1000.0)
            template_stride = max(2, int(self.cfg.get("template_scan_stride", 12 if game_mode else 3)))
            target = str(self.cfg.get("stop_target", "BOTH")).upper().strip()
            allowed = {"SECRET"} if target == "SECRET" else ({"MYTHIC"} if target == "MYTHIC" else {"SECRET", "MYTHIC"})
            streak = 0
            streak_kind = None
            frame_no = 0
            with base.mss.mss() as sct:
                while self.running and not self.stop_event.is_set():
                    frame = self.grab_region(sct)
                    frame_no += 1
                    # Color detection is cheap and remains on every scan. Expensive template matching is a
                    # low-frequency fallback, not something that needs to run dozens of times per second.
                    fallback = (frame_no % template_stride == 0)
                    kind, info, counts = self.detect_once(
                        frame, secret_templates, mythic_templates,
                        template_fallback=fallback, allowed_kinds=allowed
                    )
                    self.last_secret_px = counts.get("SECRET", 0)
                    self.last_mythic_px = counts.get("MYTHIC", 0)
                    if kind and kind == streak_kind:
                        streak += 1
                    elif kind:
                        streak_kind, streak = kind, 1
                    else:
                        streak_kind, streak = None, 0
                    if kind and streak >= required:
                        self.rare_event.set()
                        self.stop_event.set()
                        cycle_no = max(0, self.active_loop_no)
                        self.after(0, lambda k=kind, i=info, n=cycle_no: self.record_rare(k, i, n))
                        self.after(0, lambda k=kind, i=info, n=cycle_no: self.finish_controller(
                            f"RARE FOUND: {k} detected on loop {n} ({i}). Replay was cancelled before later recorded events could run.",
                            "rare", "rare"
                        ))
                        return
                    self.stop_event.wait(interval)
        except Exception as e:
            if self.running and not self.stop_event.is_set():
                self.engine_error_message = str(e)
                self.stop_event.set()
                self.after(0, lambda err=str(e): self.finish_controller(f"Detector error: {err}", "error", "error"))
                self.after(0, lambda err=str(e): self.log_activity(f"Detector error: {err}", "error"))

    # ---------- optimized replay ----------
    def compile_replay_timeline(self, macro):
        events = macro.get("events", []) if macro else []
        if not events:
            return []
        smooth = bool(self.cfg.get("smooth_replay", True))
        configured_hz = max(60, int(self.cfg.get("replay_hz", 120)))
        game_mode = bool(self.cfg.get("game_compatibility_mode", True))
        replay_hz = min(configured_hz, 120) if game_mode else configured_hz
        interval_rec = 1.0 / replay_hz
        if not smooth:
            return list(events)

        timeline = []
        last_anchor = None
        last_generated_xy = None
        for ev in events:
            rec_t = float(ev.get("t", 0.0))
            if "x" in ev and "y" in ev and last_anchor is not None:
                prev_t = float(last_anchor.get("t", 0.0))
                dt = rec_t - prev_t
                if dt > interval_rec * 1.25:
                    px, py = int(last_anchor["x"]), int(last_anchor["y"])
                    tx, ty = int(ev["x"]), int(ev["y"])
                    tcur = prev_t + interval_rec
                    while tcur < rec_t - 1e-9:
                        frac = (tcur - prev_t) / max(1e-9, dt)
                        x = round(px + (tx - px) * frac)
                        y = round(py + (ty - py) * frac)
                        # Do not flood Windows/Roblox with multiple generated events that round to the same pixel.
                        if (x, y) != last_generated_xy:
                            timeline.append({"t": tcur, "type": "move", "x": x, "y": y, "generated": True})
                            last_generated_xy = (x, y)
                        tcur += interval_rec
            # Every real recorded anchor/event is kept, regardless of optimization.
            timeline.append(ev)
            if "x" in ev and "y" in ev:
                last_anchor = ev
                last_generated_xy = (int(ev["x"]), int(ev["y"]))
        return timeline

    def _send_event(self, injector, ev):
        et = ev.get("type")
        x = int(ev.get("x", self._v15_last_injected_pos[0] if self._v15_last_injected_pos else 0))
        y = int(ev.get("y", self._v15_last_injected_pos[1] if self._v15_last_injected_pos else 0))
        if et == "move":
            # Generated duplicates are filtered during compilation; recorded anchors are always sent.
            injector.move_absolute(x, y)
            self._v15_last_injected_pos = (x, y)
            return
        if et == "button":
            # v14 re-sent a mouse-move event immediately before every button transition. In some games that
            # means move+click land in the same input frame. Only reposition when needed, then give the game
            # a tiny hover-processing window before mouse-down.
            if self._v15_last_injected_pos != (x, y):
                injector.move_absolute(x, y)
                self._v15_last_injected_pos = (x, y)
                settle = max(0, int(self.cfg.get("click_settle_ms", 6))) / 1000.0
                if settle:
                    self.stop_event.wait(settle)
            button = str(ev.get("button", "left"))
            pressed = bool(ev.get("pressed"))
            if pressed:
                injector.button(button, True)
                self._v15_button_down_at[button] = time.perf_counter()
            else:
                down_at = self._v15_button_down_at.pop(button, None)
                if down_at is not None:
                    min_hold = max(0.008, int(self.cfg.get("min_click_hold_ms", 24)) / 1000.0)
                    remaining = min_hold - (time.perf_counter() - down_at)
                    if remaining > 0:
                        self.stop_event.wait(remaining)
                injector.button(button, False)
            return
        if et == "scroll":
            if self._v15_last_injected_pos != (x, y):
                injector.move_absolute(x, y)
                self._v15_last_injected_pos = (x, y)
            injector.scroll(int(ev.get("dx", 0)), int(ev.get("dy", 0)))

    def replay_macro_once(self, injector, macro, timeline=None):
        events = timeline if timeline is not None else self.compile_replay_timeline(macro)
        if not events:
            return False
        speed = max(0.25, float(self.cfg.get("replay_speed", 1.0)))
        high_precision = bool(self.cfg.get("high_precision_timing", True))
        start_ns = time.perf_counter_ns()
        self._v15_last_injected_pos = None
        self._v15_button_down_at.clear()

        for ev in events:
            if self.stop_event.is_set() or self.rare_event.is_set():
                return False
            rec_t = float(ev.get("t", 0.0))
            deadline = start_ns + int((rec_t / speed) * 1_000_000_000)
            if not efficient_wait_until(deadline, self.stop_event, high_precision):
                return False
            if self.rare_event.is_set():
                return False
            self._send_event(injector, ev)

        original = macro.get("events", [])
        duration = float(macro.get("duration", original[-1].get("t", 0.0) if original else 0.0))
        efficient_wait_until(start_ns + int((duration / speed) * 1_000_000_000), self.stop_event, high_precision)
        return not self.stop_event.is_set() and not self.rare_event.is_set()

    def controller_loop(self):
        injector = None
        try:
            if sys.platform != "win32":
                raise RuntimeError("Precision absolute replay requires Windows.")
            macro = self.macro
            secret_templates = self.load_templates(base.SECRET_DIR)
            mythic_templates = self.load_templates(base.MYTHIC_DIR)
            game_mode = bool(self.cfg.get("game_compatibility_mode", True))
            # Allow Windows to coalesce redundant synthetic movement in compatibility mode. Real anchors and
            # button events are still sent directly and in order.
            injector = base.WindowsMouseInjector(no_coalesce=False if game_mode else bool(self.cfg.get("no_coalesce", True)))
            injector.refresh_bounds()
            replay_timeline = self.compile_replay_timeline(macro)

            detector = threading.Thread(target=self.detector_loop, args=(secret_templates, mythic_templates), daemon=True)
            detector.start()

            effective_scan_ms = max(30 if game_mode else 8, int(self.cfg.get("scan_interval_ms", 30)))
            precheck_deadline = time.perf_counter() + max(0.10, int(self.cfg.get("stable_frames", 2)) * effective_scan_ms / 1000.0 * 2.2)
            while time.perf_counter() < precheck_deadline and not self.stop_event.is_set():
                self.stop_event.wait(0.008)
            if self.stop_event.is_set():
                return

            high_precision = bool(self.cfg.get("high_precision_timing", True))
            loop_gap = max(0.0, int(self.cfg.get("loop_gap_ms", 80)) / 1000.0)
            self._v15_last_loop_ui = 0.0
            with base.TimerResolution(high_precision):
                while not self.stop_event.is_set():
                    loop_start = time.perf_counter()
                    loop_no = self.cycles + 1
                    self.active_loop_no = loop_no
                    now = time.monotonic()
                    if loop_no == 1 or now - self._v15_last_loop_ui >= 1.0:
                        self._v15_last_loop_ui = now
                        self.after(0, lambda n=loop_no: self.set_status(
                            f"Loop {n}: low-impact precision replay • Game Compatibility {'ON' if game_mode else 'OFF'}", "running"
                        ))
                    completed = self.replay_macro_once(injector, macro, replay_timeline)
                    if not completed:
                        break
                    loop_end = time.perf_counter()
                    self.cycles += 1
                    self.loop_durations.append(max(0.001, loop_end - loop_start))
                    self.cfg["lifetime_cycles"] = int(self.cfg.get("lifetime_cycles", 0)) + 1
                    self._stats_dirty = True
                    # Don't queue two Tk callbacks and a sound on every fast loop. Log periodically instead.
                    if self.cycles <= 3 or self.cycles % 10 == 0:
                        self.after(0, lambda n=self.cycles: self.log_activity(f"Loop {n} completed (v15 low-impact engine)", "cycle"))
                    if loop_gap > 0:
                        gap_end = time.perf_counter_ns() + int(loop_gap * 1_000_000_000)
                        if not efficient_wait_until(gap_end, self.stop_event, high_precision):
                            break

            if not self.rare_event.is_set() and not self.engine_error_message:
                self.after(0, lambda: self.finish_controller(
                    f"Macro stopped by user after {self.cycles} completed loop(s).", "stopped", "stop"
                ))
                self.after(0, lambda: self.log_activity(f"Macro stopped after {self.cycles} loop(s)", "stop"))
        except Exception as e:
            self.stop_event.set()
            self.after(0, lambda err=str(e): self.finish_controller(f"Macro stopped because of an error: {err}", "error", "error"))
            self.after(0, lambda err=str(e): self.log_activity(f"Macro engine error: {err}", "error"))
        finally:
            if injector is not None:
                try:
                    injector.release_all()
                    if hasattr(self, "_release_all_keyboard"):
                        self._release_all_keyboard()
                except Exception:
                    pass



SEQUENCE_CONFIG_PATH = ROOT / "data" / "sequence_slots.json"
SEQUENCE_SLOT_COUNT = 10


def _default_sequence_meta():
    return {
        "version": 1,
        "slots": [
            {
                "enabled": False,
                "region": None,
                "stop_target": "BOTH",
                "deactivated_reason": "",
                "rare_count": 0,
                "last_rare": "Never",
                "custom_template": "",
                "custom_template_name": "",
            }
            for _ in range(SEQUENCE_SLOT_COUNT)
        ],
    }


def _slot_macro_path(index):
    return ROOT / "data" / f"sequence_macro_{index + 1}.json"


class V16App(V15App):
    """Ten-slot sequence controller built on the v15 low-impact replay engine."""

    def __init__(self):
        self._record_target_slot = None
        self._last_recorded_slot = None
        self._sequence_meta = self._load_sequence_meta()
        self._slot_macros = [self._load_slot_macro(i) for i in range(SEQUENCE_SLOT_COUNT)]
        self._seq_ui = []
        self._sequence_current_slot = -1
        self._sequence_slot_runs = 0
        self._sequence_rare_events = 0
        super().__init__()
        self.title(f"Roblox Auto Roll Selector v{APP_VERSION}")
        self._apply_v16_migration()
        self._refresh_sequence_ui()

    # ---------- persistence ----------
    def _load_sequence_meta(self):
        meta = _default_sequence_meta()
        try:
            if SEQUENCE_CONFIG_PATH.exists():
                raw = json.loads(SEQUENCE_CONFIG_PATH.read_text(encoding="utf-8"))
                slots = raw.get("slots", []) if isinstance(raw, dict) else []
                for i in range(min(SEQUENCE_SLOT_COUNT, len(slots))):
                    if isinstance(slots[i], dict):
                        meta["slots"][i].update(slots[i])
        except Exception:
            pass
        for slot in meta["slots"]:
            target = str(slot.get("stop_target", "BOTH")).upper()
            slot["stop_target"] = target if target in {"BOTH", "SECRET", "MYTHIC", "CUSTOM"} else "BOTH"
            slot["enabled"] = bool(slot.get("enabled", False))
        return meta

    def _save_sequence_meta(self):
        SEQUENCE_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        SEQUENCE_CONFIG_PATH.write_text(json.dumps(self._sequence_meta, indent=2), encoding="utf-8")

    def _load_slot_macro(self, index):
        path = _slot_macro_path(index)
        try:
            if path.exists():
                data = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(data, dict) and isinstance(data.get("events"), list):
                    return data
        except Exception:
            pass
        return None

    def _save_slot_macro(self, index, macro):
        path = _slot_macro_path(index)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(macro, separators=(",", ":")), encoding="utf-8")
        self._slot_macros[index] = macro

    def _apply_v16_migration(self):
        changed = False
        if "sequence_mode" not in self.cfg:
            self.cfg["sequence_mode"] = False
            changed = True
        if "sequence_result_check_ms" not in self.cfg:
            self.cfg["sequence_result_check_ms"] = 180
            changed = True
        if "sequence_precheck_ms" not in self.cfg:
            self.cfg["sequence_precheck_ms"] = 80
            changed = True
        if int(self.cfg.get("sequence_profile_version", 0)) < 16:
            self.cfg["sequence_profile_version"] = 17
            changed = True
        if changed:
            base.save_config(self.cfg)

    # ---------- shell / page ----------
    def build_shell(self):
        super().build_shell()
        try:
            sidebar = self.nav_buttons["Detection"].master
            btn = ctk.CTkButton(
                sidebar, text="≋   Sequence", anchor="w", height=44, corner_radius=10,
                fg_color="transparent", hover_color=base.SURFACE_2, text_color=base.MUTED,
                font=ctk.CTkFont(family="Segoe UI", size=13, weight="bold"),
                command=lambda: self.switch_page("Sequence"),
            )
            btn.pack(fill="x", padx=12, pady=3, before=self.nav_buttons["Detection"])
            self.nav_buttons["Sequence"] = btn
        except Exception:
            pass

    def build_pages(self):
        super().build_pages()
        self.build_sequence_page()

    def switch_page(self, name):
        super().switch_page(name)
        if name == "Sequence":
            self.page_subtitle.configure(text="Run up to ten independent macro + target-area pairs in one rotating sequence")
            self._refresh_sequence_ui()

    def build_sequence_page(self):
        page = self.make_page("Sequence")
        base.ctk.CTkLabel(page, text="Sequence controller", text_color=base.TEXT,
                         font=ctk.CTkFont(family="Segoe UI", size=18, weight="bold")).pack(anchor="w", pady=(2, 0))
        base.ctk.CTkLabel(
            page,
            text=("Each slot owns its own recorded mouse/keyboard macro, target area and target image or legacy stop target. The controller rotates through enabled slots. "
                  "If one slot sees its selected rare, only that slot is deactivated; the remaining slots continue."),
            text_color=base.MUTED, wraplength=940, justify="left"
        ).pack(anchor="w", pady=(2, 12))

        top = ctk.CTkFrame(page, fg_color=base.SURFACE, corner_radius=16, border_width=1, border_color=base.BORDER)
        top.pack(fill="x", pady=(0, 14))
        row = ctk.CTkFrame(top, fg_color="transparent")
        row.pack(fill="x", padx=20, pady=(16, 8))
        self.sequence_mode_var = tk.BooleanVar(value=bool(self.cfg.get("sequence_mode", False)))
        self.sequence_mode_switch = ctk.CTkSwitch(
            row, text="Use 10-slot Sequence Mode", variable=self.sequence_mode_var,
            command=self._on_sequence_mode_toggle, progress_color=base.ACCENT,
            button_color="white", button_hover_color="#dddddd"
        )
        self.sequence_mode_switch.pack(side="left")
        self.sequence_summary_var = tk.StringVar(value="")
        ctk.CTkLabel(row, textvariable=self.sequence_summary_var, text_color=base.SUCCESS,
                     font=ctk.CTkFont(size=12, weight="bold")).pack(side="right")

        timing = ctk.CTkFrame(top, fg_color="transparent")
        timing.pack(fill="x", padx=20, pady=(0, 14))
        self.sequence_precheck_var = tk.IntVar(value=int(self.cfg.get("sequence_precheck_ms", 80)))
        self.sequence_result_check_var = tk.IntVar(value=int(self.cfg.get("sequence_result_check_ms", 180)))
        ctk.CTkLabel(timing, text="Pre-check before each slot (ms)", text_color=base.MUTED).pack(side="left")
        ctk.CTkEntry(timing, textvariable=self.sequence_precheck_var, width=76,
                     fg_color=base.SURFACE_2, border_color=base.BORDER).pack(side="left", padx=(7, 18))
        ctk.CTkLabel(timing, text="Final result scan window (ms)", text_color=base.MUTED).pack(side="left")
        ctk.CTkEntry(timing, textvariable=self.sequence_result_check_var, width=76,
                     fg_color=base.SURFACE_2, border_color=base.BORDER).pack(side="left", padx=(7, 18))
        ctk.CTkButton(timing, text="Reactivate configured slots", height=32, corner_radius=9,
                      fg_color=base.SURFACE_3, hover_color="#3b434b", command=self.reactivate_all_slots).pack(side="right")

        self._seq_ui = []
        for i in range(SEQUENCE_SLOT_COUNT):
            slot = self._sequence_meta["slots"][i]
            card = ctk.CTkFrame(page, fg_color=base.SURFACE, corner_radius=15, border_width=1, border_color=base.BORDER)
            card.pack(fill="x", pady=(0, 12))
            header = ctk.CTkFrame(card, fg_color="transparent")
            header.pack(fill="x", padx=18, pady=(14, 8))
            ctk.CTkLabel(header, text=f"SLOT {i + 1}", text_color=base.TEXT,
                         font=ctk.CTkFont(size=16, weight="bold")).pack(side="left")
            status_var = tk.StringVar(value="")
            status = ctk.CTkLabel(header, textvariable=status_var, width=125, height=28,
                                  corner_radius=9, fg_color=base.SURFACE_2, text_color=base.MUTED,
                                  font=ctk.CTkFont(size=10, weight="bold"))
            status.pack(side="right")

            controls = ctk.CTkFrame(card, fg_color="transparent")
            controls.pack(fill="x", padx=18, pady=(0, 9))
            enabled_var = tk.BooleanVar(value=bool(slot.get("enabled", False)))
            enable = ctk.CTkSwitch(
                controls, text="Enabled", variable=enabled_var,
                command=lambda n=i: self._toggle_slot_enabled(n), progress_color=base.ACCENT,
                button_color="white", button_hover_color="#ddd"
            )
            enable.pack(side="left", padx=(0, 16))
            target_var = tk.StringVar(value=str(slot.get("stop_target", "BOTH")))
            target = ctk.CTkSegmentedButton(
                controls, values=["BOTH", "SECRET", "MYTHIC", "CUSTOM"], variable=target_var,
                command=lambda value, n=i: self._set_slot_target(n, value),
                selected_color=base.ACCENT, selected_hover_color=base.ACCENT_HOVER,
                unselected_color=base.SURFACE_2, unselected_hover_color=base.SURFACE_3
            )
            target.pack(side="left")

            buttons = ctk.CTkFrame(card, fg_color="transparent")
            buttons.pack(fill="x", padx=18, pady=(0, 9))
            rec = base.ModernButton(buttons, text="●  RECORD MACRO", width=150, height=34,
                                    fg_color=base.ACCENT, hover_color=base.ACCENT_HOVER,
                                    command=lambda n=i: self.start_sequence_recording(n))
            rec.pack(side="left", padx=(0, 7))
            region_btn = ctk.CTkButton(buttons, text="Set target area", width=130, height=34, corner_radius=9,
                                       fg_color=base.SURFACE_3, hover_color="#3b434b",
                                       command=lambda n=i: self.select_slot_region(n))
            region_btn.pack(side="left", padx=7)
            template_btn = ctk.CTkButton(buttons, text="Upload target", width=112, height=34, corner_radius=9,
                                         fg_color=base.SURFACE_3, hover_color="#3b434b",
                                         command=lambda n=i: self.upload_slot_template(n))
            template_btn.pack(side="left", padx=7)
            test_btn = ctk.CTkButton(buttons, text="Test", width=72, height=34, corner_radius=9,
                                     fg_color=base.SURFACE_3, hover_color="#3b434b",
                                     command=lambda n=i: self.test_slot_detection(n))
            test_btn.pack(side="left", padx=7)
            reactivate = ctk.CTkButton(buttons, text="Reactivate", width=100, height=34, corner_radius=9,
                                       fg_color=base.SURFACE_3, hover_color="#3b434b",
                                       command=lambda n=i: self.reactivate_slot(n))
            reactivate.pack(side="right", padx=(7, 0))
            clear = ctk.CTkButton(buttons, text="Clear", width=75, height=34, corner_radius=9,
                                  fg_color="transparent", border_width=1, border_color=base.BORDER,
                                  hover_color=base.SURFACE_2, command=lambda n=i: self.clear_slot(n))
            clear.pack(side="right")

            macro_var = tk.StringVar(value="")
            region_var = tk.StringVar(value="")
            template_var = tk.StringVar(value="")
            reason_var = tk.StringVar(value="")
            info = ctk.CTkFrame(card, fg_color=base.SURFACE_2, corner_radius=10)
            info.pack(fill="x", padx=18, pady=(0, 14))
            ctk.CTkLabel(info, textvariable=macro_var, text_color=base.TEXT, justify="left").pack(anchor="w", padx=12, pady=(9, 1))
            ctk.CTkLabel(info, textvariable=region_var, text_color=base.MUTED, justify="left").pack(anchor="w", padx=12, pady=(0, 1))
            ctk.CTkLabel(info, textvariable=template_var, text_color=base.CYAN, justify="left").pack(anchor="w", padx=12, pady=(0, 1))
            ctk.CTkLabel(info, textvariable=reason_var, text_color=base.WARNING, justify="left", wraplength=850).pack(anchor="w", padx=12, pady=(0, 9))

            self._seq_ui.append({
                "status_var": status_var, "status": status, "enabled_var": enabled_var,
                "enable": enable, "target_var": target_var, "target": target,
                "record": rec, "region": region_btn, "template": template_btn, "test": test_btn,
                "reactivate": reactivate, "clear": clear,
                "macro_var": macro_var, "region_var": region_var, "template_var": template_var, "reason_var": reason_var,
            })

        footer = ctk.CTkFrame(page, fg_color="#191f24", corner_radius=13, border_width=1, border_color=base.BORDER)
        footer.pack(fill="x", pady=(2, 18))
        ctk.CTkLabel(
            footer,
            text=("Sequence example: Slot 1 → check Area 1 → Slot 2 → check Area 2 → Slot 3 → check Area 3. "
                  "If Area 3 detects its selected rarity, Slot 3 is disabled immediately and future passes continue with every other enabled slot up to Slot 10."),
            text_color=base.MUTED, wraplength=930, justify="left"
        ).pack(anchor="w", padx=16, pady=14)

    def _on_sequence_mode_toggle(self):
        self.cfg["sequence_mode"] = bool(self.sequence_mode_var.get())
        base.save_config(self.cfg)
        self._refresh_sequence_ui()
        self.log_activity(f"Sequence Mode {'enabled' if self.sequence_mode_var.get() else 'disabled'}", "info")

    def save_settings(self):
        ok = super().save_settings()
        if hasattr(self, "sequence_mode_var"):
            pre = int(self.sequence_precheck_var.get())
            final = int(self.sequence_result_check_var.get())
            if not 0 <= pre <= 1000:
                raise ValueError("Sequence pre-check must be between 0 and 1000 ms.")
            if not 40 <= final <= 2000:
                raise ValueError("Sequence final scan window must be between 40 and 2000 ms.")
            self.cfg["sequence_mode"] = bool(self.sequence_mode_var.get())
            self.cfg["sequence_precheck_ms"] = pre
            self.cfg["sequence_result_check_ms"] = final
            self.cfg["sequence_profile_version"] = 17
            base.save_config(self.cfg)
        return ok

    # ---------- slot UI helpers ----------
    def _slot_ready(self, index):
        slot = self._sequence_meta["slots"][index]
        return bool(slot.get("enabled")) and self._slot_macros[index] is not None and bool(slot.get("region"))

    def _configured_slot_count(self):
        return sum(1 for i in range(SEQUENCE_SLOT_COUNT) if self._slot_macros[i] is not None and self._sequence_meta["slots"][i].get("region"))

    def _active_slot_indices(self):
        return [i for i in range(SEQUENCE_SLOT_COUNT) if self._slot_ready(i)]

    def _refresh_sequence_ui(self):
        if not self._seq_ui:
            return
        active = 0
        configured = 0
        for i, ui in enumerate(self._seq_ui):
            slot = self._sequence_meta["slots"][i]
            macro = self._slot_macros[i]
            region = slot.get("region")
            ready_config = macro is not None and bool(region)
            configured += 1 if ready_config else 0
            is_active = bool(slot.get("enabled")) and ready_config
            active += 1 if is_active else 0
            ui["enabled_var"].set(bool(slot.get("enabled", False)))
            ui["target_var"].set(str(slot.get("stop_target", "BOTH")))
            if macro:
                stats = self.macro_stats(macro)
                ui["macro_var"].set(
                    f"Macro: {stats['duration']:.3f}s • {stats['events']} events • {stats['moves']} move anchors • {stats['clicks']} clicks"
                )
            else:
                ui["macro_var"].set("Macro: not recorded")
            if region:
                ui["region_var"].set(
                    f"Target area: {region.get('width','?')}×{region.get('height','?')} • x={region.get('left','?')} y={region.get('top','?')} • target {slot.get('stop_target','BOTH')}"
                )
            else:
                ui["region_var"].set("Target area: not set")
            reason = str(slot.get("deactivated_reason", ""))
            ui["reason_var"].set(reason if reason else " ")
            if is_active:
                ui["status_var"].set("ACTIVE")
                ui["status"].configure(text_color=base.SUCCESS, fg_color="#18322d")
            elif reason:
                ui["status_var"].set("RARE • OFF")
                ui["status"].configure(text_color=base.WARNING, fg_color="#332817")
            elif not ready_config:
                ui["status_var"].set("INCOMPLETE")
                ui["status"].configure(text_color=base.MUTED, fg_color=base.SURFACE_2)
            else:
                ui["status_var"].set("DISABLED")
                ui["status"].configure(text_color=base.MUTED, fg_color=base.SURFACE_2)
        mode = bool(self.sequence_mode_var.get()) if hasattr(self, "sequence_mode_var") else bool(self.cfg.get("sequence_mode", False))
        self.sequence_summary_var.set(f"{'SEQUENCE ON' if mode else 'SEQUENCE OFF'} • {active} active / {configured} configured")

    def _toggle_slot_enabled(self, index):
        if self.running:
            self._refresh_sequence_ui()
            return
        enabled = bool(self._seq_ui[index]["enabled_var"].get())
        self._sequence_meta["slots"][index]["enabled"] = enabled
        if enabled:
            self._sequence_meta["slots"][index]["deactivated_reason"] = ""
        self._save_sequence_meta()
        self._refresh_sequence_ui()

    def _set_slot_target(self, index, value):
        target = str(value).upper()
        if target not in {"BOTH", "SECRET", "MYTHIC"}:
            target = "BOTH"
        self._sequence_meta["slots"][index]["stop_target"] = target
        self._save_sequence_meta()
        self._refresh_sequence_ui()

    def reactivate_slot(self, index):
        if self.running or self.recording:
            return
        if self._slot_macros[index] is None or not self._sequence_meta["slots"][index].get("region"):
            base.messagebox.showwarning("Incomplete slot", f"Slot {index + 1} needs both a recorded macro and a target area first.")
            return
        slot = self._sequence_meta["slots"][index]
        slot["enabled"] = True
        slot["deactivated_reason"] = ""
        self._save_sequence_meta()
        self._refresh_sequence_ui()
        self.log_activity(f"Sequence Slot {index + 1} reactivated", "info")

    def reactivate_all_slots(self):
        if self.running or self.recording:
            return
        count = 0
        for i, slot in enumerate(self._sequence_meta["slots"]):
            if self._slot_macros[i] is not None and slot.get("region"):
                slot["enabled"] = True
                slot["deactivated_reason"] = ""
                count += 1
        self._save_sequence_meta()
        self._refresh_sequence_ui()
        self.log_activity(f"Reactivated {count} configured sequence slot(s)", "info")

    def clear_slot(self, index):
        if self.running or self.recording:
            base.messagebox.showwarning("Busy", "Stop playback/recording first.")
            return
        if not base.messagebox.askyesno("Clear sequence slot", f"Clear Macro {index + 1} and its target area?"):
            return
        try:
            _slot_macro_path(index).unlink(missing_ok=True)
        except Exception:
            pass
        self._slot_macros[index] = None
        self._sequence_meta["slots"][index] = _default_sequence_meta()["slots"][index]
        self._save_sequence_meta()
        self._refresh_sequence_ui()
        self.log_activity(f"Sequence Slot {index + 1} cleared", "info")

    # ---------- visible recording countdown ----------
    def _set_record_countdown_status(self, seconds_left, hotkey):
        """Show the countdown inside the app's existing Engine status UI."""
        try:
            label = f"REC {seconds_left:.1f}s"
            self.status_short_var.set(label)
            self.status_var.set(
                f"Mouse recording starts in {seconds_left:.1f}s • app stays open • stop with {hotkey.upper()}"
            )
            self.record_status_var.set(
                f"COUNTDOWN • {seconds_left:.1f}s • app stays open • stop with {hotkey.upper()}"
            )
            # Keep the engine-status corner visually distinct during countdown.
            for widget in (getattr(self, "header_pill", None), getattr(self, "sidebar_status", None), getattr(self, "hero_status", None)):
                if widget is not None:
                    widget.configure(text_color=base.ACCENT)
        except Exception:
            pass

    def start_recording(self):
        """Keep the app visible and count down in Engine status instead of hiding it."""
        if self.running:
            base.messagebox.showwarning("Macro running", "Stop playback before recording a new macro.")
            return
        if self.recording:
            return
        try:
            self.save_settings()
        except Exception as e:
            base.messagebox.showerror("Settings", str(e))
            return

        hotkey = self.cfg.get("record_stop_hotkey", "f9")
        countdown = max(1, int(self.cfg.get("record_countdown_s", 2)))
        if not base.messagebox.askyesno(
            "Record new mouse macro",
            f"The app will stay open. Recording starts after a visible {countdown}-second countdown in the Engine status corner.\n\n"
            f"Press {hotkey.upper()} to stop recording.\n\nRecord one complete cycle. Continue?",
        ):
            return

        self.recording = True
        self.record_stop_event.clear()
        self.record_events = []
        self.record_screen = base.virtual_screen_bounds()
        try:
            self.record_button.configure(state="disabled")
            self.stop_record_button.configure(state="normal")
        except Exception:
            pass
        self._set_record_countdown_status(float(countdown), hotkey)
        self.log_activity(f"Visible recording countdown started ({countdown}s)", "record")
        self.play_sound("start")
        # Deliberately do NOT iconify()/withdraw(): user asked to keep the app visible.
        threading.Thread(target=self._record_worker, args=(countdown, hotkey), daemon=True).start()

    def _record_worker(self, countdown, hotkey):
        """Countdown with 0.1s Engine-status updates, then hand off to the proven recorder."""
        try:
            _set_thread_below_normal()
            deadline = time.perf_counter() + float(countdown)
            last_tenth = None
            while True:
                if self.record_stop_event.is_set():
                    raise RuntimeError("Recording cancelled before capture started.")
                remaining = deadline - time.perf_counter()
                if remaining <= 0:
                    break
                # Round upward so a two-second countdown visibly begins at 2.0, not 1.9.
                tenth = math.ceil((remaining - 1e-6) * 10.0) / 10.0
                tenth = max(0.1, min(float(countdown), tenth))
                if tenth != last_tenth:
                    last_tenth = tenth
                    self.after(0, lambda r=tenth, h=hotkey: self._set_record_countdown_status(r, h))
                self.record_stop_event.wait(min(0.045, max(0.0, remaining)))

            if self.record_stop_event.is_set():
                raise RuntimeError("Recording cancelled before capture started.")

            # The inherited recorder is still the exact same proven mouse-capture path;
            # passing zero skips its old hidden countdown because the in-app Engine status already performed it visibly.
            return super()._record_worker(0, hotkey)
        except Exception as e:
            self.after(0, lambda err=str(e): self._record_error_ui(err))
            self.recording = False
            self.record_listener = None
            self.record_start_perf = None
            self.record_stop_event.clear()

    # ---------- slot recording ----------
    def start_sequence_recording(self, index):
        if self.running or self.recording:
            base.messagebox.showwarning("Busy", "Stop playback/recording first.")
            return
        self._record_target_slot = index
        self._set_sequence_controls_recording(True)
        self.start_recording()
        if not self.recording:
            self._record_target_slot = None
            self._set_sequence_controls_recording(False)

    def _set_sequence_controls_recording(self, recording):
        state = "disabled" if recording else "normal"
        for ui in self._seq_ui:
            for key in ("record", "region", "template", "test", "reactivate", "clear", "enable", "target"):
                try:
                    ui[key].configure(state=state)
                except Exception:
                    pass

    def save_macro(self, macro):
        if self._record_target_slot is None:
            return super().save_macro(macro)
        index = int(self._record_target_slot)
        self._save_slot_macro(index, macro)
        slot = self._sequence_meta["slots"][index]
        slot["enabled"] = True
        slot["deactivated_reason"] = ""
        self._save_sequence_meta()
        self._last_recorded_slot = index

    def _record_success_ui(self):
        if self._record_target_slot is None:
            return super()._record_success_ui()
        index = int(self._record_target_slot)
        self.deiconify()
        self.lift()
        try:
            self.record_button.configure(state="normal")
            self.stop_record_button.configure(state="disabled")
        except Exception:
            pass
        self._set_sequence_controls_recording(False)
        macro = self._slot_macros[index]
        stats = self.macro_stats(macro)
        self.record_status_var.set(
            f"SLOT {index + 1} SAVED • {stats['events']} events • {stats['clicks']} clicks • {stats['duration']:.3f}s"
        )
        self.set_status(f"Sequence Macro {index + 1} saved with exact absolute coordinates.", "idle")
        self.log_activity(f"Sequence Macro {index + 1} recorded: {stats['events']} events, {stats['duration']:.3f}s", "record")
        self.play_sound("test")
        if hasattr(self, "sequence_mode_var"):
            self.sequence_mode_var.set(True)
            self.cfg["sequence_mode"] = True
            base.save_config(self.cfg)
        self._record_target_slot = None
        self._refresh_sequence_ui()

    def _record_error_ui(self, error):
        if self._record_target_slot is None:
            return super()._record_error_ui(error)
        index = int(self._record_target_slot)
        self._record_target_slot = None
        self._set_sequence_controls_recording(False)
        self.deiconify()
        self.lift()
        try:
            self.record_button.configure(state="normal")
            self.stop_record_button.configure(state="disabled")
        except Exception:
            pass
        self.record_status_var.set(f"SLOT {index + 1} RECORDING ERROR • {error}")
        self.set_status(f"Sequence Macro {index + 1} recording failed: {error}", "error")
        self.log_activity(f"Sequence Macro {index + 1} recording error: {error}", "error")
        self.play_sound("error")

    # ---------- slot regions ----------
    def select_slot_region(self, index):
        if self.running or self.recording:
            base.messagebox.showwarning("Busy", "Stop playback/recording before changing a target area.")
            return
        self.withdraw()
        self.after(250, lambda n=index: base.RegionSelector(self, lambda region: self._on_slot_region_selected(n, region)))

    def _on_slot_region_selected(self, index, region):
        slot = self._sequence_meta["slots"][index]
        slot["region"] = region
        slot["deactivated_reason"] = ""
        if self._slot_macros[index] is not None:
            slot["enabled"] = True
        self._save_sequence_meta()
        self.deiconify()
        self._refresh_sequence_ui()
        self.set_status(f"Sequence target area {index + 1} saved.", "idle")
        self.log_activity(f"Slot {index + 1} target area set to {region['width']}×{region['height']}", "info")

    def test_slot_detection(self, index):
        slot = self._sequence_meta["slots"][index]
        region = slot.get("region")
        if not region:
            base.messagebox.showwarning("No target area", f"Set target area {index + 1} first.")
            return
        try:
            with base.mss.mss() as sct:
                frame = base.np.array(sct.grab(region))[:, :, :3]
            secret_templates = self.load_templates(base.SECRET_DIR)
            mythic_templates = self.load_templates(base.MYTHIC_DIR)
            target = str(slot.get("stop_target", "BOTH")).upper()
            allowed = {"SECRET", "MYTHIC"} if target == "BOTH" else {target}
            kind, info, counts = self.detect_once(frame, secret_templates, mythic_templates, template_fallback=True, allowed_kinds=allowed)
            if kind:
                base.messagebox.showinfo("Detection test", f"Slot {index + 1}: detected {kind}.\n\n{info}")
            else:
                base.messagebox.showinfo(
                    "Detection test",
                    f"Slot {index + 1}: no selected rare detected.\nSECRET pixels: {counts.get('SECRET', 0)}\nMYTHIC pixels: {counts.get('MYTHIC', 0)}"
                )
        except Exception as exc:
            base.messagebox.showerror("Detection test", str(exc))

    # ---------- controls ----------
    def set_running_buttons(self, running):
        super().set_running_buttons(running)
        state = "disabled" if running else "normal"
        if hasattr(self, "sequence_mode_switch"):
            try:
                self.sequence_mode_switch.configure(state=state)
            except Exception:
                pass
        if self._seq_ui:
            for ui in self._seq_ui:
                for key in ("record", "region", "template", "test", "reactivate", "clear", "enable", "target"):
                    try:
                        ui[key].configure(state=state)
                    except Exception:
                        pass

    def start_controller(self):
        use_sequence = bool(self.sequence_mode_var.get()) if hasattr(self, "sequence_mode_var") else bool(self.cfg.get("sequence_mode", False))
        if not use_sequence:
            return super().start_controller()
        return self.start_sequence_controller()

    def start_sequence_controller(self):
        if self.running or self.recording:
            return
        try:
            self.save_settings()
            active = self._active_slot_indices()
            if not active:
                raise RuntimeError("Sequence Mode has no active configured slots. Each enabled slot needs both a recorded macro and a target area.")
            mismatches = []
            for i in active:
                ok, saved, current = self.validate_macro_environment(self._slot_macros[i])
                if not ok:
                    mismatches.append((i + 1, saved, current))
            if mismatches:
                details = "\n".join(f"Slot {n}: recorded {saved} • current {current}" for n, saved, current in mismatches)
                if not base.messagebox.askyesno(
                    "Display layout changed",
                    "One or more sequence macros were recorded on a different virtual desktop layout. Absolute coordinates may click the wrong place.\n\n"
                    + details + "\n\nContinue anyway?"
                ):
                    return
        except Exception as exc:
            self.play_sound("error")
            base.messagebox.showerror("Cannot start sequence", str(exc))
            return

        self.running = True
        self.cycles = 0
        self.active_loop_no = 0
        self.loop_durations.clear()
        self.session_start = time.perf_counter()
        self.stop_event.clear()
        self.rare_event.clear()
        self._rare_handled = False
        self.engine_error_message = None
        self._sequence_current_slot = -1
        self._sequence_slot_runs = 0
        self._sequence_rare_events = 0
        self.set_running_buttons(True)
        self.detector_var.set("SEQUENCE")
        self.set_scan_animation(True)
        self.stop_target_display_var.set("SEQUENCE • INDIVIDUAL SLOT TARGETS")
        self.set_status(f"Starting sequence with {len(active)} active macro slot(s).", "running")
        self.log_activity(f"v17 sequence engine started with {len(active)} active slot(s)", "info")
        self.play_sound("start")
        if bool(self.cfg.get("minimize_on_start", False)):
            self.after(80, self.iconify)
        threading.Thread(target=self.sequence_controller_loop, daemon=True).start()

    # ---------- sequence detector ----------
    def _slot_detector_loop(self, index, region, allowed, secret_templates, mythic_templates, rare_event, scan_end, result):
        try:
            _set_thread_below_normal()
            required = max(1, int(self.cfg.get("stable_frames", 2)))
            game_mode = bool(self.cfg.get("game_compatibility_mode", True))
            configured = int(self.cfg.get("scan_interval_ms", 30))
            interval = max(0.030 if game_mode else 0.008, configured / 1000.0)
            template_stride = max(2, int(self.cfg.get("template_scan_stride", 12 if game_mode else 3)))
            streak = 0
            streak_kind = None
            frame_no = 0
            with base.mss.mss() as sct:
                while self.running and not self.stop_event.is_set() and not scan_end.is_set():
                    frame = base.np.array(sct.grab(region))[:, :, :3]
                    frame_no += 1
                    kind, info, counts = self.detect_once(
                        frame, secret_templates, mythic_templates,
                        template_fallback=(frame_no % template_stride == 0), allowed_kinds=allowed
                    )
                    if self._sequence_current_slot == index:
                        self.last_secret_px = counts.get("SECRET", 0)
                        self.last_mythic_px = counts.get("MYTHIC", 0)
                    if kind and kind == streak_kind:
                        streak += 1
                    elif kind:
                        streak_kind, streak = kind, 1
                    else:
                        streak_kind, streak = None, 0
                    if kind and streak >= required:
                        result["kind"] = kind
                        result["info"] = info
                        rare_event.set()
                        return
                    scan_end.wait(interval)
        except Exception as exc:
            result["error"] = str(exc)
            rare_event.set()

    def _wait_sequence_deadline(self, deadline_ns, rare_event, high_precision=True):
        while not self.stop_event.is_set() and not rare_event.is_set():
            remaining = deadline_ns - time.perf_counter_ns()
            if remaining <= 0:
                return True
            if not high_precision:
                self.stop_event.wait(min(0.01, remaining / 1_000_000_000))
            elif remaining > 2_000_000:
                self.stop_event.wait(min(0.01, max(0.0, (remaining - 500_000) / 1_000_000_000)))
            elif remaining > 350_000:
                time.sleep(max(0.0, (remaining - 150_000) / 1_000_000_000))
            else:
                time.sleep(0)
        return False

    def replay_sequence_slot_once(self, injector, macro, timeline, rare_event):
        events = timeline or self.compile_replay_timeline(macro)
        if not events:
            return False
        speed = max(0.25, float(self.cfg.get("replay_speed", 1.0)))
        high_precision = bool(self.cfg.get("high_precision_timing", True))
        start_ns = time.perf_counter_ns()
        self._v15_last_injected_pos = None
        self._v15_button_down_at.clear()
        for ev in events:
            if self.stop_event.is_set() or rare_event.is_set():
                return False
            deadline = start_ns + int((float(ev.get("t", 0.0)) / speed) * 1_000_000_000)
            if not self._wait_sequence_deadline(deadline, rare_event, high_precision):
                return False
            if rare_event.is_set():
                return False
            self._send_event(injector, ev)
        original = macro.get("events", [])
        duration = float(macro.get("duration", original[-1].get("t", 0.0) if original else 0.0))
        self._wait_sequence_deadline(start_ns + int((duration / speed) * 1_000_000_000), rare_event, high_precision)
        return not self.stop_event.is_set() and not rare_event.is_set()

    def _deactivate_slot_for_rare(self, index, kind, info, pass_no):
        slot = self._sequence_meta["slots"][index]
        slot["enabled"] = False
        slot["rare_count"] = int(slot.get("rare_count", 0)) + 1
        stamp = base.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        slot["last_rare"] = f"{kind} • {stamp}"
        slot["deactivated_reason"] = f"{kind} detected on sequence pass {pass_no}. Slot automatically deactivated; other slots continue."
        self._save_sequence_meta()
        self.cfg["rare_finds"] = int(self.cfg.get("rare_finds", 0)) + 1
        self.cfg["last_rare"] = f"{kind} • Slot {index + 1} • {stamp}"
        base.save_config(self.cfg)
        self._sequence_rare_events += 1
        self.after(0, self._refresh_sequence_ui)
        self.after(0, lambda n=index + 1, k=kind, i=info: self.log_activity(f"Slot {n}: {k} detected ({i}) • slot deactivated, sequence continues", "rare"))
        self.after(0, lambda k=kind, n=index + 1: self.set_status(f"{k} found in Slot {n}. Slot {n} deactivated; continuing sequence.", "running"))
        self.after(0, lambda: self.play_sound("rare"))

    def sequence_controller_loop(self):
        injector = None
        try:
            if sys.platform != "win32":
                raise RuntimeError("Precision absolute replay requires Windows.")
            secret_templates = self.load_templates(base.SECRET_DIR)
            mythic_templates = self.load_templates(base.MYTHIC_DIR)
            game_mode = bool(self.cfg.get("game_compatibility_mode", True))
            injector = base.WindowsMouseInjector(no_coalesce=False if game_mode else bool(self.cfg.get("no_coalesce", True)))
            injector.refresh_bounds()
            timelines = {i: self.compile_replay_timeline(self._slot_macros[i]) for i in range(SEQUENCE_SLOT_COUNT) if self._slot_macros[i]}
            high_precision = bool(self.cfg.get("high_precision_timing", True))
            pass_gap = max(0.0, int(self.cfg.get("loop_gap_ms", 80)) / 1000.0)
            precheck = max(0.0, int(self.cfg.get("sequence_precheck_ms", 80)) / 1000.0)
            final_window = max(0.040, int(self.cfg.get("sequence_result_check_ms", 180)) / 1000.0)

            with base.TimerResolution(high_precision):
                while not self.stop_event.is_set():
                    active = self._active_slot_indices()
                    if not active:
                        self.after(0, lambda: self.finish_controller(
                            "Sequence finished: no active configured slots remain. Reactivate a slot from the Sequence page to use it again.",
                            "stopped", "stop"
                        ))
                        self.after(0, lambda: self.log_activity("Sequence stopped because no active slots remain", "stop"))
                        return
                    pass_start = time.perf_counter()
                    pass_no = self.cycles + 1
                    self.active_loop_no = pass_no
                    for index in list(active):
                        if self.stop_event.is_set():
                            break
                        if not self._slot_ready(index):
                            continue
                        slot = self._sequence_meta["slots"][index]
                        macro = self._slot_macros[index]
                        region = dict(slot.get("region"))
                        target = str(slot.get("stop_target", "BOTH")).upper()
                        allowed = {"SECRET", "MYTHIC"} if target == "BOTH" else {target}
                        self._sequence_current_slot = index
                        self.after(0, lambda n=index + 1, p=pass_no, t=target: self.set_status(
                            f"Sequence pass {p} • Slot {n}/10 • target {t}", "running"
                        ))
                        self.after(0, lambda n=index + 1: self.detector_var.set(f"SLOT {n}"))

                        rare_event = threading.Event()
                        scan_end = threading.Event()
                        result = {}
                        detector = threading.Thread(
                            target=self._slot_detector_loop,
                            args=(index, region, allowed, secret_templates, mythic_templates, rare_event, scan_end, result),
                            daemon=True
                        )
                        detector.start()

                        # Give an already-visible rare a chance to deactivate the slot before the macro can dismiss it.
                        if precheck > 0:
                            deadline = time.perf_counter_ns() + int(precheck * 1_000_000_000)
                            self._wait_sequence_deadline(deadline, rare_event, high_precision)
                        if result.get("error"):
                            scan_end.set()
                            raise RuntimeError(f"Slot {index + 1} detector error: {result['error']}")
                        if rare_event.is_set():
                            scan_end.set()
                            try:
                                injector.release_all()
                                if hasattr(self, "_release_all_keyboard"):
                                    self._release_all_keyboard()
                            except Exception:
                                pass
                            self._v15_button_down_at.clear()
                            self._deactivate_slot_for_rare(index, result.get("kind", "RARE"), result.get("info", "pre-check"), pass_no)
                            continue

                        completed = self.replay_sequence_slot_once(injector, macro, timelines.get(index, []), rare_event)
                        if rare_event.is_set():
                            try:
                                injector.release_all()
                                if hasattr(self, "_release_all_keyboard"):
                                    self._release_all_keyboard()
                            except Exception:
                                pass
                            self._v15_button_down_at.clear()
                        elif completed and final_window > 0:
                            deadline = time.perf_counter_ns() + int(final_window * 1_000_000_000)
                            self._wait_sequence_deadline(deadline, rare_event, high_precision)

                        scan_end.set()
                        detector.join(timeout=0.15)
                        if result.get("error"):
                            raise RuntimeError(f"Slot {index + 1} detector error: {result['error']}")
                        if rare_event.is_set() and result.get("kind"):
                            try:
                                injector.release_all()
                                if hasattr(self, "_release_all_keyboard"):
                                    self._release_all_keyboard()
                            except Exception:
                                pass
                            self._v15_button_down_at.clear()
                            self._deactivate_slot_for_rare(index, result["kind"], result.get("info", "detector"), pass_no)
                            continue
                        if self.stop_event.is_set():
                            break
                        if not completed:
                            break

                        self._sequence_slot_runs += 1
                        if self._sequence_slot_runs <= 5 or self._sequence_slot_runs % 20 == 0:
                            self.after(0, lambda n=index + 1, r=self._sequence_slot_runs: self.log_activity(
                                f"Sequence Slot {n} completed • total slot runs {r}", "cycle"
                            ))

                    if self.stop_event.is_set():
                        break
                    self.cycles += 1
                    pass_end = time.perf_counter()
                    self.loop_durations.append(max(0.001, pass_end - pass_start))
                    self.cfg["lifetime_cycles"] = int(self.cfg.get("lifetime_cycles", 0)) + 1
                    self.cfg["sequence_slot_runs"] = int(self.cfg.get("sequence_slot_runs", 0)) + self._sequence_slot_runs
                    self._stats_dirty = True
                    # reset per-save accumulator so lifetime slot runs aren't double-counted
                    self._sequence_slot_runs = 0
                    if pass_gap > 0:
                        deadline = time.perf_counter_ns() + int(pass_gap * 1_000_000_000)
                        if not efficient_wait_until(deadline, self.stop_event, high_precision):
                            break

            if not self.engine_error_message:
                self.after(0, lambda: self.finish_controller(
                    f"Sequence stopped by user after {self.cycles} completed pass(es).", "stopped", "stop"
                ))
                self.after(0, lambda: self.log_activity(f"Sequence stopped after {self.cycles} pass(es)", "stop"))
        except Exception as exc:
            self.engine_error_message = str(exc)
            self.stop_event.set()
            self.after(0, lambda err=str(exc): self.finish_controller(f"Sequence stopped because of an error: {err}", "error", "error"))
            self.after(0, lambda err=str(exc): self.log_activity(f"Sequence engine error: {err}", "error"))
        finally:
            self._sequence_current_slot = -1
            if injector is not None:
                try:
                    injector.release_all()
                    if hasattr(self, "_release_all_keyboard"):
                        self._release_all_keyboard()
                except Exception:
                    pass



CUSTOM_TEMPLATE_DIR = ROOT / "data" / "custom_templates"
CUSTOM_TEMPLATE_DIR.mkdir(parents=True, exist_ok=True)


class V17App(V16App):
    """Universal target-template + keyboard macro layer on top of the v16 sequence engine."""

    def __init__(self):
        self._custom_template_cache = {}
        self._record_keyboard_hook = None
        self._record_key_down = set()
        self._v17_held_keys = set()
        super().__init__()
        self.title(f"Roblox Auto Roll Selector • v{APP_VERSION}")
        self._apply_v17_migration()
        self._rebrand_visible_text()
        self._refresh_sequence_ui()
        self._refresh_custom_template_status()

    def _apply_v17_migration(self):
        changed = False
        defaults = {
            "record_keyboard_input": False,
            "custom_detection_enabled": False,
            "custom_template_path": "",
            "custom_template_name": "",
            "universal_profile_version": 17,
        }
        for key, value in defaults.items():
            if key not in self.cfg:
                self.cfg[key] = value
                changed = True
        if int(self.cfg.get("universal_profile_version", 0)) < 17:
            self.cfg["universal_profile_version"] = 17
            changed = True
        if changed:
            base.save_config(self.cfg)

    def _rebrand_visible_text(self):
        try:
            for widget in _all_widgets(self):
                if isinstance(widget, ctk.CTkLabel):
                    try:
                        current = str(widget.cget("text"))
                        if current == "Idle Mafia":
                            widget.configure(text="Roblox Auto Roll Selector")
                        elif "Idle Mafia" in current:
                            widget.configure(text=current.replace("Idle Mafia", "Roblox Auto Roll Selector"))
                    except Exception:
                        pass
        except Exception:
            pass

    # ---------- settings ----------
    def build_settings_page(self):
        super().build_settings_page()
        page = self.pages.get("Settings")
        if page is None:
            return
        self.record_keyboard_var = tk.BooleanVar(value=bool(self.cfg.get("record_keyboard_input", False)))
        card = ctk.CTkFrame(page, fg_color=base.SURFACE, corner_radius=15, border_width=1, border_color=base.BORDER)
        card.pack(fill="x", pady=(0, 14))
        ctk.CTkLabel(card, text="Macro input recording", text_color=base.TEXT,
                     font=ctk.CTkFont(size=15, weight="bold")).pack(anchor="w", padx=20, pady=(16, 4))
        ctk.CTkLabel(
            card,
            text="Mouse input is always recorded. Enable keyboard recording when the Roblox workflow also needs keys, movement controls, hotkeys or text input.",
            text_color=base.MUTED, wraplength=900, justify="left"
        ).pack(anchor="w", padx=20, pady=(0, 10))
        ctk.CTkSwitch(card, text="Record keyboard input with macros", variable=self.record_keyboard_var,
                      command=self._save_keyboard_recording_pref, progress_color=base.ACCENT,
                      button_color="white", button_hover_color="#ddd").pack(anchor="w", padx=20, pady=(0, 16))

    def _save_keyboard_recording_pref(self):
        self.cfg["record_keyboard_input"] = bool(self.record_keyboard_var.get())
        base.save_config(self.cfg)

    def save_settings(self):
        ok = super().save_settings()
        if hasattr(self, "record_keyboard_var"):
            self.cfg["record_keyboard_input"] = bool(self.record_keyboard_var.get())
        if hasattr(self, "custom_template_enabled_var"):
            self.cfg["custom_detection_enabled"] = bool(self.custom_template_enabled_var.get())
        base.save_config(self.cfg)
        return ok

    # ---------- universal template UI ----------
    def build_detection_page(self):
        super().build_detection_page()
        page = self.pages.get("Detection")
        if page is None:
            return
        self.custom_template_enabled_var = tk.BooleanVar(value=bool(self.cfg.get("custom_detection_enabled", False)))
        self.custom_template_name_var = tk.StringVar(value="")
        card = ctk.CTkFrame(page, fg_color=base.SURFACE, corner_radius=15, border_width=1, border_color=base.BORDER)
        card.pack(fill="x", pady=(0, 14))
        ctk.CTkLabel(card, text="Custom target image", text_color=base.TEXT,
                     font=ctk.CTkFont(size=15, weight="bold")).pack(anchor="w", padx=20, pady=(16, 4))
        ctk.CTkLabel(
            card,
            text=("Upload a screenshot crop of whatever result you want the macro to stop on. This makes detection game-independent. "
                  "Use a tight crop around a stable icon, word, badge or result graphic."),
            text_color=base.MUTED, wraplength=900, justify="left"
        ).pack(anchor="w", padx=20, pady=(0, 10))
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x", padx=20, pady=(0, 8))
        ctk.CTkSwitch(row, text="Use custom target for single-macro mode", variable=self.custom_template_enabled_var,
                      command=self._toggle_custom_detection, progress_color=base.ACCENT,
                      button_color="white", button_hover_color="#ddd").pack(side="left")
        ctk.CTkButton(row, text="Upload target image", width=145, height=34, corner_radius=9,
                      fg_color=base.ACCENT, hover_color=base.ACCENT_HOVER,
                      command=self.upload_global_template).pack(side="right")
        ctk.CTkButton(row, text="Clear", width=70, height=34, corner_radius=9,
                      fg_color=base.SURFACE_3, hover_color="#3b434b",
                      command=self.clear_global_template).pack(side="right", padx=(0, 8))
        ctk.CTkLabel(card, textvariable=self.custom_template_name_var, text_color=base.CYAN,
                     justify="left").pack(anchor="w", padx=20, pady=(0, 16))
        self._refresh_custom_template_status()

    def _refresh_custom_template_status(self):
        if not hasattr(self, "custom_template_name_var"):
            return
        path = Path(str(self.cfg.get("custom_template_path", ""))) if self.cfg.get("custom_template_path") else None
        if path and path.exists():
            name = self.cfg.get("custom_template_name") or path.name
            self.custom_template_name_var.set(f"Loaded target: {name} • threshold {float(self.cfg.get('match_threshold', 0.88)):.2f}")
        else:
            self.custom_template_name_var.set("No custom target image uploaded yet.")

    def _toggle_custom_detection(self):
        enabled = bool(self.custom_template_enabled_var.get())
        if enabled and not self._get_custom_template(self.cfg.get("custom_template_path", "")):
            self.custom_template_enabled_var.set(False)
            base.messagebox.showwarning("No target image", "Upload a custom target image first.")
            return
        self.cfg["custom_detection_enabled"] = bool(self.custom_template_enabled_var.get())
        base.save_config(self.cfg)

    @staticmethod
    def _copy_template_image(source, destination):
        source = Path(source)
        destination = Path(destination)
        destination.parent.mkdir(parents=True, exist_ok=True)
        # Normalize to PNG so OpenCV gets a predictable RGB/BGR file even if the upload is WEBP/JPEG.
        with Image.open(source) as im:
            im.convert("RGB").save(destination, format="PNG", optimize=True)
        return destination

    def upload_global_template(self):
        source = filedialog.askopenfilename(
            parent=self, title="Choose target image",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp"), ("All files", "*.*")]
        )
        if not source:
            return
        try:
            dest = self._copy_template_image(source, CUSTOM_TEMPLATE_DIR / "single_target.png")
            self._custom_template_cache.pop(str(dest), None)
            self.cfg["custom_template_path"] = str(dest)
            self.cfg["custom_template_name"] = Path(source).name
            self.cfg["custom_detection_enabled"] = True
            if hasattr(self, "custom_template_enabled_var"):
                self.custom_template_enabled_var.set(True)
            base.save_config(self.cfg)
            self._refresh_custom_template_status()
            self.set_status(f"Custom target image loaded: {Path(source).name}", "idle")
            self.log_activity(f"Custom target uploaded: {Path(source).name}", "info")
        except Exception as exc:
            base.messagebox.showerror("Target image", f"Could not import the image:\n{exc}")

    def clear_global_template(self):
        path = Path(str(self.cfg.get("custom_template_path", ""))) if self.cfg.get("custom_template_path") else None
        if path:
            try:
                path.unlink(missing_ok=True)
            except Exception:
                pass
        self.cfg["custom_template_path"] = ""
        self.cfg["custom_template_name"] = ""
        self.cfg["custom_detection_enabled"] = False
        if hasattr(self, "custom_template_enabled_var"):
            self.custom_template_enabled_var.set(False)
        base.save_config(self.cfg)
        self._custom_template_cache.clear()
        self._refresh_custom_template_status()

    def _get_custom_template(self, path_value):
        if not path_value:
            return None
        path = Path(str(path_value))
        if not path.exists():
            return None
        try:
            key = str(path.resolve())
            mtime = path.stat().st_mtime_ns
            cached = self._custom_template_cache.get(key)
            if cached and cached[0] == mtime:
                return cached[1]
            img = base.cv2.imread(str(path), base.cv2.IMREAD_COLOR)
            if img is None:
                return None
            self._custom_template_cache[key] = (mtime, img)
            return img
        except Exception:
            return None

    def _match_custom(self, frame, template, label="CUSTOM"):
        if template is None:
            return None, "custom target missing", 0.0
        score = self.match_template(frame, template)
        threshold = float(self.cfg.get("match_threshold", 0.88))
        if score >= threshold:
            return label, f"custom template {score:.3f}", score
        return None, f"custom template {score:.3f} / {threshold:.3f}", score

    # ---------- single-mode custom detector ----------
    def detector_loop(self, secret_templates, mythic_templates):
        custom_enabled = bool(self.cfg.get("custom_detection_enabled", False))
        custom_template = self._get_custom_template(self.cfg.get("custom_template_path", "")) if custom_enabled else None
        if not custom_enabled or custom_template is None:
            return super().detector_loop(secret_templates, mythic_templates)
        try:
            _set_thread_below_normal()
            required = max(1, int(self.cfg.get("stable_frames", 2)))
            game_mode = bool(self.cfg.get("game_compatibility_mode", True))
            interval = max(0.030 if game_mode else 0.008, int(self.cfg.get("scan_interval_ms", 30)) / 1000.0)
            streak = 0
            label = str(self.cfg.get("custom_template_name", "CUSTOM")) or "CUSTOM"
            with base.mss.mss() as sct:
                while self.running and not self.stop_event.is_set():
                    frame = self.grab_region(sct)
                    kind, info, _score = self._match_custom(frame, custom_template, label)
                    streak = streak + 1 if kind else 0
                    if kind and streak >= required:
                        self.rare_event.set()
                        self.stop_event.set()
                        cycle_no = max(0, self.active_loop_no)
                        self.after(0, lambda k=kind, i=info, n=cycle_no: self.record_rare(k, i, n))
                        self.after(0, lambda k=kind, i=info, n=cycle_no: self.finish_controller(
                            f"TARGET FOUND: {k} detected on loop {n} ({i}). Replay was cancelled before later events could run.",
                            "rare", "rare"
                        ))
                        return
                    self.stop_event.wait(interval)
        except Exception as exc:
            if self.running and not self.stop_event.is_set():
                self.engine_error_message = str(exc)
                self.stop_event.set()
                self.after(0, lambda err=str(exc): self.finish_controller(f"Detector error: {err}", "error", "error"))

    def test_detection(self):
        if not bool(self.cfg.get("custom_detection_enabled", False)):
            return super().test_detection()
        try:
            self.save_settings()
            template = self._get_custom_template(self.cfg.get("custom_template_path", ""))
            if template is None:
                raise RuntimeError("Upload a custom target image first.")
            frame = self.grab_region()
            label = str(self.cfg.get("custom_template_name", "CUSTOM")) or "CUSTOM"
            kind, info, score = self._match_custom(frame, template, label)
            if kind:
                self.detector_var.set("TARGET")
                self.set_status(f"TEST SUCCESS: custom target detected ({info}).", "rare")
                self.play_sound("rare")
                base.messagebox.showinfo("Detection test", f"Custom target detected.\n\nScore: {score:.3f}")
            else:
                self.detector_var.set("NORMAL")
                self.set_status(f"Custom target not detected ({info}).", "idle")
                base.messagebox.showinfo("Detection test", f"No custom target match.\n\nScore: {score:.3f}")
        except Exception as exc:
            base.messagebox.showerror("Detection test", str(exc))

    # ---------- per-slot custom targets ----------
    def upload_slot_template(self, index):
        if self.running or self.recording:
            base.messagebox.showwarning("Busy", "Stop playback/recording before changing a target image.")
            return
        source = filedialog.askopenfilename(
            parent=self, title=f"Choose target image for Slot {index + 1}",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp"), ("All files", "*.*")]
        )
        if not source:
            return
        try:
            dest = self._copy_template_image(source, CUSTOM_TEMPLATE_DIR / f"slot_{index + 1:02d}.png")
            self._custom_template_cache.pop(str(dest), None)
            slot = self._sequence_meta["slots"][index]
            slot["custom_template"] = str(dest)
            slot["custom_template_name"] = Path(source).name
            slot["stop_target"] = "CUSTOM"
            slot["deactivated_reason"] = ""
            if self._slot_macros[index] is not None and slot.get("region"):
                slot["enabled"] = True
            self._save_sequence_meta()
            self._refresh_sequence_ui()
            self.set_status(f"Slot {index + 1} target image loaded: {Path(source).name}", "idle")
        except Exception as exc:
            base.messagebox.showerror("Target image", f"Could not import the image:\n{exc}")

    def _set_slot_target(self, index, value):
        target = str(value).upper()
        if target not in {"BOTH", "SECRET", "MYTHIC", "CUSTOM"}:
            target = "BOTH"
        self._sequence_meta["slots"][index]["stop_target"] = target
        self._sequence_meta["slots"][index]["deactivated_reason"] = ""
        self._save_sequence_meta()
        self._refresh_sequence_ui()

    def _slot_config_complete(self, index):
        slot = self._sequence_meta["slots"][index]
        if self._slot_macros[index] is None or not slot.get("region"):
            return False
        if str(slot.get("stop_target", "BOTH")).upper() == "CUSTOM":
            return self._get_custom_template(slot.get("custom_template", "")) is not None
        return True

    def _slot_ready(self, index):
        return bool(self._sequence_meta["slots"][index].get("enabled")) and self._slot_config_complete(index)

    def _configured_slot_count(self):
        return sum(1 for i in range(SEQUENCE_SLOT_COUNT) if self._slot_config_complete(i))

    def reactivate_slot(self, index):
        if self.running or self.recording:
            return
        if not self._slot_config_complete(index):
            base.messagebox.showwarning("Incomplete slot", f"Slot {index + 1} needs a macro, target area, and a target image when CUSTOM is selected.")
            return
        slot = self._sequence_meta["slots"][index]
        slot["enabled"] = True
        slot["deactivated_reason"] = ""
        self._save_sequence_meta()
        self._refresh_sequence_ui()
        self.log_activity(f"Sequence Slot {index + 1} reactivated", "info")

    def reactivate_all_slots(self):
        if self.running or self.recording:
            return
        count = 0
        for i, slot in enumerate(self._sequence_meta["slots"]):
            if self._slot_config_complete(i):
                slot["enabled"] = True
                slot["deactivated_reason"] = ""
                count += 1
        self._save_sequence_meta()
        self._refresh_sequence_ui()
        self.log_activity(f"Reactivated {count} configured sequence slot(s)", "info")

    def clear_slot(self, index):
        template_path = str(self._sequence_meta["slots"][index].get("custom_template", ""))
        super().clear_slot(index)
        # Only delete the target file if the slot really was cleared (not if user cancelled).
        if self._slot_macros[index] is None and not self._sequence_meta["slots"][index].get("region") and template_path:
            try:
                Path(template_path).unlink(missing_ok=True)
            except Exception:
                pass
            self._custom_template_cache.pop(template_path, None)

    def _refresh_sequence_ui(self):
        if not self._seq_ui:
            return
        active = 0
        configured = 0
        for i, ui in enumerate(self._seq_ui):
            slot = self._sequence_meta["slots"][i]
            macro = self._slot_macros[i]
            region = slot.get("region")
            ready_config = self._slot_config_complete(i)
            configured += 1 if ready_config else 0
            is_active = bool(slot.get("enabled")) and ready_config
            active += 1 if is_active else 0
            ui["enabled_var"].set(bool(slot.get("enabled", False)))
            ui["target_var"].set(str(slot.get("stop_target", "BOTH")))
            if macro:
                stats = self.macro_stats(macro)
                key_text = f" • {stats.get('keys', 0)} key presses" if stats.get("keys", 0) else ""
                ui["macro_var"].set(
                    f"Macro: {stats['duration']:.3f}s • {stats['events']} events • {stats['moves']} move anchors • {stats['clicks']} clicks{key_text}"
                )
            else:
                ui["macro_var"].set("Macro: not recorded")
            if region:
                ui["region_var"].set(
                    f"Target area: {region.get('width','?')}×{region.get('height','?')} • x={region.get('left','?')} y={region.get('top','?')} • mode {slot.get('stop_target','BOTH')}"
                )
            else:
                ui["region_var"].set("Target area: not set")
            tname = slot.get("custom_template_name") or Path(str(slot.get("custom_template", ""))).name if slot.get("custom_template") else ""
            ui["template_var"].set(f"Custom target: {tname}" if tname else "Custom target: not uploaded")
            reason = str(slot.get("deactivated_reason", ""))
            ui["reason_var"].set(reason if reason else " ")
            if is_active:
                ui["status_var"].set("ACTIVE")
                ui["status"].configure(text_color=base.SUCCESS, fg_color="#18322d")
            elif reason:
                ui["status_var"].set("TARGET • OFF")
                ui["status"].configure(text_color=base.WARNING, fg_color="#332817")
            elif not ready_config:
                ui["status_var"].set("INCOMPLETE")
                ui["status"].configure(text_color=base.MUTED, fg_color=base.SURFACE_2)
            else:
                ui["status_var"].set("DISABLED")
                ui["status"].configure(text_color=base.MUTED, fg_color=base.SURFACE_2)
        mode = bool(self.sequence_mode_var.get()) if hasattr(self, "sequence_mode_var") else bool(self.cfg.get("sequence_mode", False))
        self.sequence_summary_var.set(f"{'SEQUENCE ON' if mode else 'SEQUENCE OFF'} • {active} active / {configured} configured")

    def test_slot_detection(self, index):
        slot = self._sequence_meta["slots"][index]
        region = slot.get("region")
        if not region:
            base.messagebox.showwarning("No target area", f"Set target area {index + 1} first.")
            return
        target = str(slot.get("stop_target", "BOTH")).upper()
        if target != "CUSTOM":
            return super().test_slot_detection(index)
        try:
            template = self._get_custom_template(slot.get("custom_template", ""))
            if template is None:
                raise RuntimeError("Upload a custom target image for this slot first.")
            with base.mss.mss() as sct:
                frame = base.np.array(sct.grab(region))[:, :, :3]
            label = str(slot.get("custom_template_name", "CUSTOM")) or "CUSTOM"
            kind, info, score = self._match_custom(frame, template, label)
            if kind:
                base.messagebox.showinfo("Detection test", f"Slot {index + 1}: custom target detected.\n\nScore: {score:.3f}")
            else:
                base.messagebox.showinfo("Detection test", f"Slot {index + 1}: target not detected.\n\nScore: {score:.3f}\n{info}")
        except Exception as exc:
            base.messagebox.showerror("Detection test", str(exc))

    def _slot_detector_loop(self, index, region, allowed, secret_templates, mythic_templates, rare_event, scan_end, result):
        slot = self._sequence_meta["slots"][index]
        target = str(slot.get("stop_target", "BOTH")).upper()
        if target != "CUSTOM":
            return super()._slot_detector_loop(index, region, allowed, secret_templates, mythic_templates, rare_event, scan_end, result)
        try:
            _set_thread_below_normal()
            template = self._get_custom_template(slot.get("custom_template", ""))
            if template is None:
                raise RuntimeError(f"Slot {index + 1} custom target image is missing.")
            required = max(1, int(self.cfg.get("stable_frames", 2)))
            game_mode = bool(self.cfg.get("game_compatibility_mode", True))
            interval = max(0.030 if game_mode else 0.008, int(self.cfg.get("scan_interval_ms", 30)) / 1000.0)
            label = str(slot.get("custom_template_name", "CUSTOM")) or "CUSTOM"
            streak = 0
            with base.mss.mss() as sct:
                while self.running and not self.stop_event.is_set() and not scan_end.is_set():
                    frame = base.np.array(sct.grab(region))[:, :, :3]
                    kind, info, _score = self._match_custom(frame, template, label)
                    streak = streak + 1 if kind else 0
                    if kind and streak >= required:
                        result["kind"] = label
                        result["info"] = info
                        rare_event.set()
                        return
                    scan_end.wait(interval)
        except Exception as exc:
            result["error"] = str(exc)
            rare_event.set()

    # ---------- keyboard recording/replay ----------
    def macro_stats(self, macro=None):
        stats = super().macro_stats(macro)
        selected = macro or self.macro
        events = selected.get("events", []) if selected else []
        stats["keys"] = sum(1 for e in events if e.get("type") == "key" and e.get("pressed"))
        return stats

    def _send_event(self, injector, ev):
        if ev.get("type") == "key":
            key = str(ev.get("key", "")).strip()
            if not key:
                return
            pressed = bool(ev.get("pressed"))
            try:
                if pressed:
                    base.keyboard.press(key)
                    self._v17_held_keys.add(key)
                else:
                    base.keyboard.release(key)
                    self._v17_held_keys.discard(key)
            except Exception as exc:
                self.log_activity(f"Keyboard replay skipped unsupported key '{key}': {exc}", "error")
            return
        return super()._send_event(injector, ev)

    def _release_all_keyboard(self):
        for key in list(self._v17_held_keys):
            try:
                base.keyboard.release(key)
            except Exception:
                pass
        self._v17_held_keys.clear()

    @staticmethod
    def _stop_hotkey_parts(hotkey):
        value = str(hotkey).lower().replace(" ", "")
        return {part for part in value.split("+") if part}

    def start_recording(self):
        if self.running:
            base.messagebox.showwarning("Macro running", "Stop playback before recording a new macro.")
            return
        if self.recording:
            return
        try:
            self.save_settings()
        except Exception as exc:
            base.messagebox.showerror("Settings", str(exc))
            return
        hotkey = self.cfg.get("record_stop_hotkey", "f9")
        countdown = max(1, int(self.cfg.get("record_countdown_s", 2)))
        keyboard_on = bool(self.cfg.get("record_keyboard_input", False))
        inputs = "mouse + keyboard" if keyboard_on else "mouse"
        if not base.messagebox.askyesno(
            "Record new macro",
            f"The app stays open. Recording starts after the {countdown}-second Engine-status countdown.\n\n"
            f"Capturing: {inputs}.\nPress {hotkey.upper()} to stop recording.\n\nRecord one complete cycle. Continue?",
        ):
            return
        self.recording = True
        self.record_stop_event.clear()
        self.record_events = []
        self.record_screen = base.virtual_screen_bounds()
        try:
            self.record_button.configure(state="disabled")
            self.stop_record_button.configure(state="normal")
        except Exception:
            pass
        self._set_record_countdown_status(float(countdown), hotkey)
        self.log_activity(f"Recording countdown started ({countdown}s) • {inputs}", "record")
        self.play_sound("start")
        threading.Thread(target=self._record_worker, args=(countdown, hotkey), daemon=True).start()

    def _record_worker(self, countdown, hotkey):
        mouse_listener = None
        keyboard_hook = None
        try:
            _set_thread_below_normal()
            deadline = time.perf_counter() + float(countdown)
            last_tenth = None
            while True:
                if self.record_stop_event.is_set():
                    raise RuntimeError("Recording cancelled before capture started.")
                remaining = deadline - time.perf_counter()
                if remaining <= 0:
                    break
                tenth = math.ceil((remaining - 1e-6) * 10.0) / 10.0
                tenth = max(0.1, min(float(countdown), tenth))
                if tenth != last_tenth:
                    last_tenth = tenth
                    self.after(0, lambda r=tenth, h=hotkey: self._set_record_countdown_status(r, h))
                self.record_stop_event.wait(min(0.045, max(0.0, remaining)))

            self.record_start_perf = time.perf_counter()
            key_down = set()
            stop_parts = self._stop_hotkey_parts(hotkey)

            def now_t():
                return time.perf_counter() - self.record_start_perf

            def on_move(x, y):
                if not self.recording or self.record_stop_event.is_set():
                    return False
                self.record_events.append({"t": now_t(), "type": "move", "x": int(x), "y": int(y)})

            def on_click(x, y, button, pressed):
                if not self.recording or self.record_stop_event.is_set():
                    return False
                self.record_events.append({
                    "t": now_t(), "type": "button", "x": int(x), "y": int(y),
                    "button": self._button_name(button), "pressed": bool(pressed),
                })

            def on_scroll(x, y, dx, dy):
                if not self.recording or self.record_stop_event.is_set():
                    return False
                self.record_events.append({
                    "t": now_t(), "type": "scroll", "x": int(x), "y": int(y), "dx": int(dx), "dy": int(dy),
                })

            def on_key(event):
                if not self.recording or self.record_stop_event.is_set():
                    return
                name = str(getattr(event, "name", "") or "").lower().strip()
                if not name or name.replace(" ", "") in stop_parts:
                    return
                pressed = str(getattr(event, "event_type", "")) == "down"
                # Suppress OS repeat downs: replay the real held duration instead of flooding Roblox.
                if pressed:
                    if name in key_down:
                        return
                    key_down.add(name)
                else:
                    if name not in key_down:
                        return
                    key_down.discard(name)
                self.record_events.append({"t": now_t(), "type": "key", "key": name, "pressed": pressed})

            mouse_listener = base.pynput_mouse.Listener(on_move=on_move, on_click=on_click, on_scroll=on_scroll)
            self.record_listener = mouse_listener
            mouse_listener.start()
            if bool(self.cfg.get("record_keyboard_input", False)):
                keyboard_hook = base.keyboard.hook(on_key, suppress=False)
                self._record_keyboard_hook = keyboard_hook
            try:
                self.record_stop_handle = base.keyboard.add_hotkey(hotkey, lambda: self.after(0, self.stop_recording), suppress=False)
            except Exception:
                self.record_stop_handle = None

            input_text = "mouse + keyboard" if bool(self.cfg.get("record_keyboard_input", False)) else "mouse"
            self.after(0, lambda: self.record_status_var.set(f"RECORDING LIVE • {input_text} • stop with {hotkey.upper()}"))
            self.after(0, lambda: self.set_status(f"Recording {input_text} events • press {hotkey.upper()} to finish.", "recording"))
            self.after(0, lambda: self.status_short_var.set("RECORDING"))
            self.after(0, lambda: self.log_activity(f"{input_text.title()} capture started", "record"))

            while self.recording and not self.record_stop_event.wait(0.02):
                pass

            # Balance held keys at recording end so playback can never leave a key stuck down.
            end_t = now_t()
            for name in sorted(key_down):
                self.record_events.append({"t": end_t, "type": "key", "key": name, "pressed": False})
            key_down.clear()

            events = list(self.record_events)
            if not events:
                raise RuntimeError("No input events were recorded.")
            events.sort(key=lambda e: e.get("t", 0.0))
            if bool(self.cfg.get("trim_recording_start", True)):
                offset = float(events[0].get("t", 0.0))
                for e in events:
                    e["t"] = max(0.0, float(e.get("t", 0.0)) - offset)
            duration = float(events[-1].get("t", 0.0))
            macro = {
                "version": 3,
                "recorded_at": base.datetime.now().isoformat(timespec="seconds"),
                "screen": self.record_screen,
                "duration": duration,
                "includes_keyboard": bool(self.cfg.get("record_keyboard_input", False)),
                "events": events,
            }
            self.save_macro(macro)
            self.after(0, self._record_success_ui)
        except Exception as exc:
            self.after(0, lambda err=str(exc): self._record_error_ui(err))
        finally:
            try:
                if mouse_listener is not None:
                    mouse_listener.stop()
                    mouse_listener.join(timeout=1.0)
            except Exception:
                pass
            if keyboard_hook is not None:
                try:
                    base.keyboard.unhook(keyboard_hook)
                except Exception:
                    pass
            self._record_keyboard_hook = None
            if self.record_stop_handle is not None:
                try:
                    base.keyboard.remove_hotkey(self.record_stop_handle)
                except Exception:
                    pass
                self.record_stop_handle = None
            self.recording = False
            self.record_listener = None
            self.record_start_perf = None
            self.record_stop_event.clear()

    def finish_controller(self, message, state="stopped", sound=None):
        self._release_all_keyboard()
        return super().finish_controller(message, state, sound)

    def on_close(self):
        self._release_all_keyboard()
        try:
            if self._record_keyboard_hook is not None:
                base.keyboard.unhook(self._record_keyboard_hook)
        except Exception:
            pass
        return super().on_close()



POPUP_TEMPLATE_DIR = ROOT / "data" / "popup_templates"
POPUP_TEMPLATE_DIR.mkdir(parents=True, exist_ok=True)


def _popup_macro_path(index):
    return ROOT / "data" / f"popup_action_macro_{index + 1}.json"


class V171App(V17App):
    """v17.1: smarter custom matching, per-slot popup recovery, and refreshed UI."""

    def __init__(self):
        # Apply the refreshed palette before the inherited UI is constructed.
        try:
            base.BG = "#080B10"
            base.SURFACE = "#10151D"
            base.SURFACE_2 = "#161D28"
            base.SURFACE_3 = "#202A38"
            base.BORDER = "#2A3545"
            base.TEXT = "#F4F7FB"
            base.MUTED = "#8F9BAD"
            base.ACCENT = "#8B5CF6"
            base.ACCENT_HOVER = "#7C3AED"
            base.CYAN = "#C084FC"
            base.SUCCESS = "#42D39A"
            base.WARNING = "#FFCA5C"
        except Exception:
            pass
        self._record_popup_slot = None
        self._popup_macros = []
        self._v171_popup_handling = False
        self._v171_popup_last_action = {}
        self._v171_match_breakdown = {}
        super().__init__()
        self._apply_v171_migration()
        self._popup_macros = [self._load_popup_macro(i) for i in range(SEQUENCE_SLOT_COUNT)]
        self._augment_sequence_popup_ui()
        self._apply_modern_polish()
        self._refresh_sequence_ui()
        self.title(f"Roblox Auto Roll Selector • v{APP_VERSION}")

    # ---------- migration / settings ----------
    def _apply_v171_migration(self):
        changed = False
        defaults = {
            "custom_match_threshold": 0.82,
            "custom_scale_tolerance_pct": 6,
            "popup_match_threshold": 0.80,
            "popup_watch_after_ms": 900,
            "popup_cooldown_ms": 450,
            "smart_detection_version": 2,
        }
        for key, value in defaults.items():
            if key not in self.cfg:
                self.cfg[key] = value
                changed = True
        for slot in self._sequence_meta.get("slots", []):
            slot_defaults = {
                "popup_enabled": False,
                "popup_region": None,
                "popup_template": "",
                "popup_template_name": "",
                "popup_count": 0,
                "popup_last": "Never",
            }
            for key, value in slot_defaults.items():
                if key not in slot:
                    slot[key] = value
                    changed = True
        if changed:
            base.save_config(self.cfg)
            self._save_sequence_meta()

    def build_detection_page(self):
        super().build_detection_page()
        page = self.pages.get("Detection")
        if page is None:
            return
        self.smart_threshold_var = tk.DoubleVar(value=float(self.cfg.get("custom_match_threshold", 0.82)))
        self.smart_scale_var = tk.IntVar(value=int(self.cfg.get("custom_scale_tolerance_pct", 6)))
        card = ctk.CTkFrame(page, fg_color="#111923", corner_radius=18, border_width=1, border_color="#2A3545")
        card.pack(fill="x", pady=(0, 14))
        top = ctk.CTkFrame(card, fg_color="transparent")
        top.pack(fill="x", padx=20, pady=(17, 4))
        ctk.CTkLabel(top, text="SMART TARGET RECOGNITION", text_color="#C084FC",
                     font=ctk.CTkFont(size=11, weight="bold")).pack(side="left")
        ctk.CTkLabel(top, text="v17.1.2 vision stack", text_color="#8F9BAD",
                     font=ctk.CTkFont(size=11)).pack(side="right")
        ctk.CTkLabel(card, text="Structure + colour + text/edge matching", text_color="#F4F7FB",
                     font=ctk.CTkFont(size=17, weight="bold")).pack(anchor="w", padx=20, pady=(2, 3))
        ctk.CTkLabel(
            card,
            text=("Custom templates are compared in several ways at once. Grayscale structure handles lighting shifts, RGB colour matching protects colour-specific results, "
                  "and an edge/text channel makes labels and lettering easier to recognize. Text is matched visually as letter shapes; this is not semantic OCR."),
            text_color="#8F9BAD", wraplength=900, justify="left"
        ).pack(anchor="w", padx=20, pady=(0, 12))
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x", padx=20, pady=(0, 7))
        ctk.CTkLabel(row, text="Smart match threshold", text_color="#AAB4C2").pack(side="left")
        self.smart_threshold_label = ctk.CTkLabel(row, text=f"{self.smart_threshold_var.get():.2f}", width=48,
                                                   text_color="#C084FC", font=ctk.CTkFont(weight="bold"))
        self.smart_threshold_label.pack(side="right")
        slider = ctk.CTkSlider(card, from_=0.65, to=0.95, number_of_steps=30, variable=self.smart_threshold_var,
                               command=self._on_smart_threshold_changed, progress_color="#8B5CF6",
                               button_color="#8B5CF6", button_hover_color="#7C3AED")
        slider.pack(fill="x", padx=20, pady=(0, 12))
        scale_row = ctk.CTkFrame(card, fg_color="transparent")
        scale_row.pack(fill="x", padx=20, pady=(0, 16))
        ctk.CTkLabel(scale_row, text="UI scale tolerance", text_color="#AAB4C2").pack(side="left")
        ctk.CTkSegmentedButton(scale_row, values=["0%", "4%", "6%", "10%"],
                               command=self._set_scale_tolerance,
                               selected_color="#8B5CF6", selected_hover_color="#7C3AED",
                               unselected_color="#202A38", unselected_hover_color="#2B3747").pack(side="right")

    def _on_smart_threshold_changed(self, _value=None):
        value = float(self.smart_threshold_var.get())
        if hasattr(self, "smart_threshold_label"):
            self.smart_threshold_label.configure(text=f"{value:.2f}")
        self.cfg["custom_match_threshold"] = value
        base.save_config(self.cfg)

    def _set_scale_tolerance(self, value):
        try:
            pct = int(str(value).replace("%", ""))
        except Exception:
            pct = 6
        self.cfg["custom_scale_tolerance_pct"] = pct
        if hasattr(self, "smart_scale_var"):
            self.smart_scale_var.set(pct)
        base.save_config(self.cfg)

    def save_settings(self):
        ok = super().save_settings()
        if hasattr(self, "smart_threshold_var"):
            self.cfg["custom_match_threshold"] = float(self.smart_threshold_var.get())
        if hasattr(self, "smart_scale_var"):
            self.cfg["custom_scale_tolerance_pct"] = int(self.smart_scale_var.get())
        base.save_config(self.cfg)
        return ok

    def _refresh_custom_template_status(self):
        if not hasattr(self, "custom_template_name_var"):
            return
        path = Path(str(self.cfg.get("custom_template_path", ""))) if self.cfg.get("custom_template_path") else None
        if path and path.exists():
            name = self.cfg.get("custom_template_name") or path.name
            threshold = float(self.cfg.get("custom_match_threshold", 0.82))
            scale = int(self.cfg.get("custom_scale_tolerance_pct", 6))
            self.custom_template_name_var.set(f"Loaded target: {name} • smart threshold {threshold:.2f} • scale ±{scale}%")
        else:
            self.custom_template_name_var.set("No custom target image uploaded yet.")

    def test_detection(self):
        if not bool(self.cfg.get("custom_detection_enabled", False)):
            return super().test_detection()
        try:
            self.save_settings()
            template = self._get_custom_template(self.cfg.get("custom_template_path", ""))
            if template is None:
                raise RuntimeError("Upload a custom target image first.")
            frame = self.grab_region()
            label = str(self.cfg.get("custom_template_name", "CUSTOM")) or "CUSTOM"
            kind, info, score = self._match_custom(frame, template, label)
            self.detector_var.set("TARGET" if kind else "NORMAL")
            if kind:
                self.set_status(f"TEST SUCCESS: custom target detected ({info}).", "rare")
                self.play_sound("rare")
            else:
                self.set_status(f"Custom target not detected ({info}).", "idle")
            base.messagebox.showinfo(
                "Smart detection test",
                f"{'Target detected' if kind else 'Target not detected'}\n\nOverall score: {score:.3f}\n{info}\n\n"
                "Tip: use a tight crop containing distinctive text, colour, icon edges, or all three."
            )
        except Exception as exc:
            base.messagebox.showerror("Detection test", str(exc))

    def test_slot_detection(self, index):
        slot = self._sequence_meta["slots"][index]
        if str(slot.get("stop_target", "BOTH")).upper() != "CUSTOM":
            return super().test_slot_detection(index)
        region = slot.get("region")
        if not region:
            base.messagebox.showwarning("No target area", f"Set target area {index + 1} first.")
            return
        try:
            template = self._get_custom_template(slot.get("custom_template", ""))
            if template is None:
                raise RuntimeError("Upload a custom target image for this slot first.")
            with base.mss.mss() as sct:
                frame = base.np.array(sct.grab(region))[:, :, :3]
            label = str(slot.get("custom_template_name", "CUSTOM")) or "CUSTOM"
            kind, info, score = self._match_custom(frame, template, label)
            base.messagebox.showinfo(
                "Smart slot detection",
                f"Slot {index + 1}: {'target detected' if kind else 'target not detected'}\n\nOverall score: {score:.3f}\n{info}"
            )
        except Exception as exc:
            base.messagebox.showerror("Detection test", str(exc))

    # ---------- smarter visual matching ----------
    @staticmethod
    def _safe_match_score(frame, template):
        if frame is None or template is None:
            return 0.0
        fh, fw = frame.shape[:2]
        th, tw = template.shape[:2]
        if th < 3 or tw < 3 or th > fh or tw > fw:
            return 0.0
        try:
            result = base.cv2.matchTemplate(frame, template, base.cv2.TM_CCOEFF_NORMED)
            score = float(base.np.nanmax(result)) if result.size else 0.0
            if not math.isfinite(score):
                raise ValueError("non-finite score")
            return max(0.0, min(1.0, score))
        except Exception:
            try:
                result = base.cv2.matchTemplate(frame, template, base.cv2.TM_CCORR_NORMED)
                score = float(base.np.nanmax(result)) if result.size else 0.0
                return max(0.0, min(1.0, score if math.isfinite(score) else 0.0))
            except Exception:
                return 0.0

    def _match_custom(self, frame, template, label="CUSTOM", threshold=None):
        if frame is None or template is None:
            return None, "template missing", 0.0
        try:
            frame_bgr = base.np.ascontiguousarray(frame[:, :, :3])
            template_bgr = base.np.ascontiguousarray(template[:, :, :3])
            frame_gray = base.cv2.cvtColor(frame_bgr, base.cv2.COLOR_BGR2GRAY)
            template_gray = base.cv2.cvtColor(template_bgr, base.cv2.COLOR_BGR2GRAY)
            tolerance = max(0, min(12, int(self.cfg.get("custom_scale_tolerance_pct", 6)))) / 100.0
            scales = [1.0]
            if tolerance > 0:
                scales = [1.0 - tolerance, 1.0, 1.0 + tolerance]
            best = None
            for scale in scales:
                if scale <= 0:
                    continue
                if abs(scale - 1.0) < 1e-6:
                    tg = template_gray
                    tb = template_bgr
                else:
                    tw = max(4, int(round(template_gray.shape[1] * scale)))
                    th = max(4, int(round(template_gray.shape[0] * scale)))
                    if tw > frame_gray.shape[1] or th > frame_gray.shape[0]:
                        continue
                    interp = base.cv2.INTER_AREA if scale < 1.0 else base.cv2.INTER_LINEAR
                    tg = base.cv2.resize(template_gray, (tw, th), interpolation=interp)
                    tb = base.cv2.resize(template_bgr, (tw, th), interpolation=interp)
                structure = self._safe_match_score(frame_gray, tg)
                if best is None or structure > best[0]:
                    best = (structure, scale, tg, tb)
            if best is None:
                return None, "template is larger than the selected target area", 0.0
            structure, scale, tg, tb = best

            # Colour is evaluated only at the best structural scale to keep CPU impact low.
            colour = self._safe_match_score(frame_bgr, tb)
            frame_edges = base.cv2.Canny(frame_gray, 55, 145)
            template_edges = base.cv2.Canny(tg, 55, 145)
            edge_pixels = int(base.np.count_nonzero(template_edges))
            edge = self._safe_match_score(frame_edges, template_edges) if edge_pixels >= 8 else structure

            # Weighted ensemble: robust to brightness changes while still caring about colour and lettering/icon outlines.
            score = (0.50 * structure) + (0.30 * colour) + (0.20 * edge)
            score = max(0.0, min(1.0, float(score)))
            limit = float(self.cfg.get("custom_match_threshold", 0.82) if threshold is None else threshold)
            self._v171_match_breakdown = {
                "score": score, "structure": structure, "colour": colour, "edge": edge, "scale": scale, "threshold": limit
            }
            info = (f"smart {score:.3f} / {limit:.3f} • structure {structure:.3f} • colour {colour:.3f} • "
                    f"text/edge {edge:.3f} • scale {scale:.3f}x")
            return (label, info, score) if score >= limit else (None, info, score)
        except Exception as exc:
            return None, f"smart detection error: {exc}", 0.0

    # ---------- popup handler persistence ----------
    def _load_popup_macro(self, index):
        path = _popup_macro_path(index)
        try:
            if path.exists():
                data = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(data, dict) and isinstance(data.get("events"), list):
                    return data
        except Exception:
            pass
        return None

    def _save_popup_macro(self, index, macro):
        path = _popup_macro_path(index)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(macro, separators=(",", ":")), encoding="utf-8")
        while len(self._popup_macros) < SEQUENCE_SLOT_COUNT:
            self._popup_macros.append(None)
        self._popup_macros[index] = macro

    def _popup_complete(self, index):
        if not self._popup_macros or index >= len(self._popup_macros):
            return False
        slot = self._sequence_meta["slots"][index]
        return bool(slot.get("popup_region")) and self._get_custom_template(slot.get("popup_template", "")) is not None and self._popup_macros[index] is not None

    # ---------- popup handler UI ----------
    def _augment_sequence_popup_ui(self):
        if not self._seq_ui:
            return
        for i, ui in enumerate(self._seq_ui):
            slot = self._sequence_meta["slots"][i]
            try:
                card = ui["record"].master.master
            except Exception:
                continue
            popup_row = ctk.CTkFrame(card, fg_color="#0D131B", corner_radius=11, border_width=1, border_color="#253246")
            popup_row.pack(fill="x", padx=18, pady=(0, 9))
            enabled_var = tk.BooleanVar(value=bool(slot.get("popup_enabled", False)))
            switch = ctk.CTkSwitch(popup_row, text="Popup recovery", variable=enabled_var,
                                   command=lambda n=i: self._toggle_popup_handler(n), progress_color="#C084FC",
                                   button_color="white", button_hover_color="#DCE5EE")
            switch.pack(side="left", padx=(12, 10), pady=10)
            upload = ctk.CTkButton(popup_row, text="Upload popup", width=104, height=30, corner_radius=8,
                                   fg_color="#202A38", hover_color="#2B3747",
                                   command=lambda n=i: self.upload_popup_template(n))
            upload.pack(side="left", padx=4)
            region = ctk.CTkButton(popup_row, text="Set popup area", width=112, height=30, corner_radius=8,
                                   fg_color="#202A38", hover_color="#2B3747",
                                   command=lambda n=i: self.select_popup_region(n))
            region.pack(side="left", padx=4)
            record = ctk.CTkButton(popup_row, text="Record confirm action", width=145, height=30, corner_radius=8,
                                   fg_color="#202A38", hover_color="#2B3747",
                                   command=lambda n=i: self.start_popup_recording(n))
            record.pack(side="left", padx=4)
            test = ctk.CTkButton(popup_row, text="Test", width=58, height=30, corner_radius=8,
                                 fg_color="#202A38", hover_color="#2B3747",
                                 command=lambda n=i: self.test_popup_detection(n))
            test.pack(side="left", padx=4)
            clear = ctk.CTkButton(popup_row, text="Reset", width=62, height=30, corner_radius=8,
                                  fg_color="transparent", border_width=1, border_color="#2A3545",
                                  hover_color="#202A38", command=lambda n=i: self.clear_popup_handler(n))
            clear.pack(side="right", padx=(4, 12))
            status_var = tk.StringVar(value="")
            status = ctk.CTkLabel(card, textvariable=status_var, text_color="#8F9BAD",
                                  font=ctk.CTkFont(size=11), justify="left")
            status.pack(anchor="w", padx=22, pady=(0, 10))
            ui.update({
                "popup_enabled_var": enabled_var, "popup_switch": switch, "popup_upload": upload,
                "popup_region_btn": region, "popup_record": record, "popup_test": test,
                "popup_clear": clear, "popup_status_var": status_var, "popup_status": status,
            })

    def _toggle_popup_handler(self, index):
        slot = self._sequence_meta["slots"][index]
        ui = self._seq_ui[index]
        enabled = bool(ui.get("popup_enabled_var").get())
        if enabled and not self._popup_complete(index):
            ui["popup_enabled_var"].set(False)
            base.messagebox.showwarning(
                "Popup handler incomplete",
                "Upload a popup image, set its popup detection area, and record the confirmation action first."
            )
            return
        slot["popup_enabled"] = enabled
        self._save_sequence_meta()
        self._refresh_sequence_ui()

    def upload_popup_template(self, index):
        if self.running or self.recording:
            base.messagebox.showwarning("Busy", "Stop playback/recording before changing popup detection.")
            return
        source = filedialog.askopenfilename(parent=self, title=f"Choose popup image for Slot {index + 1}",
                                            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp"), ("All files", "*.*")])
        if not source:
            return
        try:
            dest = self._copy_template_image(source, POPUP_TEMPLATE_DIR / f"slot_{index + 1:02d}_popup.png")
            self._custom_template_cache.pop(str(dest), None)
            slot = self._sequence_meta["slots"][index]
            slot["popup_template"] = str(dest)
            slot["popup_template_name"] = Path(source).name
            self._save_sequence_meta()
            self._refresh_sequence_ui()
        except Exception as exc:
            base.messagebox.showerror("Popup image", f"Could not import the popup image:\n{exc}")

    def select_popup_region(self, index):
        if self.running or self.recording:
            base.messagebox.showwarning("Busy", "Stop playback/recording before changing popup area.")
            return
        self.withdraw()
        self.after(250, lambda n=index: base.RegionSelector(self, lambda region: self._on_popup_region_selected(n, region)))

    def _on_popup_region_selected(self, index, region):
        self._sequence_meta["slots"][index]["popup_region"] = region
        self._save_sequence_meta()
        self.deiconify()
        self.lift()
        self._refresh_sequence_ui()
        self.set_status(f"Slot {index + 1} popup area saved.", "idle")

    def start_popup_recording(self, index):
        if self.running or self.recording:
            base.messagebox.showwarning("Busy", "Stop playback/recording first.")
            return
        self._record_popup_slot = index
        self._record_target_slot = None
        self._set_sequence_controls_recording(True)
        self.start_recording()
        if not self.recording:
            self._record_popup_slot = None
            self._set_sequence_controls_recording(False)

    def save_macro(self, macro):
        if self._record_popup_slot is not None:
            self._save_popup_macro(int(self._record_popup_slot), macro)
            return
        return super().save_macro(macro)

    def _record_success_ui(self):
        if self._record_popup_slot is None:
            return super()._record_success_ui()
        index = int(self._record_popup_slot)
        self._record_popup_slot = None
        self._set_sequence_controls_recording(False)
        try:
            self.record_button.configure(state="normal")
            self.stop_record_button.configure(state="disabled")
        except Exception:
            pass
        stats = self.macro_stats(self._popup_macros[index])
        self.record_status_var.set(f"SLOT {index + 1} POPUP ACTION SAVED • {stats['events']} events • {stats['duration']:.3f}s")
        self.set_status(f"Popup confirmation action saved for Slot {index + 1}.", "idle")
        self._refresh_sequence_ui()

    def _record_error_ui(self, error):
        if self._record_popup_slot is None:
            return super()._record_error_ui(error)
        index = int(self._record_popup_slot)
        self._record_popup_slot = None
        self._set_sequence_controls_recording(False)
        self.record_status_var.set(f"SLOT {index + 1} POPUP ACTION ERROR • {error}")
        self.set_status(f"Popup action recording failed: {error}", "error")

    def test_popup_detection(self, index):
        slot = self._sequence_meta["slots"][index]
        region = slot.get("popup_region")
        template = self._get_custom_template(slot.get("popup_template", ""))
        if not region or template is None:
            base.messagebox.showwarning("Popup handler", "Upload a popup image and set its popup area first.")
            return
        try:
            with base.mss.mss() as sct:
                frame = base.np.array(sct.grab(region))[:, :, :3]
            kind, info, score = self._match_custom(frame, template, "POPUP", threshold=float(self.cfg.get("popup_match_threshold", 0.80)))
            base.messagebox.showinfo("Popup detection test", f"{'Popup detected' if kind else 'Popup not detected'}\n\nScore: {score:.3f}\n{info}")
        except Exception as exc:
            base.messagebox.showerror("Popup detection test", str(exc))

    def clear_popup_handler(self, index):
        if self.running or self.recording:
            return
        slot = self._sequence_meta["slots"][index]
        for path_value in (slot.get("popup_template", ""), str(_popup_macro_path(index))):
            try:
                if path_value:
                    Path(path_value).unlink(missing_ok=True)
            except Exception:
                pass
        slot.update({"popup_enabled": False, "popup_region": None, "popup_template": "", "popup_template_name": "", "popup_count": 0, "popup_last": "Never"})
        if self._popup_macros and index < len(self._popup_macros):
            self._popup_macros[index] = None
        self._save_sequence_meta()
        self._refresh_sequence_ui()

    def _refresh_sequence_ui(self):
        super()._refresh_sequence_ui()
        if not getattr(self, "_seq_ui", None):
            return
        for i, ui in enumerate(self._seq_ui):
            if "popup_status_var" not in ui:
                continue
            slot = self._sequence_meta["slots"][i]
            ready = self._popup_complete(i)
            enabled = bool(slot.get("popup_enabled", False)) and ready
            ui["popup_enabled_var"].set(bool(slot.get("popup_enabled", False)))
            region = slot.get("popup_region")
            name = slot.get("popup_template_name") or (Path(str(slot.get("popup_template", ""))).name if slot.get("popup_template") else "")
            action = "action ready" if self._popup_macros and i < len(self._popup_macros) and self._popup_macros[i] else "action missing"
            area = f"{region.get('width')}×{region.get('height')}" if region else "area missing"
            state = "ON" if enabled else ("READY" if ready else "OFF")
            ui["popup_status_var"].set(f"Popup recovery {state} • {name or 'image missing'} • {area} • {action}")
            ui["popup_status"].configure(text_color="#C084FC" if enabled else "#8F9BAD")

    def _set_sequence_controls_recording(self, recording):
        super()._set_sequence_controls_recording(recording)
        state = "disabled" if recording else "normal"
        for ui in getattr(self, "_seq_ui", []):
            for key in ("popup_switch", "popup_upload", "popup_region_btn", "popup_record", "popup_test", "popup_clear"):
                try:
                    ui[key].configure(state=state)
                except Exception:
                    pass

    def set_running_buttons(self, running):
        super().set_running_buttons(running)
        state = "disabled" if running else "normal"
        for ui in getattr(self, "_seq_ui", []):
            for key in ("popup_switch", "popup_upload", "popup_region_btn", "popup_record", "popup_test", "popup_clear"):
                try:
                    ui[key].configure(state=state)
                except Exception:
                    pass

    # ---------- popup watcher / recovery ----------
    def _popup_watch_loop(self, index, popup_event, popup_end, result):
        try:
            _set_thread_below_normal()
            slot = self._sequence_meta["slots"][index]
            if not bool(slot.get("popup_enabled", False)) or not self._popup_complete(index):
                return
            region = dict(slot.get("popup_region"))
            template = self._get_custom_template(slot.get("popup_template", ""))
            threshold = float(self.cfg.get("popup_match_threshold", 0.80))
            streak = 0
            with base.mss.mss() as sct:
                while self.running and not self.stop_event.is_set() and not popup_end.is_set():
                    if self._v171_popup_handling:
                        popup_end.wait(0.04)
                        continue
                    frame = base.np.array(sct.grab(region))[:, :, :3]
                    kind, info, score = self._match_custom(frame, template, "POPUP", threshold=threshold)
                    streak = streak + 1 if kind else 0
                    if kind and streak >= 2:
                        result.update({"detected": True, "info": info, "score": score})
                        popup_event.set()
                        # Wait until the handler clears the event instead of spamming detections.
                        while popup_event.is_set() and not popup_end.is_set() and not self.stop_event.is_set():
                            popup_end.wait(0.04)
                        streak = 0
                    popup_end.wait(0.045)
        except Exception as exc:
            result["error"] = str(exc)

    def _popup_wait(self, deadline_ns, rare_event, popup_event, high_precision):
        while not self.stop_event.is_set() and not rare_event.is_set() and not popup_event.is_set():
            remaining = deadline_ns - time.perf_counter_ns()
            if remaining <= 0:
                return True
            # 8 ms slices make popup interruption responsive without recreating the old high-CPU spin loop.
            slice_s = min(0.008, remaining / 1_000_000_000)
            self.stop_event.wait(max(0.0, slice_s))
        return not self.stop_event.is_set() and not rare_event.is_set() and not popup_event.is_set()

    def _replay_popup_action(self, index, injector, rare_event):
        macro = self._popup_macros[index]
        if macro is None:
            return False
        timeline = self.compile_replay_timeline(macro)
        if not timeline:
            return False
        speed = max(0.25, float(self.cfg.get("replay_speed", 1.0)))
        high_precision = bool(self.cfg.get("high_precision_timing", True))
        start_ns = time.perf_counter_ns()
        for ev in timeline:
            if self.stop_event.is_set() or rare_event.is_set():
                return False
            deadline = start_ns + int((float(ev.get("t", 0.0)) / speed) * 1_000_000_000)
            if not efficient_wait_until(deadline, self.stop_event, high_precision):
                return False
            if rare_event.is_set():
                return False
            self._send_event(injector, ev)
        duration = float(macro.get("duration", timeline[-1].get("t", 0.0)))
        efficient_wait_until(start_ns + int((duration / speed) * 1_000_000_000), self.stop_event, high_precision)
        return not self.stop_event.is_set() and not rare_event.is_set()

    def _handle_popup_action(self, index, injector, rare_event, popup_event, popup_result):
        now = time.perf_counter()
        cooldown = max(0.10, int(self.cfg.get("popup_cooldown_ms", 450)) / 1000.0)
        last = float(self._v171_popup_last_action.get(index, 0.0))
        if now - last < cooldown:
            popup_event.clear()
            return True
        self._v171_popup_handling = True
        try:
            try:
                injector.release_all()
                self._release_all_keyboard()
            except Exception:
                pass
            self.after(0, lambda n=index + 1: self.set_status(f"Slot {n}: confirmation popup detected • running recovery action", "running"))
            self.after(0, lambda n=index + 1: self.log_activity(f"Slot {n}: popup recovery triggered", "info"))
            ok = self._replay_popup_action(index, injector, rare_event)
            self._v171_popup_last_action[index] = time.perf_counter()
            slot = self._sequence_meta["slots"][index]
            slot["popup_count"] = int(slot.get("popup_count", 0)) + 1
            slot["popup_last"] = base.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self._save_sequence_meta()
            # Give Roblox time to close the dialog. The watcher is paused while handling.
            self.stop_event.wait(cooldown)
            popup_result.clear()
            popup_event.clear()
            self.after(0, self._refresh_sequence_ui)
            return ok
        finally:
            self._v171_popup_handling = False

    def _replay_sequence_slot_with_popup(self, index, injector, macro, timeline, rare_event, popup_event, popup_result):
        events = timeline or self.compile_replay_timeline(macro)
        if not events:
            return False
        speed = max(0.25, float(self.cfg.get("replay_speed", 1.0)))
        high_precision = bool(self.cfg.get("high_precision_timing", True))
        start_ns = time.perf_counter_ns()
        self._v15_last_injected_pos = None
        self._v15_button_down_at.clear()
        for ev in events:
            if self.stop_event.is_set() or rare_event.is_set():
                return False
            while popup_event.is_set() and not rare_event.is_set() and not self.stop_event.is_set():
                before = time.perf_counter_ns()
                if not self._handle_popup_action(index, injector, rare_event, popup_event, popup_result):
                    return False
                start_ns += time.perf_counter_ns() - before
            deadline = start_ns + int((float(ev.get("t", 0.0)) / speed) * 1_000_000_000)
            if not self._popup_wait(deadline, rare_event, popup_event, high_precision):
                if popup_event.is_set() and not rare_event.is_set() and not self.stop_event.is_set():
                    before = time.perf_counter_ns()
                    if not self._handle_popup_action(index, injector, rare_event, popup_event, popup_result):
                        return False
                    start_ns += time.perf_counter_ns() - before
                    deadline = start_ns + int((float(ev.get("t", 0.0)) / speed) * 1_000_000_000)
                    if not self._popup_wait(deadline, rare_event, popup_event, high_precision):
                        return False
                else:
                    return False
            self._send_event(injector, ev)
        duration = float(macro.get("duration", events[-1].get("t", 0.0)))
        end_deadline = start_ns + int((duration / speed) * 1_000_000_000)
        self._popup_wait(end_deadline, rare_event, popup_event, high_precision)
        if popup_event.is_set() and not rare_event.is_set() and not self.stop_event.is_set():
            if not self._handle_popup_action(index, injector, rare_event, popup_event, popup_result):
                return False
        return not self.stop_event.is_set() and not rare_event.is_set()

    def sequence_controller_loop(self):
        injector = None
        try:
            if sys.platform != "win32":
                raise RuntimeError("Precision absolute replay requires Windows.")
            secret_templates = self.load_templates(base.SECRET_DIR)
            mythic_templates = self.load_templates(base.MYTHIC_DIR)
            game_mode = bool(self.cfg.get("game_compatibility_mode", True))
            injector = base.WindowsMouseInjector(no_coalesce=False if game_mode else bool(self.cfg.get("no_coalesce", True)))
            injector.refresh_bounds()
            timelines = {i: self.compile_replay_timeline(self._slot_macros[i]) for i in range(SEQUENCE_SLOT_COUNT) if self._slot_macros[i]}
            high_precision = bool(self.cfg.get("high_precision_timing", True))
            pass_gap = max(0.0, int(self.cfg.get("loop_gap_ms", 80)) / 1000.0)
            precheck = max(0.0, int(self.cfg.get("sequence_precheck_ms", 80)) / 1000.0)
            final_window = max(0.040, int(self.cfg.get("sequence_result_check_ms", 180)) / 1000.0)
            popup_after = max(0.10, int(self.cfg.get("popup_watch_after_ms", 900)) / 1000.0)

            with base.TimerResolution(high_precision):
                while not self.stop_event.is_set():
                    active = self._active_slot_indices()
                    if not active:
                        self.after(0, lambda: self.finish_controller(
                            "Sequence finished: no active configured slots remain. Reactivate a slot to continue.", "stopped", "stop"))
                        return
                    pass_start = time.perf_counter()
                    pass_no = self.cycles + 1
                    self.active_loop_no = pass_no
                    for index in list(active):
                        if self.stop_event.is_set():
                            break
                        if not self._slot_ready(index):
                            continue
                        slot = self._sequence_meta["slots"][index]
                        macro = self._slot_macros[index]
                        region = dict(slot.get("region"))
                        target = str(slot.get("stop_target", "BOTH")).upper()
                        allowed = {"SECRET", "MYTHIC"} if target == "BOTH" else {target}
                        self._sequence_current_slot = index
                        self.after(0, lambda n=index + 1, p=pass_no, t=target: self.set_status(
                            f"Sequence pass {p} • Slot {n}/10 • target {t}", "running"))
                        self.after(0, lambda n=index + 1: self.detector_var.set(f"SLOT {n}"))

                        rare_event = threading.Event()
                        scan_end = threading.Event()
                        result = {}
                        detector = threading.Thread(target=self._slot_detector_loop,
                                                    args=(index, region, allowed, secret_templates, mythic_templates, rare_event, scan_end, result), daemon=True)
                        detector.start()

                        popup_event = threading.Event()
                        popup_end = threading.Event()
                        popup_result = {}
                        popup_thread = None
                        if bool(slot.get("popup_enabled", False)) and self._popup_complete(index):
                            popup_thread = threading.Thread(target=self._popup_watch_loop,
                                                            args=(index, popup_event, popup_end, popup_result), daemon=True)
                            popup_thread.start()

                        if precheck > 0:
                            deadline = time.perf_counter_ns() + int(precheck * 1_000_000_000)
                            self._wait_sequence_deadline(deadline, rare_event, high_precision)
                        if result.get("error"):
                            scan_end.set(); popup_end.set()
                            raise RuntimeError(f"Slot {index + 1} detector error: {result['error']}")
                        if rare_event.is_set():
                            scan_end.set(); popup_end.set()
                            try:
                                injector.release_all(); self._release_all_keyboard()
                            except Exception:
                                pass
                            self._v15_button_down_at.clear()
                            self._deactivate_slot_for_rare(index, result.get("kind", "TARGET"), result.get("info", "pre-check"), pass_no)
                            continue

                        if popup_event.is_set() and not rare_event.is_set():
                            self._handle_popup_action(index, injector, rare_event, popup_event, popup_result)

                        completed = self._replay_sequence_slot_with_popup(index, injector, macro, timelines.get(index, []), rare_event, popup_event, popup_result)
                        if rare_event.is_set():
                            try:
                                injector.release_all(); self._release_all_keyboard()
                            except Exception:
                                pass
                            self._v15_button_down_at.clear()
                        elif completed and popup_thread is not None:
                            # Keep watching briefly after the last macro event because Roblox dialogs often appear a few frames later.
                            deadline = time.perf_counter() + popup_after
                            while time.perf_counter() < deadline and not rare_event.is_set() and not self.stop_event.is_set():
                                if popup_event.is_set():
                                    self._handle_popup_action(index, injector, rare_event, popup_event, popup_result)
                                    break
                                self.stop_event.wait(0.02)

                        if not rare_event.is_set() and completed and final_window > 0:
                            deadline = time.perf_counter_ns() + int(final_window * 1_000_000_000)
                            self._wait_sequence_deadline(deadline, rare_event, high_precision)

                        scan_end.set(); popup_end.set()
                        detector.join(timeout=0.15)
                        if popup_thread is not None:
                            popup_thread.join(timeout=0.15)
                        if popup_result.get("error"):
                            self.after(0, lambda n=index + 1, e=popup_result.get("error"): self.log_activity(f"Slot {n} popup watcher warning: {e}", "error"))
                        if result.get("error"):
                            raise RuntimeError(f"Slot {index + 1} detector error: {result['error']}")
                        if rare_event.is_set() and result.get("kind"):
                            try:
                                injector.release_all(); self._release_all_keyboard()
                            except Exception:
                                pass
                            self._v15_button_down_at.clear()
                            self._deactivate_slot_for_rare(index, result["kind"], result.get("info", "detector"), pass_no)
                            continue
                        if self.stop_event.is_set():
                            break
                        if not completed:
                            break
                        self._sequence_slot_runs += 1

                    if self.stop_event.is_set():
                        break
                    self.cycles += 1
                    self.loop_durations.append(max(0.001, time.perf_counter() - pass_start))
                    self.cfg["lifetime_cycles"] = int(self.cfg.get("lifetime_cycles", 0)) + 1
                    self.cfg["sequence_slot_runs"] = int(self.cfg.get("sequence_slot_runs", 0)) + self._sequence_slot_runs
                    self._stats_dirty = True
                    self._sequence_slot_runs = 0
                    if pass_gap > 0:
                        deadline = time.perf_counter_ns() + int(pass_gap * 1_000_000_000)
                        if not efficient_wait_until(deadline, self.stop_event, high_precision):
                            break

            if not self.engine_error_message:
                self.after(0, lambda: self.finish_controller(f"Sequence stopped by user after {self.cycles} pass(es).", "stopped", "stop"))
        except Exception as exc:
            self.engine_error_message = str(exc)
            self.stop_event.set()
            self.after(0, lambda err=str(exc): self.finish_controller(f"Sequence stopped because of an error: {err}", "error", "error"))
            self.after(0, lambda err=str(exc): self.log_activity(f"Sequence engine error: {err}", "error"))
        finally:
            self._sequence_current_slot = -1
            self._v171_popup_handling = False
            if injector is not None:
                try:
                    injector.release_all(); self._release_all_keyboard()
                except Exception:
                    pass

    # ---------- visual refresh ----------
    def _apply_modern_polish(self):
        try:
            # Softer spacing/rounding and stronger hierarchy across the inherited interface.
            for widget in _all_widgets(self):
                if isinstance(widget, ctk.CTkButton):
                    try:
                        widget.configure(corner_radius=10)
                    except Exception:
                        pass
                elif isinstance(widget, ctk.CTkFrame):
                    try:
                        current = widget.cget("corner_radius")
                        if isinstance(current, (int, float)) and current > 0:
                            widget.configure(corner_radius=max(12, int(current)))
                    except Exception:
                        pass
            # Add a product identity strip above the Sequence page.
            page = self.pages.get("Sequence")
            if page is not None and page.winfo_children():
                hero = ctk.CTkFrame(page, fg_color="#120D1D", corner_radius=20, border_width=1, border_color="#3A2B52")
                hero.pack(fill="x", pady=(0, 14), before=page.winfo_children()[0])
                left = ctk.CTkFrame(hero, fg_color="transparent")
                left.pack(side="left", fill="x", expand=True, padx=20, pady=16)
                ctk.CTkLabel(left, text="ROBLOX AUTO ROLL SELECTOR", text_color="#C084FC",
                             font=ctk.CTkFont(size=11, weight="bold")).pack(anchor="w")
                ctk.CTkLabel(left, text="Automation Studio", text_color="#F4F7FB",
                             font=ctk.CTkFont(size=22, weight="bold")).pack(anchor="w", pady=(1, 2))
                ctk.CTkLabel(left, text="10 smart target slots • popup recovery • mouse + keyboard macros",
                             text_color="#8F9BAD").pack(anchor="w")
                badge = ctk.CTkLabel(hero, text="v17.1  SMART VISION", fg_color="#24133A", text_color="#E9D5FF",
                                     corner_radius=10, font=ctk.CTkFont(size=11, weight="bold"), width=135, height=32)
                badge.pack(side="right", padx=20)
        except Exception:
            pass

class V1711App(V171App):
    """v17.1.1: scroll-stability cleanup, simplified navigation, purple visual system and complete help."""

    def __init__(self):
        self._v1711_scroll_active = False
        self._v1711_scroll_job = None
        super().__init__()
        self._apply_v1711_migration()
        self._stabilize_scroll_pages()
        self._apply_sleek_navigation()
        self._add_update_channel_banner()
        self.title(f"Roblox Auto Roll Selector • v{APP_VERSION}")

    def _apply_v1711_migration(self):
        changed = False
        # The stable build remains v16.2. v17.x is the development/beta line.
        if int(self.cfg.get("ui_profile_version", 0)) < 1711:
            self.cfg["ui_profile_version"] = 1711
            # v17.x is the Beta line; select Beta once when this build is first installed.
            self.cfg["update_channel"] = "beta"
            changed = True
        if changed:
            base.save_config(self.cfg)

    # ---------- navigation / page construction ----------
    def build_shell(self):
        super().build_shell()
        # Analytics was mostly redundant with the Home status cards and caused needless redraw work.
        btn = self.nav_buttons.pop("Analytics", None)
        if btn is not None:
            try:
                btn.destroy()
            except Exception:
                pass

    def build_analytics_page(self):
        # Intentionally removed in v17.1.1.
        return None

    def build_help_page(self):
        page = self.make_page("Help")
        ctk.CTkLabel(page, text="Help & setup guide", text_color=base.TEXT,
                     font=ctk.CTkFont(family="Segoe UI", size=22, weight="bold")).pack(anchor="w", pady=(2, 2))
        ctk.CTkLabel(
            page,
            text="Everything important for recording, target recognition, sequence automation, popup recovery and updates.",
            text_color=base.MUTED, wraplength=940, justify="left"
        ).pack(anchor="w", pady=(0, 14))

        def help_card(title, body, tag=None):
            card = ctk.CTkFrame(page, fg_color=base.SURFACE, corner_radius=16,
                                border_width=1, border_color=base.BORDER)
            card.pack(fill="x", pady=(0, 10))
            top = ctk.CTkFrame(card, fg_color="transparent")
            top.pack(fill="x", padx=18, pady=(14, 4))
            ctk.CTkLabel(top, text=title, text_color=base.TEXT,
                         font=ctk.CTkFont(size=14, weight="bold")).pack(side="left")
            if tag:
                ctk.CTkLabel(top, text=tag, fg_color="#24133A", text_color="#E9D5FF",
                             corner_radius=8, height=24,
                             font=ctk.CTkFont(size=9, weight="bold")).pack(side="right")
            ctk.CTkLabel(card, text=body, text_color=base.MUTED, wraplength=900,
                         justify="left").pack(anchor="w", padx=18, pady=(0, 14))
            return card

        help_card(
            "1. Quick start",
            "Choose a target area in Target Detection, upload a target image if you use CUSTOM, record one complete roll cycle, test detection, then start the macro. "
            "Keep the Roblox window and monitor layout in the same positions used while recording because mouse coordinates are absolute.",
            "START HERE"
        )
        help_card(
            "2. Recording mouse + keyboard",
            "Open Recorder or a Sequence slot and press Record Macro. The Engine status shows REC 2.0s → 0.1s, then RECORDING when capture is truly live. "
            "Mouse movement, clicks and scrolling are always recorded. Enable keyboard recording in Settings if the game also needs keys. Press the configured Stop Recording hotkey (F9 by default) when the result is visible."
        )
        help_card(
            "3. Custom target images / Smart Vision",
            "Upload a tight screenshot crop of the exact result you want. Smart Vision combines grayscale structure, full colour and edge/text-shape detail, then checks nearby scales to tolerate small Roblox UI-size changes. "
            "It does not read words semantically like OCR; lettering is recognized by its visual shapes. For best reliability, include distinctive text, colour and an icon/border when possible, avoid animated backgrounds, and use Test Detection before unattended use.",
            "VISION"
        )
        help_card(
            "4. Match threshold and scale tolerance",
            "The Smart Vision threshold controls how similar the screen must be to your uploaded target. Higher values reduce false positives but can miss changing effects; lower values are more tolerant. "
            "Start near 0.82. The default ±6% scale tolerance handles small UI scaling differences. Use the test result breakdown to see structure, colour and edge/text scores before changing settings."
        )
        help_card(
            "5. 10-slot Sequence Mode",
            "Each slot has its own macro, target area, target type/image and enabled state. The engine runs active slots in order and repeats. If one slot finds its target, only that slot is deactivated; the other configured slots continue. "
            "Use Reactivate when you want that slot included again. You do not need to configure all ten slots."
        )
        help_card(
            "6. Popup Recovery",
            "Use Popup Recovery for confirmation dialogs such as a warning before dismissing a Mythic. Upload a screenshot of the popup, select the popup's screen area, record a short recovery macro that presses the correct confirmation button, then enable and test it. "
            "When the popup appears, the active watcher checks it at a high-frequency low-CPU cadence, normal slot playback pauses, the correct slot-specific recovery action runs once, a cooldown prevents spam, and the sequence resumes. v17.1.2 also performs a cross-slot safety sweep so delayed dialogs from another configured slot can still be recovered."
        )
        help_card(
            "7. SECRET / MYTHIC legacy modes",
            "BOTH, SECRET and MYTHIC remain available for older Idle Mafia setups. When rolling for SECRET only, MYTHIC can be ignored by the main target detector while Popup Recovery handles the game's Mythic-dismiss confirmation dialog."
        )
        help_card(
            "8. Preventing missed clicks and Roblox lag",
            "Leave Game Compatibility Mode enabled. It limits generated movement to a game-friendly rate, lowers detector CPU pressure and keeps click timing reliable. If Roblox visibly reaches a button but misses clicks, increase Hover settle or Minimum click hold slightly in Settings rather than raising replay frequency."
        )
        help_card(
            "9. Hotkeys and emergency stop",
            "Start and Stop hotkeys work while Roblox is focused. F6/F7 are the usual defaults and F9 stops a recording unless you changed them. Stop immediately if the Roblox layout changes unexpectedly. The app releases held mouse buttons and recorded keyboard keys when playback stops."
        )
        help_card(
            "10. Stable vs Beta updates",
            "v16.2 is the current Stable channel. v17.x builds, including v17.1.2, are published on Beta while the universal target, popup and new UI systems mature. "
            "To receive v17 updates, choose Beta on the Updates page. Switching channels does not erase your shared macros, target images or sequence data.",
            "UPDATES"
        )
        help_card(
            "11. Detection troubleshooting",
            "If a target or popup is missed, first make the detection area tighter and capture a cleaner screenshot from the same UI state. Then use Test Detection and compare the score with your threshold. Popup Recovery uses a faster dedicated matcher in v17.1.2, so a tight popup area is especially important for catching short-lived dialogs. "
            "If false positives occur, raise the threshold or use a crop with more unique colour/text detail. Animated glows, particles, changing numbers and transparent effects can make any screenshot matcher less consistent."
        )

    def switch_page(self, name):
        if name == "Analytics":
            name = "Dashboard"
        super().switch_page(name)
        subtitles = {
            "Dashboard": "At-a-glance automation status and quick controls",
            "Macro": "Record and replay precise mouse + optional keyboard input",
            "Sequence": "Build up to 10 independent automation slots",
            "Detection": "Upload, test and tune visual target recognition",
            "Updates": "Stable and Beta releases, changelogs and rollback",
            "Settings": "Input, performance, hotkeys and recording options",
            "Help": "Complete setup, detection and troubleshooting guide",
        }
        if hasattr(self, "page_subtitle"):
            self.page_subtitle.configure(text=subtitles.get(name, ""))

    # ---------- scroll stability ----------
    def _on_scroll_activity(self, _event=None):
        self._v1711_scroll_active = True
        if self._v1711_scroll_job is not None:
            try:
                self.after_cancel(self._v1711_scroll_job)
            except Exception:
                pass
        self._v1711_scroll_job = self.after(170, self._finish_scroll_activity)

    def _finish_scroll_activity(self):
        self._v1711_scroll_job = None
        self._v1711_scroll_active = False
        try:
            page = self.pages.get(self.current_page)
            canvas = getattr(page, "_parent_canvas", None) if page is not None else None
            if canvas is not None:
                canvas.update_idletasks()
                bbox = canvas.bbox("all")
                if bbox:
                    canvas.configure(scrollregion=bbox)
        except Exception:
            pass

    def _stabilize_scroll_pages(self):
        """Avoid CTk scroll-canvas repaint artifacts by keeping internals opaque and redraw work quiet while scrolling."""
        for page in self.pages.values():
            try:
                page.configure(fg_color=base.BG, corner_radius=0, border_width=0)
            except Exception:
                pass
            canvas = getattr(page, "_parent_canvas", None)
            if canvas is not None:
                try:
                    canvas.configure(background=base.BG, highlightthickness=0, bd=0, yscrollincrement=2)
                    canvas.bind("<MouseWheel>", self._on_scroll_activity, add="+")
                    canvas.bind("<Button-4>", self._on_scroll_activity, add="+")
                    canvas.bind("<Button-5>", self._on_scroll_activity, add="+")
                except Exception:
                    pass
        # A deferred geometry pass prevents stale scrollregions after the large 10-slot page is constructed.
        self.after(80, self._refresh_all_scrollregions)
        self.after(450, self._refresh_all_scrollregions)

    def _refresh_all_scrollregions(self):
        for page in self.pages.values():
            try:
                canvas = getattr(page, "_parent_canvas", None)
                if canvas is not None:
                    canvas.update_idletasks()
                    bbox = canvas.bbox("all")
                    if bbox:
                        canvas.configure(scrollregion=bbox)
            except Exception:
                pass

    def animation_tick(self):
        # Redrawing animated CTk widgets at the same time as a large scrollable canvas is moving
        # is a common cause of visual tearing/ghosting on Windows. Pause decorative redraws briefly.
        if getattr(self, "_v1711_scroll_active", False):
            self.after(180, self.animation_tick)
            return
        return super().animation_tick()

    # ---------- sleek targeted styling ----------
    def _apply_modern_polish(self):
        """Replace v17.1's recursive widget mutation with targeted cards only.

        The old routine walked through CTkScrollableFrame internals and changed frame geometry after
        creation. That could leave stale canvas items while scrolling. v17.1.1 never mutates the
        scroll-frame internals and only adds normal content cards.
        """
        try:
            page = self.pages.get("Sequence")
            if page is not None and page.winfo_children():
                hero = ctk.CTkFrame(page, fg_color="#120D1D", corner_radius=18,
                                    border_width=1, border_color="#3A2B52")
                hero.pack(fill="x", pady=(0, 14), before=page.winfo_children()[0])
                left = ctk.CTkFrame(hero, fg_color="transparent")
                left.pack(side="left", fill="x", expand=True, padx=20, pady=15)
                ctk.CTkLabel(left, text="AUTOMATION SEQUENCE", text_color="#C084FC",
                             font=ctk.CTkFont(size=10, weight="bold")).pack(anchor="w")
                ctk.CTkLabel(left, text="10 independent roll slots", text_color=base.TEXT,
                             font=ctk.CTkFont(size=21, weight="bold")).pack(anchor="w", pady=(1, 2))
                ctk.CTkLabel(left, text="Macro + target + optional popup recovery per slot",
                             text_color=base.MUTED).pack(anchor="w")
                ctk.CTkLabel(hero, text="v17.1.2  BETA", fg_color="#24133A", text_color="#E9D5FF",
                             corner_radius=9, width=112, height=30,
                             font=ctk.CTkFont(size=10, weight="bold")).pack(side="right", padx=20)
        except Exception:
            pass

    def _apply_sleek_navigation(self):
        labels = {
            "Dashboard": "⌂   Home",
            "Macro": "●   Recorder",
            "Sequence": "≋   Sequence",
            "Detection": "◎   Target Detection",
            "Updates": "↻   Updates",
            "Settings": "⚙   Settings",
            "Help": "?   Help & Guide",
        }
        for name, text in labels.items():
            btn = self.nav_buttons.get(name)
            if btn is not None:
                try:
                    btn.configure(text=text, corner_radius=11)
                except Exception:
                    pass
        # Update inherited sidebar branding without touching scroll-frame internals.
        for widget in _all_widgets(self):
            if not isinstance(widget, ctk.CTkLabel):
                continue
            try:
                text = str(widget.cget("text"))
                if text == "Roblox Auto Roll Selector":
                    widget.configure(text="Roblox Auto Roll", text_color=base.TEXT,
                                     font=ctk.CTkFont(family="Segoe UI", size=14, weight="bold"))
                elif text == "PRECISION MACRO":
                    widget.configure(text="AUTO ROLL SELECTOR", text_color="#C084FC")
            except Exception:
                pass

    def _add_update_channel_banner(self):
        page = self.pages.get("Updates")
        if page is None:
            return
        try:
            first = page.winfo_children()[0] if page.winfo_children() else None
            card = ctk.CTkFrame(page, fg_color="#120D1D", corner_radius=16,
                                border_width=1, border_color="#3A2B52")
            kwargs = {"fill": "x", "pady": (0, 12)}
            if first is not None:
                kwargs["before"] = first
            card.pack(**kwargs)
            row = ctk.CTkFrame(card, fg_color="transparent")
            row.pack(fill="x", padx=18, pady=14)
            ctk.CTkLabel(row, text="RELEASE CHANNELS", text_color="#C084FC",
                         font=ctk.CTkFont(size=10, weight="bold")).pack(anchor="w")
            ctk.CTkLabel(row, text="Stable: v16.2   •   Beta: v17.1.2",
                         text_color=base.TEXT, font=ctk.CTkFont(size=14, weight="bold")).pack(anchor="w", pady=(2, 2))
            ctk.CTkLabel(row, text="Universal target recognition, popup recovery and the redesigned interface are currently on Beta.",
                         text_color=base.MUTED).pack(anchor="w")
        except Exception:
            pass


class V1712App(V1711App):
    """v17.1.2: slot-safe Popup Recovery v3, faster popup vision and runtime hardening."""

    def __init__(self):
        # These exist before inherited page construction because inherited refresh callbacks may
        # run while the UI is still being built.
        self._v1712_popup_context_cache = {}
        self._v1712_popup_handling_slots = set()
        self._v1712_popup_cache_lock = threading.RLock()
        super().__init__()
        self._apply_v1712_migration()
        self._refresh_sequence_ui()
        self.title(f"Roblox Auto Roll Selector • v{APP_VERSION}")

    # ---------- v17.1.2 migration / preflight ----------
    def _apply_v1712_migration(self):
        changed = False
        old_detector = int(self.cfg.get("popup_detection_version", 0) or 0)
        if old_detector < 3:
            # 0.80 was the original v17.1 default. The new aligned matcher is more selective,
            # so 0.76 is a better starting point without making broad areas trigger easily.
            try:
                if abs(float(self.cfg.get("popup_match_threshold", 0.80)) - 0.80) < 1e-9:
                    self.cfg["popup_match_threshold"] = 0.76
            except Exception:
                self.cfg["popup_match_threshold"] = 0.76
            if int(self.cfg.get("popup_watch_after_ms", 900) or 900) <= 900:
                self.cfg["popup_watch_after_ms"] = 1200
            self.cfg["popup_detection_version"] = 3
            changed = True

        defaults = {
            "popup_scan_interval_ms": 12,
            "popup_single_frame_margin": 0.055,
            "popup_soft_hit_window_ms": 85,
            "popup_close_grace_ms": 180,
            "popup_cross_slot_sweep": True,
            "runtime_audit_version": 1712,
        }
        for key, value in defaults.items():
            if key not in self.cfg:
                self.cfg[key] = value
                changed = True
        if changed:
            base.save_config(self.cfg)

    @staticmethod
    def _popup_region_signature(region):
        if not isinstance(region, dict):
            return None
        return tuple(int(region.get(k, 0)) for k in ("left", "top", "width", "height"))

    def _popup_context_signature(self, index):
        if index < 0 or index >= SEQUENCE_SLOT_COUNT:
            return None
        slot = self._sequence_meta["slots"][index]
        path_value = str(slot.get("popup_template", ""))
        try:
            mtime = Path(path_value).stat().st_mtime_ns if path_value else 0
        except Exception:
            mtime = 0
        return (
            path_value,
            mtime,
            self._popup_region_signature(slot.get("popup_region")),
            round(float(self.cfg.get("popup_match_threshold", 0.76)), 5),
            int(self.cfg.get("custom_scale_tolerance_pct", 6)),
        )

    def _prepare_popup_context(self, index):
        """Build an immutable, slot-specific popup matcher context.

        Pre-resizing the template means the high-frequency watcher only converts the live crop
        once and performs cheap correlations. It also prevents Slot 1 state from leaking into
        another slot through shared mutable matcher data.
        """
        if index < 0 or index >= SEQUENCE_SLOT_COUNT or not self._popup_complete(index):
            return None
        slot = self._sequence_meta["slots"][index]
        region = dict(slot.get("popup_region") or {})
        if int(region.get("width", 0)) < 4 or int(region.get("height", 0)) < 4:
            return None
        template = self._get_custom_template(slot.get("popup_template", ""))
        if template is None:
            return None

        threshold = max(0.45, min(0.98, float(self.cfg.get("popup_match_threshold", 0.76))))
        tolerance = max(0, min(12, int(self.cfg.get("custom_scale_tolerance_pct", 6)))) / 100.0
        # Five nearby sizes improves Roblox UI-scale tolerance without resizing on each frame.
        scales = [1.0]
        if tolerance > 0:
            half = tolerance * 0.5
            scales = [1.0 - tolerance, 1.0 - half, 1.0, 1.0 + half, 1.0 + tolerance]
        variants = []
        base_gray = base.cv2.cvtColor(base.np.ascontiguousarray(template[:, :, :3]), base.cv2.COLOR_BGR2GRAY)
        for scale in scales:
            if scale <= 0:
                continue
            if abs(scale - 1.0) < 1e-8:
                tb = base.np.ascontiguousarray(template[:, :, :3])
                tg = base_gray
            else:
                tw = max(4, int(round(template.shape[1] * scale)))
                th = max(4, int(round(template.shape[0] * scale)))
                if tw > int(region["width"]) or th > int(region["height"]):
                    continue
                interp = base.cv2.INTER_AREA if scale < 1.0 else base.cv2.INTER_LINEAR
                tb = base.cv2.resize(template[:, :, :3], (tw, th), interpolation=interp)
                tg = base.cv2.resize(base_gray, (tw, th), interpolation=interp)
            te = base.cv2.Canny(tg, 55, 145)
            variants.append({
                "scale": float(scale),
                "bgr": base.np.ascontiguousarray(tb),
                "gray": base.np.ascontiguousarray(tg),
                "edges": base.np.ascontiguousarray(te),
                "edge_pixels": int(base.np.count_nonzero(te)),
            })
        if not variants:
            return None
        return {
            "index": index,
            "region": region,
            "threshold": threshold,
            "variants": variants,
            "name": slot.get("popup_template_name") or f"Slot {index + 1} popup",
        }

    def _get_popup_context(self, index):
        signature = self._popup_context_signature(index)
        if signature is None:
            return None
        with self._v1712_popup_cache_lock:
            cached = self._v1712_popup_context_cache.get(index)
            if cached and cached[0] == signature:
                return cached[1]
        context = self._prepare_popup_context(index)
        with self._v1712_popup_cache_lock:
            self._v1712_popup_context_cache[index] = (signature, context)
        return context

    @staticmethod
    def _popup_corr(frame, template):
        """Return normalized template correlation and best location."""
        if frame is None or template is None:
            return 0.0, (0, 0)
        fh, fw = frame.shape[:2]
        th, tw = template.shape[:2]
        if th < 3 or tw < 3 or th > fh or tw > fw:
            return 0.0, (0, 0)
        try:
            result = base.cv2.matchTemplate(frame, template, base.cv2.TM_CCOEFF_NORMED)
            _min_v, max_v, _min_l, max_l = base.cv2.minMaxLoc(result)
            score = float(max_v)
            if not math.isfinite(score):
                raise ValueError("non-finite popup correlation")
            return max(0.0, min(1.0, score)), max_l
        except Exception:
            try:
                result = base.cv2.matchTemplate(frame, template, base.cv2.TM_CCORR_NORMED)
                _min_v, max_v, _min_l, max_l = base.cv2.minMaxLoc(result)
                score = float(max_v)
                return max(0.0, min(1.0, score if math.isfinite(score) else 0.0)), max_l
            except Exception:
                return 0.0, (0, 0)

    def _match_popup_frame(self, frame, context):
        """Fast aligned popup matcher.

        v17.1 evaluated colour and edges as independent whole-region template searches. Those
        channels could accidentally score different screen locations. v17.1.2 first locates the
        popup structurally, then evaluates colour and edges at that exact same location. This is
        both faster and more reliable for warning dialogs containing text/buttons.
        """
        if frame is None or context is None:
            return False, "popup context missing", 0.0
        try:
            fb = base.np.ascontiguousarray(frame[:, :, :3])
            fg = base.cv2.cvtColor(fb, base.cv2.COLOR_BGR2GRAY)
            best = None
            for variant in context["variants"]:
                structure, loc = self._popup_corr(fg, variant["gray"])
                if best is None or structure > best[0]:
                    best = (structure, loc, variant)
            if best is None:
                return False, "popup template does not fit selected area", 0.0

            structure, (x, y), variant = best
            threshold = float(context["threshold"])
            # Cheap negative path: most frames never get near the popup threshold, so skip the
            # colour/edge work entirely and keep Roblox CPU contention very low.
            if structure < max(0.20, threshold - 0.16):
                info = f"popup {structure:.3f}/{threshold:.3f} • fast structure • scale {variant['scale']:.3f}x"
                return False, info, structure

            th, tw = variant["gray"].shape[:2]
            crop_bgr = fb[y:y + th, x:x + tw]
            crop_gray = fg[y:y + th, x:x + tw]
            if crop_bgr.shape[:2] != (th, tw):
                return False, "popup candidate was clipped by selected area", structure

            colour, _ = self._popup_corr(crop_bgr, variant["bgr"])
            if variant["edge_pixels"] >= 8:
                crop_edges = base.cv2.Canny(crop_gray, 55, 145)
                edge, _ = self._popup_corr(crop_edges, variant["edges"])
            else:
                edge = structure

            # Dialogs are dominated by stable shapes and text, with colour as corroboration.
            score = max(0.0, min(1.0, (0.58 * structure) + (0.22 * colour) + (0.20 * edge)))
            info = (
                f"popup {score:.3f}/{threshold:.3f} • structure {structure:.3f} • "
                f"colour {colour:.3f} • text/edge {edge:.3f} • scale {variant['scale']:.3f}x"
            )
            return score >= threshold, info, score
        except Exception as exc:
            return False, f"popup matcher error: {exc}", 0.0

    # ---------- all-slot popup watcher ----------
    def _popup_watch_loop(self, index, popup_event, popup_end, result):
        try:
            _set_thread_below_normal()
            context = self._get_popup_context(index)
            if context is None:
                result["error"] = f"Slot {index + 1} popup configuration is incomplete or invalid."
                return
            game_mode = bool(self.cfg.get("game_compatibility_mode", True))
            configured_ms = int(self.cfg.get("popup_scan_interval_ms", 12))
            interval = max(0.010 if game_mode else 0.006, min(0.050, configured_ms / 1000.0))
            strong_margin = max(0.02, min(0.15, float(self.cfg.get("popup_single_frame_margin", 0.055))))
            soft_window = max(0.035, min(0.250, int(self.cfg.get("popup_soft_hit_window_ms", 85)) / 1000.0))
            last_soft_hit = 0.0
            peak_score = 0.0
            scan_count = 0
            with base.mss.mss() as sct:
                while self.running and not self.stop_event.is_set() and not popup_end.is_set():
                    if index in self._v1712_popup_handling_slots:
                        popup_end.wait(min(0.012, interval))
                        continue
                    frame = base.np.array(sct.grab(context["region"]))[:, :, :3]
                    matched, info, score = self._match_popup_frame(frame, context)
                    scan_count += 1
                    peak_score = max(peak_score, float(score))
                    now = time.perf_counter()
                    threshold = float(context["threshold"])
                    trigger = False
                    # A very convincing single frame fires immediately, which is the key fix for
                    # dialogs that are visible for only one or two rendered frames.
                    if score >= threshold + strong_margin:
                        trigger = True
                    elif matched:
                        if last_soft_hit and now - last_soft_hit <= soft_window:
                            trigger = True
                        else:
                            last_soft_hit = now
                    elif score < threshold - 0.035:
                        last_soft_hit = 0.0

                    if trigger:
                        result.update({
                            "detected": True, "index": index, "info": info, "score": float(score),
                            "peak": peak_score, "scans": scan_count,
                        })
                        popup_event.set()
                        while popup_event.is_set() and not popup_end.is_set() and not self.stop_event.is_set():
                            popup_end.wait(min(0.010, interval))
                        last_soft_hit = 0.0
                        peak_score = 0.0
                    popup_end.wait(interval)
        except Exception as exc:
            result["error"] = str(exc)

    def _handle_popup_action(self, index, injector, rare_event, popup_event, popup_result):
        # If a cross-slot safety scan found another slot's dialog, always execute that slot's
        # own recovery macro rather than the currently running slot's macro.
        detected_index = popup_result.get("index") if isinstance(popup_result, dict) else None
        try:
            if detected_index is not None:
                index = int(detected_index)
        except Exception:
            pass
        if index < 0 or index >= SEQUENCE_SLOT_COUNT or not self._popup_complete(index):
            popup_event.clear()
            return True

        now = time.perf_counter()
        cooldown = max(0.10, int(self.cfg.get("popup_cooldown_ms", 450)) / 1000.0)
        last = float(self._v171_popup_last_action.get(index, 0.0))
        if now - last < cooldown:
            popup_event.clear()
            return True

        self._v1712_popup_handling_slots.add(index)
        self._v171_popup_handling = True  # keep inherited status semantics compatible
        try:
            try:
                injector.release_all()
                self._release_all_keyboard()
            except Exception:
                pass
            self.after(0, lambda n=index + 1: self.set_status(
                f"Slot {n}: popup detected • running that slot's recovery action", "running"))
            self.after(0, lambda n=index + 1: self.log_activity(
                f"Slot {n}: Popup Recovery v3 triggered", "info"))
            ok = self._replay_popup_action(index, injector, rare_event)
            self._v171_popup_last_action[index] = time.perf_counter()
            slot = self._sequence_meta["slots"][index]
            slot["popup_count"] = int(slot.get("popup_count", 0)) + 1
            slot["popup_last"] = base.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self._save_sequence_meta()
            # Resume sooner than v17.1 while the independent cooldown still prevents spam.
            grace = max(0.06, min(cooldown, int(self.cfg.get("popup_close_grace_ms", 180)) / 1000.0))
            self.stop_event.wait(grace)
            popup_result.clear()
            popup_event.clear()
            self.after(0, self._refresh_sequence_ui)
            return ok
        finally:
            self._v1712_popup_handling_slots.discard(index)
            self._v171_popup_handling = bool(self._v1712_popup_handling_slots)

    def _recover_any_visible_popup_once(self, injector, rare_event, preferred_index=None):
        """One low-frequency cross-slot sweep for delayed dialogs between sequence slots."""
        if not bool(self.cfg.get("popup_cross_slot_sweep", True)) or self.stop_event.is_set() or rare_event.is_set():
            return True
        order = []
        if preferred_index is not None:
            order.append(int(preferred_index))
        order.extend(i for i in range(SEQUENCE_SLOT_COUNT) if i not in order)
        contexts = []
        for i in order:
            slot = self._sequence_meta["slots"][i]
            if bool(slot.get("popup_enabled", False)) and self._popup_complete(i):
                ctx = self._get_popup_context(i)
                if ctx is not None:
                    contexts.append(ctx)
        if not contexts:
            return True
        best = None
        try:
            with base.mss.mss() as sct:
                for context in contexts:
                    frame = base.np.array(sct.grab(context["region"]))[:, :, :3]
                    matched, info, score = self._match_popup_frame(frame, context)
                    if matched and (best is None or score > best[0]):
                        best = (score, context["index"], info)
        except Exception as exc:
            self.after(0, lambda e=str(exc): self.log_activity(f"Popup cross-slot sweep warning: {e}", "error"))
            return True
        if best is None:
            return True
        score, found_index, info = best
        event = threading.Event(); event.set()
        result = {"detected": True, "index": found_index, "score": score, "info": info}
        return self._handle_popup_action(found_index, injector, rare_event, event, result)

    def _replay_sequence_slot_with_popup(self, index, injector, macro, timeline, rare_event, popup_event, popup_result):
        # Before each slot begins, recover a dialog left behind by any of the ten configured slots.
        if not self._recover_any_visible_popup_once(injector, rare_event, preferred_index=index):
            return False
        return super()._replay_sequence_slot_with_popup(index, injector, macro, timeline, rare_event, popup_event, popup_result)

    def start_sequence_controller(self):
        # Re-read every slot's recovery macro and rebuild matcher contexts at each run. This makes
        # all ten slots deterministic even after an update or after files were edited on disk.
        self._popup_macros = [self._load_popup_macro(i) for i in range(SEQUENCE_SLOT_COUNT)]
        with self._v1712_popup_cache_lock:
            self._v1712_popup_context_cache.clear()
        armed = []
        invalid = []
        display_mismatch = []
        for i in range(SEQUENCE_SLOT_COUNT):
            slot = self._sequence_meta["slots"][i]
            if not bool(slot.get("popup_enabled", False)):
                continue
            if not self._popup_complete(i):
                invalid.append(i + 1)
                continue
            context = self._get_popup_context(i)
            if context is None:
                invalid.append(i + 1)
                continue
            armed.append(i + 1)
            try:
                ok, saved, current = self.validate_macro_environment(self._popup_macros[i])
                if not ok:
                    display_mismatch.append((i + 1, saved, current))
            except Exception:
                pass
        if invalid:
            base.messagebox.showwarning(
                "Popup Recovery configuration",
                "These slots have Popup Recovery enabled but are incomplete or invalid: "
                + ", ".join(map(str, invalid))
                + ". They will not be used until their popup image, popup area and recovery macro are configured."
            )
        if display_mismatch:
            details = "\n".join(f"Slot {n}: recorded {saved} • current {current}" for n, saved, current in display_mismatch)
            if not base.messagebox.askyesno(
                "Popup recovery display layout changed",
                "One or more popup recovery actions were recorded on another display layout. "
                "Their absolute click coordinates may be wrong.\n\n" + details + "\n\nContinue anyway?"
            ):
                return
        if armed:
            self.log_activity("Popup Recovery armed for slots: " + ", ".join(map(str, armed)), "info")
        return super().start_sequence_controller()

    def test_popup_detection(self, index):
        slot = self._sequence_meta["slots"][index]
        if not slot.get("popup_region") or self._get_custom_template(slot.get("popup_template", "")) is None:
            base.messagebox.showwarning("Popup handler", "Upload a popup image and set its popup area first.")
            return
        context = self._get_popup_context(index)
        if context is None:
            base.messagebox.showerror("Popup detection test", "The popup template does not fit the selected popup area.")
            return
        try:
            # Burst test catches animated/short dialogs and shows the actual peak score the runtime
            # watcher would see, rather than testing only one unlucky frame.
            interval = max(0.010, int(self.cfg.get("popup_scan_interval_ms", 12)) / 1000.0)
            deadline = time.perf_counter() + 0.30
            best = (False, "no frame", 0.0)
            frames = 0
            with base.mss.mss() as sct:
                while time.perf_counter() < deadline:
                    frame = base.np.array(sct.grab(context["region"]))[:, :, :3]
                    current = self._match_popup_frame(frame, context)
                    frames += 1
                    if current[2] > best[2]:
                        best = current
                    if current[0] and current[2] >= context["threshold"] + float(self.cfg.get("popup_single_frame_margin", 0.055)):
                        break
                    time.sleep(interval)
            matched, info, score = best
            base.messagebox.showinfo(
                "Popup Recovery v3 test",
                f"Slot {index + 1}: {'POPUP DETECTED' if matched else 'popup not detected'}\n\n"
                f"Peak score: {score:.3f}\nFrames sampled: {frames}\n{info}\n\n"
                "Tip: use a tight popup area containing stable dialog text, borders and the confirmation buttons."
            )
        except Exception as exc:
            base.messagebox.showerror("Popup detection test", str(exc))

    def _refresh_sequence_ui(self):
        super()._refresh_sequence_ui()
        for i, ui in enumerate(getattr(self, "_seq_ui", [])):
            if "popup_status_var" not in ui:
                continue
            slot = self._sequence_meta["slots"][i]
            ready = self._popup_complete(i)
            enabled = bool(slot.get("popup_enabled", False)) and ready
            region = slot.get("popup_region")
            name = slot.get("popup_template_name") or (Path(str(slot.get("popup_template", ""))).name if slot.get("popup_template") else "")
            action = "action ready" if self._popup_macros and i < len(self._popup_macros) and self._popup_macros[i] else "action missing"
            area = f"{region.get('width')}×{region.get('height')}" if region else "area missing"
            state = "FAST ON" if enabled else ("READY" if ready else "OFF")
            ui["popup_status_var"].set(f"Popup recovery {state} • Slot {i + 1} • {name or 'image missing'} • {area} • {action}")
            try:
                ui["popup_status"].configure(text_color="#C084FC" if enabled else "#8F9BAD")
            except Exception:
                pass




class V1713App(V1712App):
    """v17.1.3: Alpha legacy archive channel and safer one-time legacy launches."""

    def __init__(self):
        super().__init__()
        changed = False
        if int(self.cfg.get("update_channel_schema_version", 0) or 0) < 3:
            self.cfg["update_channel_schema_version"] = 3
            changed = True
        if changed:
            base.save_config(self.cfg)
        self._patch_v1713_ui_copy()
        self.title(f"Roblox Auto Roll Selector • v{APP_VERSION}")

    def _patch_v1713_ui_copy(self):
        for widget in _all_widgets(self):
            if not isinstance(widget, ctk.CTkLabel):
                continue
            try:
                text = str(widget.cget("text"))
            except Exception:
                continue
            new = text.replace("v17.1.2", "v17.1.3")
            if new == "v17.1.3  BETA":
                new = "v17.1.3  STABLE"
            elif new == "Stable: v16.2   •   Beta: v17.1.3":
                new = "Stable: v17.1.3   •   Beta: previews   •   Alpha: v1–v13 archive"
            elif new == "Universal target recognition, popup recovery and the redesigned interface are currently on Beta.":
                new = "Alpha contains the original pre-v14 builds. Legacy Alpha sessions open temporarily and Stable stays selected."
            elif new == "10. Stable vs Beta updates":
                new = "10. Stable, Beta & Alpha updates"
            elif new.startswith("v16.2 is the current Stable channel."):
                new = (
                    "v17.1.3 is the current Stable release. Beta contains newer preview/history builds from the modern updater era. "
                    "Alpha contains the original v1–v13 legacy builds from before Update Center existed. Choose Alpha to browse them. "
                    "Opening an Alpha build is a one-time legacy session: the app closes Stable, opens the selected old build, and keeps Stable selected so RUN_APP.bat returns you to the modern release."
                )
            if new != text:
                try: widget.configure(text=new)
                except Exception: pass

    def switch_page(self, name):
        super().switch_page(name)
        if name == "Updates" and hasattr(self, "page_subtitle"):
            self.page_subtitle.configure(text="Stable, Beta and Alpha legacy releases, changelogs and safe rollback")


from macro_library import MacroLibraryMixin
from ui_performance import PerformanceMixin


class V172App(PerformanceMixin, MacroLibraryMixin, V1713App):
    """Stable navigation, personal branding and reusable named macros."""

    macro_library_root = ROOT
    ui_base = base


def main():
    _set_app_id()
    app = V172App()
    _apply_icon(app)
    app.log_activity("v17.2.0 active • stable scrolling • named slots and macro library", "info")
    app.mainloop()


if __name__ == "__main__":
    main()
