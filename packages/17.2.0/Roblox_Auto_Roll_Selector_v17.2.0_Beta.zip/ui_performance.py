"""UI-only performance improvements; playback and detection remain independent."""
import json
import time
from pathlib import Path

import customtkinter as ctk
from PIL import Image

from stable_scroll import StableScrollableFrame


def set_changed(variable, value):
    if variable.get() != value:
        variable.set(value)


def configure_changed(widget, **values):
    changed = {key: value for key, value in values.items() if widget.cget(key) != value}
    if changed:
        widget.configure(**changed)


class PerformanceMixin:
    def __init__(self):
        self._macro_stats_cache = {}
        self._sequence_ui_signature = None
        self._visible_page = None
        self._scroll_until = 0.0
        self._selected_slot = 0
        self._slot_nav_buttons = []
        super().__init__()
        self._add_personal_photo()
        self._update_current_copy()
        self.title("Roblox Auto Roll Selector • v17.2.0 BETA")

    def build_sequence_page(self):
        super().build_sequence_page()
        page = self.pages["Sequence"]
        self._slot_cards = [ui["record"].master.master for ui in self._seq_ui]
        selector = ctk.CTkFrame(page, fg_color=self.ui_base.SURFACE, corner_radius=14,
                                border_width=1, border_color=self.ui_base.BORDER)
        selector.pack(fill="x", pady=(0, 12), before=self._slot_cards[0])
        ctk.CTkLabel(selector, text="CHOOSE A SLOT TO EDIT", text_color="#C084FC",
                     font=ctk.CTkFont(size=11, weight="bold")).pack(anchor="w", padx=18, pady=(12, 3))
        ctk.CTkLabel(selector, text="All enabled slots still run in sequence. Choose a slot below to edit its controls.",
                     text_color=self.ui_base.MUTED, wraplength=650, justify="left").pack(anchor="w", padx=18)
        grid = ctk.CTkFrame(selector, fg_color="transparent")
        grid.pack(fill="x", padx=14, pady=(8, 14))
        for column in range(5):
            grid.grid_columnconfigure(column, weight=1, uniform="slot")
        for index in range(10):
            button = ctk.CTkButton(grid, text=f"Slot {index+1}", height=34, width=80,
                                   fg_color=self.ui_base.SURFACE_3, hover_color="#49305F",
                                   command=lambda n=index: self._show_slot(n))
            button.grid(row=index//5, column=index%5, sticky="ew", padx=4, pady=4)
            self._slot_nav_buttons.append(button)
        for card in self._slot_cards[1:]:
            card.pack_forget()
        self._refresh_slot_selector()

    def _show_slot(self, index):
        if index == self._selected_slot:
            return
        previous = self._slot_cards[self._selected_slot]
        following = previous.master.pack_slaves()
        anchor_index = following.index(previous) + 1
        anchor = following[anchor_index] if anchor_index < len(following) else None
        previous.pack_forget()
        options = {"fill": "x", "pady": (0, 12)}
        if anchor is not None:
            options["before"] = anchor
        self._slot_cards[index].pack(**options)
        self._selected_slot = index
        self._refresh_slot_selector()

    def _refresh_slot_selector(self):
        for index, button in enumerate(self._slot_nav_buttons):
            name = str(self._sequence_meta["slots"][index].get("name", ""))
            label = f"{index+1} · {name[:12]}{'…' if len(name)>12 else ''}" if name else f"Slot {index+1}"
            configure_changed(button, text=label,
                              fg_color="#8B5CF6" if index == self._selected_slot else self.ui_base.SURFACE_3)

    def make_page(self, name):
        base = self.ui_base
        page = StableScrollableFrame(
            self.page_host, fg_color=base.BG, corner_radius=0,
            scrollbar_button_color=base.SURFACE_3,
            scrollbar_button_hover_color="#685185",
            on_scroll=self._on_scroll_activity,
        )
        page.grid(row=0, column=0, sticky="nsew")
        page.grid_remove()
        page.grid_columnconfigure(0, weight=1)
        self.pages[name] = page
        return page

    def _on_scroll_activity(self, _event=None):
        self._scroll_until = time.monotonic() + 0.16

    def _stabilize_scroll_pages(self):
        # StableScrollableFrame owns layout, clipping and scrolling from creation.
        pass

    def _refresh_all_scrollregions(self):
        pass

    def _finish_scroll_activity(self):
        pass

    def switch_page(self, name):
        name = "Dashboard" if name == "Analytics" else name
        if name not in self.pages or self._visible_page == name:
            return
        previous = self._visible_page
        if previous in self.pages:
            self.pages[previous].grid_remove()
        self.pages[name].grid()
        self.current_page = self._visible_page = name
        titles = {"Dashboard": "Home", "Macro": "Recorder"}
        subtitles = {
            "Dashboard": "Your automation at a glance",
            "Macro": "Record, save and reuse mouse and keyboard macros",
            "Sequence": "Name and configure up to 10 independent roll slots",
            "Detection": "Upload, test and tune visual target recognition",
            "Settings": "Input, performance, hotkeys and recording options",
            "Help": "Setup, detection and troubleshooting guide",
            "Updates": "Stable, Beta and Alpha releases, changelogs and rollback",
        }
        configure_changed(self.page_title, text=titles.get(name, name))
        configure_changed(self.page_subtitle, text=subtitles.get(name, ""))
        base = self.ui_base
        for key in (previous, name):
            if key in self.nav_buttons:
                configure_changed(self.nav_buttons[key],
                                  fg_color=base.SURFACE_2 if key == name else "transparent",
                                  text_color=base.TEXT if key == name else base.MUTED)
        if name == "Sequence":
            self._refresh_sequence_ui()
        elif name == "Updates":
            self.update_controller.refresh_page()

    def macro_stats(self, macro=None):
        value = self.macro if macro is None else macro
        if not value:
            return super().macro_stats(macro)
        cache = self._macro_stats_cache
        key = id(value)
        events = value.get("events", [])
        signature = (id(events), len(events), value.get("duration"))
        cached = cache.get(key)
        if cached and cached[0] is value and cached[1] == signature:
            return cached[2]
        result = super().macro_stats(macro)
        if len(cache) >= 32:
            cache.clear()
        cache[key] = (value, signature, result)
        return result

    def _refresh_sequence_ui(self):
        if not getattr(self, "_seq_ui", None):
            return
        signature = (
            json.dumps(self._sequence_meta, sort_keys=True),
            tuple(id(m) for m in self._slot_macros),
            tuple(id(m) for m in getattr(self, "_popup_macros", [])),
            bool(self.sequence_mode_var.get()),
            tuple("popup_status_var" in ui for ui in self._seq_ui),
        )
        if signature == self._sequence_ui_signature:
            return
        super()._refresh_sequence_ui()
        self._sequence_ui_signature = signature
        self._refresh_slot_selector()

    def ui_tick(self):
        base = self.ui_base
        visible = self.state() != "iconic"
        if visible and time.monotonic() >= self._scroll_until:
            if self.running and self.session_start:
                elapsed = max(0, time.perf_counter() - self.session_start)
                h, m, s = int(elapsed // 3600), int(elapsed % 3600 // 60), int(elapsed % 60)
                set_changed(self.elapsed_var, f"{h:02d}:{m:02d}:{s:02d}")
                if elapsed > 3 and self.cycles:
                    set_changed(self.loops_hour_var, str(int(round(self.cycles * 3600 / elapsed))))
            for var, value in (
                (self.session_cycles_var, str(self.cycles)),
                (self.lifetime_cycles_var, str(int(self.cfg.get("lifetime_cycles", 0)))),
                (self.rare_finds_var, str(int(self.cfg.get("rare_finds", 0)))),
                (self.last_rare_var, str(self.cfg.get("last_rare", "Never"))),
                (self.secret_px_var, f"{self.last_secret_px} px"),
                (self.mythic_px_var, f"{self.last_mythic_px} px"),
            ):
                set_changed(var, value)
            if self.current_page == "Dashboard" and hasattr(self, "dashboard_macro"):
                configure_changed(self.dashboard_macro, text=(
                    f"{self.macro_duration_var.get()}\n{self.macro_moves_var.get()} move anchors • "
                    f"{self.macro_clicks_var.get()} clicks\n{self.macro_sample_var.get()}"))
        if self._stats_dirty and time.monotonic() - self._last_stats_save >= 3:
            try:
                base.save_config(self.cfg)
                self._stats_dirty = False
                self._last_stats_save = time.monotonic()
            except OSError:
                pass
        self.after(600 if self.running else 400, self.ui_tick)

    def animation_tick(self):
        base = self.ui_base
        if self.state() != "iconic" and time.monotonic() >= self._scroll_until:
            color = base.WARNING if self.running else (base.ACCENT if self.recording else base.MUTED)
            if self._rare_flash_remaining > 0 and self.ui_animations_var.get():
                color = base.CYAN
                self._rare_flash_remaining = max(0, self._rare_flash_remaining - 1)
            configure_changed(self.header_live_dot, text_color=color)
        self.after(400, self.animation_tick)

    def _add_personal_photo(self):
        base = self.ui_base
        # Decode the bundled asset once. CTk caches each DPI size.
        with Image.open(Path(__file__).parent / "assets" / "profile.jpg") as source:
            photo = source.convert("RGB")
        self._personal_photo = ctk.CTkImage(light_image=photo, dark_image=photo, size=(72, 96))
        sidebar = self.nav_buttons["Dashboard"].master
        card = ctk.CTkFrame(sidebar, fg_color="#1A1424", border_color="#49305F",
                            border_width=1, corner_radius=14)
        card.pack(side="bottom", fill="x", padx=16, pady=(8, 0))
        ctk.CTkLabel(card, text="", image=self._personal_photo).pack(side="left", padx=(10, 9), pady=10)
        caption = ctk.CTkFrame(card, fg_color="transparent")
        caption.pack(side="left", fill="x", expand=True, padx=(0, 8))
        ctk.CTkLabel(caption, text="AUTO ROLL", text_color="#D8B4FE",
                     font=ctk.CTkFont(size=11, weight="bold")).pack(anchor="w")
        ctk.CTkLabel(caption, text="Your setup", text_color=base.MUTED,
                     font=ctk.CTkFont(size=11)).pack(anchor="w")

    def _update_current_copy(self):
        for page in (self.pages.get("Sequence"), self.pages.get("Updates")):
            if page is None:
                continue
            stack = list(page.winfo_children())
            while stack:
                widget = stack.pop()
                stack.extend(widget.winfo_children())
                if isinstance(widget, ctk.CTkLabel):
                    text = widget.cget("text")
                    if text == "v17.1.3  STABLE":
                        widget.configure(text="v17.2.0  BETA")
                    elif str(text).startswith("Stable: v17.1.3"):
                        widget.configure(text="Installed: v17.2.0 Beta   •   Stable / Beta / Alpha")
