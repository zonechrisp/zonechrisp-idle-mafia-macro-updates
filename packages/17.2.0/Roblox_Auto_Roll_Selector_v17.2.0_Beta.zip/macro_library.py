"""Named slots and reusable mouse/keyboard macros for the desktop application.

Integrate as ``class V172App(MacroLibraryMixin, V1713App)`` and set
``macro_library_root = ROOT`` on that class. The pure storage helpers can be
tested without constructing a Tk window or importing the legacy app.
"""

import copy
import hashlib
import json
import math
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import customtkinter as ctk
import tkinter as tk
from tkinter import filedialog, messagebox


FORMAT = "roblox-auto-roll-macro"
MAX_FILE_BYTES = 32 * 1024 * 1024
MAX_EVENTS = 500_000
TEXT = "#F4F7FB"
MUTED = "#8F9BAD"
ACCENT = "#8B5CF6"
PANEL = "#10151D"
BORDER = "#2A3545"


def atomic_write_json(path, value):
    """Commit a complete JSON file; serialization/write failures keep the old file."""
    path = Path(path)
    payload = json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", newline="\n",
                                         dir=path.parent, prefix=".macro-", suffix=".tmp",
                                         delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        temporary = None
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def validate_name(value, allow_empty=False):
    if not isinstance(value, str):
        raise ValueError("The name must be text.")
    value = value.strip()
    if not value and not allow_empty:
        raise ValueError("Enter a name for this macro.")
    if len(value) > 64:
        raise ValueError("Keep names to 64 characters or fewer.")
    if any(ord(ch) < 32 or ord(ch) == 127 for ch in value):
        raise ValueError("Names cannot contain line breaks or control characters.")
    return value


def _number(value, label, minimum=None, integer=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{label} must be a number.")
    try:
        finite = math.isfinite(value)
    except OverflowError:
        finite = False
    if not finite or (minimum is not None and value < minimum):
        raise ValueError(f"{label} is outside the supported range.")
    if integer and int(value) != value:
        raise ValueError(f"{label} must be a whole number.")
    return value


def validate_macro(value):
    """Validate supported input events without altering coordinates or timing.

    Accept raw v14-v17 macro files and this module's portable library wrapper.
    Retain all optional/unknown JSON metadata, including the recorded screen.
    """
    if not isinstance(value, dict):
        raise ValueError("Choose a macro JSON file containing an events list.")
    if "format" in value and value.get("format") == FORMAT:
        if value.get("version") != 1:
            raise ValueError("This macro-library file uses an unsupported version.")
        value = value.get("macro")
    if not isinstance(value, dict) or not isinstance(value.get("events"), list):
        raise ValueError("This file does not contain a recorded macro.")
    events = value["events"]
    if not events:
        raise ValueError("The macro has no recorded events.")
    if len(events) > MAX_EVENTS:
        raise ValueError(f"The macro exceeds the {MAX_EVENTS:,}-event import limit.")
    previous = 0.0
    for i, event in enumerate(events, 1):
        prefix = f"Event {i}"
        if not isinstance(event, dict):
            raise ValueError(f"{prefix} must be an object.")
        timestamp = _number(event.get("t"), f"{prefix} time", minimum=0)
        if timestamp < previous:
            raise ValueError(f"{prefix} is out of time order.")
        previous = timestamp
        kind = event.get("type")
        if not isinstance(kind, str) or kind not in {"move", "button", "scroll", "key"}:
            raise ValueError(f"{prefix} has an unsupported event type.")
        if kind != "key":
            for axis in ("x", "y"):
                coordinate = _number(event.get(axis), f"{prefix} {axis}", integer=True)
                if abs(coordinate) > 2_147_483_647:
                    raise ValueError(f"{prefix} coordinate is outside the supported range.")
        if kind in {"key", "button"} and not isinstance(event.get("pressed"), bool):
            raise ValueError(f"{prefix} pressed must be true or false.")
        if kind == "button" and (not isinstance(event.get("button"), str) or event.get("button") not in {
                "left", "right", "middle", "x1", "x2", "button4", "button5", "button8", "button9"}):
            raise ValueError(f"{prefix} has an unsupported mouse button.")
        if kind == "scroll":
            for direction in ("dx", "dy"):
                amount = _number(event.get(direction), f"{prefix} {direction}", integer=True)
                if abs(amount) > 2_147_483_647:
                    raise ValueError(f"{prefix} scroll amount is outside the supported range.")
        if kind == "key":
            key = event.get("key")
            if not isinstance(key, str) or not key.strip() or len(key) > 128:
                raise ValueError(f"{prefix} has an invalid keyboard key.")
    duration = _number(value.get("duration", previous), "Macro duration", minimum=0)
    if duration + 1e-9 < previous:
        raise ValueError("The macro duration ends before its last event.")
    screen = value.get("screen")
    if screen is not None:
        if not isinstance(screen, dict):
            raise ValueError("Recorded screen information must be an object.")
        for key in ("x", "y", "width", "height"):
            _number(screen.get(key), f"Screen {key}",
                    minimum=1 if key in {"width", "height"} else None, integer=True)
    try:
        # Reject NaN/Infinity even in optional metadata, and detach input objects.
        return json.loads(json.dumps(value, ensure_ascii=False, allow_nan=False))
    except (TypeError, ValueError, OverflowError, RecursionError) as exc:
        raise ValueError("The macro contains unsupported JSON data.") from exc


def read_macro_file(path):
    path = Path(path)
    with path.open("rb") as stream:
        raw = stream.read(MAX_FILE_BYTES + 1)
    if len(raw) > MAX_FILE_BYTES:
        raise ValueError("Macro files must be 32 MB or smaller.")
    try:
        return json.loads(raw.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError, RecursionError) as exc:
        raise ValueError("The selected file is not valid UTF-8 JSON.") from exc


def macro_document(name, macro):
    return {"format": FORMAT, "version": 1, "name": validate_name(name),
            "saved_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "macro": validate_macro(macro)}


class MacroLibrary:
    def __init__(self, directory):
        self.directory = Path(directory)

    def path_for_name(self, name):
        name = validate_name(name)
        # Names are display text, never a filesystem path; also handles Windows names.
        digest = hashlib.sha256(name.casefold().encode("utf-8")).hexdigest()[:24]
        return self.directory / f"{digest}.json"

    def save(self, name, macro):
        document = macro_document(name, macro)
        path = self.path_for_name(document["name"])
        atomic_write_json(path, document)
        return path

    def entries(self):
        entries, skipped = [], 0
        if not self.directory.exists():
            return entries, skipped
        for path in self.directory.glob("*.json"):
            try:
                document = read_macro_file(path)
                if not isinstance(document, dict) or document.get("format") != FORMAT:
                    raise ValueError("Not a library macro")
                name = validate_name(document.get("name"))
                # Full validation runs when loading; listing avoids scanning all events.
                macro = document.get("macro")
                if document.get("version") != 1 or not isinstance(macro, dict) or not isinstance(macro.get("events"), list):
                    raise ValueError("Invalid library macro")
                duration = _number(macro.get("duration", 0), "Duration", minimum=0)
                entries.append({"name": name, "path": path,
                                "duration": duration, "events": len(macro["events"])})
            except (OSError, ValueError, TypeError):
                skipped += 1
        entries.sort(key=lambda entry: entry["name"].casefold())
        return entries, skipped


class MacroLibraryMixin:
    macro_library_root = None

    def __init__(self, *args, **kwargs):
        if self.macro_library_root is None:
            raise RuntimeError("Set macro_library_root = ROOT on the application class.")
        self._library_data_dir = Path(self.macro_library_root) / "data"
        self._macro_library = MacroLibrary(self._library_data_dir / "macro_library")
        self._library_widgets = []
        self._library_dialog = None
        self._library_controls_state = None
        super().__init__(*args, **kwargs)
        self._refresh_library_controls()

    def _save_sequence_meta(self):
        atomic_write_json(self._library_data_dir / "sequence_slots.json", self._sequence_meta)

    def _save_slot_macro(self, index, macro):
        atomic_write_json(self._library_data_dir / f"sequence_macro_{index + 1}.json", macro)
        self._slot_macros[index] = macro

    def _save_popup_macro(self, index, macro):
        atomic_write_json(self._library_data_dir / f"popup_action_macro_{index + 1}.json", macro)
        while len(self._popup_macros) <= index:
            self._popup_macros.append(None)
        self._popup_macros[index] = macro

    def save_macro(self, macro):
        if getattr(self, "_record_popup_slot", None) is not None or getattr(self, "_record_target_slot", None) is not None:
            return super().save_macro(macro)
        atomic_write_json(self._library_data_dir / "mouse_macro.json", macro)
        self.macro = macro

    def slot_display_name(self, index):
        name = self._sequence_meta["slots"][index].get("name", "")
        return f"Slot {index + 1} · {name}" if name else f"Slot {index + 1}"

    def _library_busy(self):
        return bool(getattr(self, "running", False) or getattr(self, "recording", False))

    def _require_library_idle(self):
        if self._library_busy():
            raise RuntimeError("Stop playback or recording before changing names or macros.")

    def _library_button(self, parent, text, command, width=112):
        button = ctk.CTkButton(parent, text=text, command=command, width=width, height=30,
                               corner_radius=8, fg_color="#202A38", hover_color="#2B3747")
        self._library_widgets.append(button)
        return button

    def build_macro_page(self):
        super().build_macro_page()
        page = self.pages.get("Macro")
        if page is None:
            return
        card = ctk.CTkFrame(page, fg_color=PANEL, corner_radius=14, border_width=1, border_color=BORDER)
        children = page.winfo_children()
        placement = {"fill": "x", "pady": (0, 14)}
        if len(children) > 2:
            placement["before"] = children[2]
        card.pack(**placement)
        ctk.CTkLabel(card, text="Your macro library", text_color=TEXT,
                     font=ctk.CTkFont(size=16, weight="bold")).pack(anchor="w", padx=20, pady=(14, 2))
        ctk.CTkLabel(card, text="Save named recordings, reuse them in any slot, or import and export JSON files.",
                     text_color=MUTED, wraplength=760, justify="left").pack(anchor="w", padx=20, pady=(0, 10))
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x", padx=20, pady=(0, 14))
        self._library_button(row, "Save Macro", lambda: self.open_macro_library("save"), 124).pack(side="left")
        self._library_button(row, "Load Macro", lambda: self.open_macro_library("load"), 124).pack(side="left", padx=8)

    def build_sequence_page(self):
        super().build_sequence_page()
        for index, ui in enumerate(self._seq_ui):
            card = ui["record"].master.master
            header = card.winfo_children()[0]
            name = str(self._sequence_meta["slots"][index].get("name", ""))
            var = tk.StringVar(master=self, value=name)
            ctk.CTkLabel(header, text="Name", text_color=MUTED).pack(side="left", padx=(18, 7))
            entry = ctk.CTkEntry(header, textvariable=var, width=240, height=30,
                                 placeholder_text="e.g. Lucky roll", fg_color="#161D28", border_color=BORDER)
            entry.pack(side="left")
            entry.bind("<Return>", lambda _event, n=index: self.save_slot_name(n))
            entry.bind("<FocusOut>", lambda _event, n=index: self.save_slot_name(n, quiet=True))
            self._library_widgets.append(entry)
            self._library_button(header, "Save name", lambda n=index: self.save_slot_name(n), 88).pack(side="left", padx=8)
            ui.update({"name_var": var, "name_entry": entry, "saved_name": name})
            row = ctk.CTkFrame(card, fg_color="transparent")
            row.pack(fill="x", padx=18, pady=(0, 12), before=ui["record"].master)
            self._library_button(row, "Save Macro", lambda n=index: self.open_macro_library("save", "slot", n)).pack(side="left")
            self._library_button(row, "Load Macro", lambda n=index: self.open_macro_library("load", "slot", n)).pack(side="left", padx=8)
            ctk.CTkLabel(row, text="Keep reusable recordings in your library", text_color=MUTED,
                         font=ctk.CTkFont(size=11)).pack(side="left", padx=5)

    def _augment_sequence_popup_ui(self):
        super()._augment_sequence_popup_ui()
        for index, ui in enumerate(self._seq_ui):
            if "popup_status" not in ui:
                continue
            card = ui["record"].master.master
            row = ctk.CTkFrame(card, fg_color="transparent")
            row.pack(fill="x", padx=22, pady=(0, 12), before=ui["popup_status"])
            self._library_button(row, "Save popup macro", lambda n=index: self.open_macro_library("save", "popup", n), 140).pack(side="left")
            self._library_button(row, "Load popup macro", lambda n=index: self.open_macro_library("load", "popup", n), 140).pack(side="left", padx=8)

    def build_help_page(self):
        super().build_help_page()
        page = self.pages.get("Help")
        if page is None:
            return
        children = page.winfo_children()
        card = ctk.CTkFrame(page, fg_color="#120D1D", corner_radius=14,
                            border_width=1, border_color="#3A2B52")
        placement = {"fill": "x", "pady": (0, 12)}
        if len(children) > 2:
            placement["before"] = children[2]
        card.pack(**placement)
        ctk.CTkLabel(card, text="Slot names & your macro library", text_color=TEXT,
                     font=ctk.CTkFont(size=16, weight="bold")).pack(anchor="w", padx=18, pady=(15, 6))
        text = (
            "Name a slot: type a name beside its slot number, then press Enter or Save name. "
            "Names also save when you leave the field, and return when you reopen the app.\n\n"
            "Save Macro: choose a name and Save to Library to keep a reusable copy. "
            "Load Macro: choose a saved recording and Load Selected. The same library works "
            "in Recorder, every Sequence slot and the separate popup macro controls.\n\n"
            "Use Export JSON to back up or share a recording, and Import JSON to load one "
            "from a file. Existing raw macro JSON files are supported. To add an imported "
            "recording to your library, load it first, then choose Save Macro.\n\n"
            "Loading keeps the recording's exact timing and screen coordinates. Slot names, "
            "target images and detection areas remain attached to their slot. Keep the game "
            "and monitor layout aligned with the recording, then check the slot's target area "
            "and Enabled switch. Stop playback or recording before changing names or macros."
        )
        ctk.CTkLabel(card, text=text, text_color=MUTED, wraplength=900,
                     justify="left").pack(anchor="w", padx=18, pady=(0, 16))

    def save_slot_name(self, index, quiet=False):
        ui = self._seq_ui[index]
        raw = ui["name_var"].get()
        if raw == ui.get("saved_name", ""):
            return True
        try:
            self._require_library_idle()
            name = validate_name(raw, allow_empty=True)
            updated = copy.deepcopy(self._sequence_meta)
            updated["slots"][index]["name"] = name
            atomic_write_json(self._library_data_dir / "sequence_slots.json", updated)
            self._sequence_meta = updated
            ui["saved_name"] = name
            ui["name_var"].set(name)
            self._refresh_sequence_ui()
            self.set_status(f"{self.slot_display_name(index)} saved.", "idle")
            return True
        except (OSError, ValueError, RuntimeError) as exc:
            ui["name_var"].set(ui.get("saved_name", ""))
            if not quiet or not self._library_busy():
                messagebox.showerror("Slot name", str(exc), parent=self)
            return False

    def _refresh_sequence_ui(self):
        super()._refresh_sequence_ui()
        for index, ui in enumerate(getattr(self, "_seq_ui", [])):
            if "name_var" not in ui:
                continue
            saved = str(self._sequence_meta["slots"][index].get("name", ""))
            if ui.get("saved_name") != saved:
                ui["saved_name"] = saved
                ui["name_var"].set(saved)
        self._refresh_library_controls()

    def _refresh_library_controls(self, busy=None):
        state = "disabled" if (self._library_busy() if busy is None else busy) else "normal"
        if state == self._library_controls_state:
            return
        self._library_controls_state = state
        for widget in self._library_widgets:
            if widget.winfo_exists():
                widget.configure(state=state)

    def set_running_buttons(self, running):
        super().set_running_buttons(running)
        self._refresh_library_controls(bool(running) or bool(getattr(self, "recording", False)))

    def _set_sequence_controls_recording(self, recording):
        super()._set_sequence_controls_recording(recording)
        self._refresh_library_controls(bool(recording) or bool(getattr(self, "running", False)))

    def start_recording(self):
        result = super().start_recording()
        self._refresh_library_controls()
        return result

    def _record_success_ui(self):
        result = super()._record_success_ui()
        self._refresh_library_controls(bool(getattr(self, "running", False)))
        return result

    def _record_error_ui(self, error):
        result = super()._record_error_ui(error)
        self._refresh_library_controls(bool(getattr(self, "running", False)))
        return result

    def _library_target(self, kind, index):
        if kind == "main":
            return self.macro, "Recorder"
        if kind not in {"slot", "popup"} or not isinstance(index, int) or not 0 <= index < len(self._slot_macros):
            raise ValueError("Choose a valid macro destination.")
        if kind == "slot":
            return self._slot_macros[index], self.slot_display_name(index)
        return self._popup_macros[index] if index < len(self._popup_macros) else None, self.slot_display_name(index) + " popup"

    def _apply_library_macro(self, kind, index, value):
        self._require_library_idle()
        self._library_target(kind, index)
        macro = validate_macro(value)
        # Validate and commit disk before changing any in-memory state. Detection
        # areas, target images, slot names, and engine settings stay associated
        # with their destination; recorded screen metadata travels with the macro.
        if kind == "main":
            atomic_write_json(self._library_data_dir / "mouse_macro.json", macro)
            self.macro = macro
            self.refresh_macro_stats()
            if hasattr(self, "record_status_var"):
                self.record_status_var.set(f"LOADED · {len(macro['events']):,} events")
        elif kind == "slot":
            self._save_slot_macro(index, macro)
            self._refresh_sequence_ui()
        else:
            self._save_popup_macro(index, macro)
            if hasattr(self, "_v1712_popup_context_cache"):
                with self._v1712_popup_cache_lock:
                    self._v1712_popup_context_cache.pop(index, None)
            self._refresh_sequence_ui()
        return macro

    def open_macro_library(self, mode="load", kind="main", index=None):
        try:
            self._require_library_idle()
            current, target = self._library_target(kind, index)
            if mode == "save" and not current:
                messagebox.showinfo("Save Macro", "Record or load a macro here before saving it to your library.", parent=self)
                return
            if self._library_dialog is not None and self._library_dialog.winfo_exists():
                self._library_dialog.lift()
                return
            self._build_macro_library_dialog(mode, kind, index, current, target)
        except (OSError, ValueError, RuntimeError) as exc:
            messagebox.showerror("Macro library", str(exc), parent=self)

    def _build_macro_library_dialog(self, mode, kind, index, current, target):
        dialog = ctk.CTkToplevel(self)
        self._library_dialog = dialog
        dialog.title(f"{'Save' if mode == 'save' else 'Load'} Macro · {target}")
        dialog.geometry("600x410")
        dialog.resizable(False, False)
        dialog.transient(self)
        dialog.configure(fg_color="#080B10")
        dialog.after(30, dialog.lift)
        title = "Save a reusable macro" if mode == "save" else "Load a saved macro"
        ctk.CTkLabel(dialog, text=title, font=ctk.CTkFont(size=22, weight="bold"), text_color=TEXT).pack(anchor="w", padx=26, pady=(24, 4))
        ctk.CTkLabel(dialog, text=f"Destination: {target}", text_color="#C084FC",
                     wraplength=540, justify="left").pack(anchor="w", padx=26)
        ctk.CTkLabel(dialog, text="Recordings keep their original coordinates, timing and display layout.",
                     text_color=MUTED, wraplength=540, justify="left").pack(anchor="w", padx=26, pady=(4, 16))
        feedback = tk.StringVar(master=dialog, value="")

        def report(action):
            try:
                self._require_library_idle()
                action()
            except (OSError, ValueError, TypeError, RuntimeError) as exc:
                feedback.set(str(exc))

        def success(message):
            self.set_status(message, "idle")
            self.log_activity(message, "info")
            dialog.destroy()

        if mode == "save":
            suggested = (self._sequence_meta["slots"][index].get("name") if index is not None else None) or target
            if kind == "popup" and not suggested.endswith(" popup"):
                suggested += " popup"
            name_var = tk.StringVar(master=dialog, value=suggested[:64])
            ctk.CTkLabel(dialog, text="Macro name", text_color=MUTED).pack(anchor="w", padx=26)
            entry = ctk.CTkEntry(dialog, textvariable=name_var, height=38, fg_color="#161D28", border_color=BORDER)
            entry.pack(fill="x", padx=26, pady=(3, 16))
            row = ctk.CTkFrame(dialog, fg_color="transparent")
            row.pack(fill="x", padx=26)

            def save_local():
                name = validate_name(name_var.get())
                path = self._macro_library.path_for_name(name)
                if path.exists() and not messagebox.askyesno("Replace saved macro", f'Replace the library macro "{name}"?', parent=dialog):
                    return
                self._require_library_idle()
                self._macro_library.save(name, current)
                success(f'Macro "{name}" saved to your library.')

            def export_file():
                name = validate_name(name_var.get())
                document = macro_document(name, current)
                filename = "".join(ch for ch in name if ch.isalnum() or ch in " -_").strip() or "macro"
                path = filedialog.asksaveasfilename(parent=dialog, title="Export Macro", defaultextension=".json",
                                                   initialfile=filename + ".json", filetypes=[("Macro JSON", "*.json")])
                if path:
                    self._require_library_idle()
                    atomic_write_json(path, document)
                    success(f'Macro "{name}" exported.')

            ctk.CTkButton(row, text="Save to Library", command=lambda: report(save_local), fg_color=ACCENT,
                           hover_color="#7C3AED", width=160, height=36).pack(side="left")
            ctk.CTkButton(row, text="Export JSON…", command=lambda: report(export_file), fg_color="#202A38",
                           hover_color="#2B3747", width=150, height=36).pack(side="left", padx=10)
            entry.bind("<Return>", lambda _event: report(save_local))
            dialog.after(50, entry.focus_set)
        else:
            entries, skipped = self._macro_library.entries()
            labels = [f"{entry['name']}  ·  {entry['duration']:.2f}s  ·  {entry['events']:,} events" for entry in entries]
            selection = tk.StringVar(master=dialog, value=labels[0] if labels else "Your library is empty")
            ctk.CTkLabel(dialog, text="Saved macros", text_color=MUTED).pack(anchor="w", padx=26)
            picker = ctk.CTkOptionMenu(dialog, values=labels or ["Your library is empty"], variable=selection,
                                      height=38, fg_color="#202A38", button_color=ACCENT, button_hover_color="#7C3AED",
                                      dynamic_resizing=False, state="normal" if entries else "disabled")
            picker.pack(fill="x", padx=26, pady=(3, 16))
            if skipped:
                feedback.set(f"Skipped {skipped} unreadable library file(s). Import a valid JSON file to continue.")
            elif not entries:
                feedback.set("Save a recording to build your library, or import an existing macro JSON file.")
            row = ctk.CTkFrame(dialog, fg_color="transparent")
            row.pack(fill="x", padx=26)

            def load_value(value, label):
                self._apply_library_macro(kind, index, value)
                success(f'Loaded "{label}" into {target}.')

            def load_local():
                if not entries or selection.get() not in labels:
                    raise ValueError("Choose a saved macro first.")
                selected = entries[labels.index(selection.get())]
                load_value(read_macro_file(selected["path"]), selected["name"])

            def import_file():
                path = filedialog.askopenfilename(parent=dialog, title=f"Import Macro into {target}",
                                                  filetypes=[("Macro JSON", "*.json"), ("All files", "*.*")])
                if path:
                    load_value(read_macro_file(path), Path(path).stem)

            ctk.CTkButton(row, text="Load Selected", command=lambda: report(load_local), fg_color=ACCENT,
                           hover_color="#7C3AED", width=160, height=36, state="normal" if entries else "disabled").pack(side="left")
            ctk.CTkButton(row, text="Import JSON…", command=lambda: report(import_file), fg_color="#202A38",
                           hover_color="#2B3747", width=150, height=36).pack(side="left", padx=10)
        ctk.CTkLabel(dialog, textvariable=feedback, text_color="#FFCA5C", wraplength=540,
                     justify="left").pack(anchor="w", padx=26, pady=(14, 4))
        ctk.CTkButton(dialog, text="Cancel", command=dialog.destroy, width=90, height=30,
                       fg_color="#202A38", hover_color="#2B3747").pack(side="bottom", anchor="e", padx=26, pady=20)
        dialog.grab_set()
