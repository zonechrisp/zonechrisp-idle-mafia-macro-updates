Roblox Auto Roll Selector v17.2.0 BETA

Update through the app: Updates > Beta > Check Now > v17.2.0 > Install.
This update requires the existing v14.0.0 compatibility base, as v17.1.3 did.

What's new
- Replaced canvas pixel scrolling with a stationary clipped viewport and bounded
  wheel/scrollbar updates to address repeated-button trails and stale page areas.
- Sequence now has a compact 10-slot selector. Choose one slot to edit its
  controls; all enabled slots still participate in the automation sequence.
- Reduced repeated status redraws, cached macro statistics and reused update
  history cards. Each page keeps its scroll position.
- Added the supplied photo as a small purple-accented sidebar card.
- Added saved slot names. Enter a name and press Enter, leave the field or
  click Save name. Names appear in the slot selector and macro dialogs.
- Added Save Macro / Load Macro in Recorder and each slot. Popup recovery
  recordings can also be saved and loaded separately.
- Save to Library keeps named recordings under data/macro_library. Load Selected
  reuses them in the chosen destination. Export JSON and Import JSON transfer
  recordings between installations. Existing raw macro JSON files are supported.
- Loading preserves recorded timing, keys, mouse coordinates and screen metadata.
  The destination keeps its target image, detection area and popup configuration.
- Naming and macro replacement are disabled during playback/recording. Invalid
  files are rejected before replacing an existing macro. Saves are atomic.

Existing data stays in the installation's shared data folder. This package does
not contain or replace your saved configuration, personal macros or slot setup.
The current Stable release remains v17.1.3; this release is on Beta.

Validation
- Python compilation and ZIP integrity.
- 18 storage/import/validation tests, including all ten slot destinations,
  popup destinations, disk-write failures, malformed files and busy guards.
- Accepted all 13 existing macro files from this installation.
- Real Tk checks for nested-button wheel routing, stationary canvas, boundaries,
  preserved page position, all ten slot editors, unchanged idle status writes,
  and update-card cache invalidation.
- The app's automation engine was not run against Roblox during these UI tests.
