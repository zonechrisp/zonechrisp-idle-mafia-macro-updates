import importlib.util
import base64
import hashlib
import json
import os
import shutil
import tarfile
import tempfile
import urllib.request
from pathlib import Path, PurePosixPath

THIS_DIR = Path(__file__).resolve().parent
ROOT = Path(os.environ.get("IDLE_MAFIA_ROOT", str(THIS_DIR.parent.parent))).resolve()
BASE_FILE = ROOT / "versions" / "14.0.0" / "update_center.py"

if not BASE_FILE.exists():
    raise RuntimeError("The v14.0.0 Update Center compatibility base is missing.")

spec = importlib.util.spec_from_file_location("roblox_auto_roll_update_center_base", BASE_FILE)
_base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(_base)

_base.BG = "#09070E"
_base.SURFACE = "#12101A"
_base.SURFACE_2 = "#1A1624"
_base.SURFACE_3 = "#261F33"
_base.BORDER = "#3A2E4B"
_base.TEXT = "#F7F3FF"
_base.MUTED = "#A59AAF"
_base.ACCENT = "#8B5CF6"
_base.ACCENT_HOVER = "#7C3AED"
_base.SUCCESS = "#55D6A9"
_base.WARNING = "#F4C86A"
_base.CYAN = "#C084FC"
_base.PINK = "#D946EF"

ctk = _base.ctk


def _walk(widget):
    yield widget
    try:
        for child in widget.winfo_children():
            yield from _walk(child)
    except Exception:
        return


class UpdateController(_base.UpdateController):
    """v17.1.3 Update Center with Stable/Beta/Alpha channel support.

    Alpha is an archive channel for pre-v14 builds. Those builds predate Update Center,
    so they are installed and launched as one-time legacy sessions without changing the
    selected Stable version. Reopening RUN_APP.bat returns to Stable automatically.
    """

    def __init__(self, *args, **kwargs):
        self._legacy_install_no_select = False
        super().__init__(*args, **kwargs)

    def build_page(self):
        super().build_page()
        # v14 hard-coded Stable/Beta. Add Alpha without forking the whole page layout.
        try:
            for widget in _walk(self.page):
                if isinstance(widget, ctk.CTkOptionMenu):
                    widget.configure(values=["stable", "beta", "alpha"])
        except Exception:
            pass

    @staticmethod
    def _visible_on_channel(release, channel):
        rc = str(release.get("channel", "stable")).lower()
        channel = str(channel or "stable").lower()
        if channel == "alpha":
            return rc == "alpha"
        if channel == "beta":
            # Preserve the updater's established behavior: Beta also sees Stable.
            return rc in {"stable", "beta"}
        return rc == "stable"

    def _latest_for_channel(self):
        if not self.manifest:
            return None
        channel = str(self.app.cfg.get("update_channel", "stable")).lower()
        candidates = [r for r in self.manifest.get("versions", []) if self._visible_on_channel(r, channel)]
        if not candidates:
            return None
        return max(candidates, key=lambda r: _base.version_key(r.get("version")))

    def _render_releases(self):
        if not self.release_list or not self.manifest:
            return
        channel = str(self.channel_var.get() if self.channel_var else self.app.cfg.get("update_channel", "stable")).lower()
        signature = (
            channel, self.app_version, json.dumps(self.manifest, sort_keys=True),
            tuple((str(r.get("version", "0")), (self.versions_dir / str(r.get("version", "0")) / "main.py").exists())
                  for r in self.manifest.get("versions", [])),
        )
        if signature == getattr(self, "_release_render_signature", None) and self.release_list.winfo_children():
            return
        for child in self.release_list.winfo_children():
            child.destroy()
        channel = str(self.channel_var.get() if self.channel_var else self.app.cfg.get("update_channel", "stable")).lower()
        releases = [r for r in (self.manifest.get("versions") or []) if self._visible_on_channel(r, channel)]
        releases.sort(key=lambda r: _base.version_key(r.get("version")), reverse=True)
        if not releases:
            self._render_placeholder("No releases are published for this channel yet.")
            return
        if channel == "alpha":
            info = ctk.CTkFrame(self.release_list, fg_color="#171022", corner_radius=14,
                                border_width=1, border_color="#5B3C79")
            info.pack(fill="x", pady=(0, 8))
            ctk.CTkLabel(info, text="ALPHA LEGACY ARCHIVE", text_color="#D8B4FE",
                         font=ctk.CTkFont(size=11, weight="bold")).pack(anchor="w", padx=18, pady=(14, 2))
            ctk.CTkLabel(info, text="v1–v13 predate Update Center. INSTALL & OPEN starts the selected build once; Stable remains selected, so reopening RUN_APP.bat returns to the modern app.",
                         text_color=_base.MUTED, wraplength=850, justify="left").pack(anchor="w", padx=18, pady=(0, 14))

        for rel in releases:
            ver = str(rel.get("version", "0"))
            current = _base.version_key(ver) == _base.version_key(self.app_version)
            installed = (self.versions_dir / ver / "main.py").exists()
            legacy = bool(rel.get("legacy_archive", False) or str(rel.get("channel", "")).lower() == "alpha")
            card = ctk.CTkFrame(self.release_list, fg_color=_base.SURFACE, corner_radius=14,
                                border_width=1, border_color=_base.ACCENT if current else _base.BORDER)
            card.pack(fill="x", pady=6)
            card.grid_columnconfigure(0, weight=1)
            title_row = ctk.CTkFrame(card, fg_color="transparent")
            title_row.grid(row=0, column=0, sticky="ew", padx=18, pady=(14, 2))
            ctk.CTkLabel(title_row, text=_base.pretty_version(ver), text_color=_base.TEXT,
                         font=ctk.CTkFont(size=16, weight="bold")).pack(side="left")
            title = str(rel.get("title", "")).strip()
            if title:
                ctk.CTkLabel(title_row, text=f"  {title}", text_color="#D8B4FE" if legacy else _base.CYAN,
                             font=ctk.CTkFont(size=12, weight="bold")).pack(side="left")
            if current:
                ctk.CTkLabel(title_row, text="CURRENT", fg_color="#203C36", text_color=_base.SUCCESS,
                             corner_radius=8, height=24, font=ctk.CTkFont(size=9, weight="bold")).pack(side="left", padx=9)
            elif installed:
                ctk.CTkLabel(title_row, text="INSTALLED", fg_color=_base.SURFACE_3, text_color=_base.CYAN,
                             corner_radius=8, height=24, font=ctk.CTkFont(size=9, weight="bold")).pack(side="left", padx=9)
            channel_text = str(rel.get("channel", "stable")).upper()
            ctk.CTkLabel(title_row, text=f"{channel_text}  •  {rel.get('released','')}", text_color=_base.MUTED,
                         font=ctk.CTkFont(size=10)).pack(side="left", padx=6)
            notes = rel.get("notes") or []
            note_text = "\n".join(f"• {n}" for n in notes[:8]) or "No changelog notes."
            ctk.CTkLabel(card, text=note_text, text_color=_base.MUTED, justify="left", wraplength=760).grid(
                row=1, column=0, sticky="w", padx=18, pady=(4, 15))
            action = ctk.CTkFrame(card, fg_color="transparent")
            action.grid(row=0, column=1, rowspan=2, sticky="e", padx=18, pady=14)
            if current:
                ctk.CTkButton(action, text="CURRENT", width=128, state="disabled", fg_color=_base.SURFACE_3).pack()
            elif legacy:
                label = "OPEN LEGACY" if installed else "INSTALL & OPEN"
                ctk.CTkButton(action, text=label, width=128, fg_color="#6D28D9",
                              hover_color="#7C3AED", command=lambda r=rel: self.install_release(r)).pack()
            elif installed:
                ctk.CTkButton(action, text="SWITCH TO", width=128, fg_color=_base.SURFACE_3,
                              hover_color="#3B3150", command=lambda r=rel: self.install_release(r)).pack()
            else:
                label = "DOWNGRADE" if _base.version_key(ver) < _base.version_key(self.app_version) else "INSTALL"
                ctk.CTkButton(action, text=label, width=128, fg_color=_base.ACCENT,
                              hover_color=_base.ACCENT_HOVER, command=lambda r=rel: self.install_release(r)).pack()
        self._release_render_signature = signature

    def _render_placeholder(self, text):
        self._release_render_signature = None
        return super()._render_placeholder(text)

    def _set_current_version(self, ver):
        if self._legacy_install_no_select:
            return
        return super()._set_current_version(ver)

    def install_release(self, release):
        if bool(release.get("legacy_archive", False) or str(release.get("channel", "")).lower() == "alpha"):
            return self._install_or_launch_legacy(release)
        return super().install_release(release)

    def _install_or_launch_legacy(self, release):
        if self.installing:
            return
        if getattr(self.app, "running", False) or getattr(self.app, "recording", False):
            _base.messagebox.showwarning("Macro active", "Stop playback/recording before opening a legacy Alpha build.")
            return
        ver = str(release.get("version", ""))
        if not ver:
            return
        existing = self.versions_dir / ver / "main.py"
        if existing.exists():
            return self._launch_legacy(ver)
        if not _base.messagebox.askyesno(
            "Open Alpha legacy build",
            f"{_base.pretty_version(ver)} is a historical pre-v14 Alpha build.\n\n"
            "It predates the modern Update Center and shared-data system. It will be installed and opened once, while your current Stable version stays selected.\n\n"
            "After closing the legacy build, run RUN_APP.bat to return to Stable.\n\nContinue?"
        ):
            return
        self.installing = True
        self._legacy_install_no_select = True
        if self.update_status_var:
            self.update_status_var.set(f"Installing legacy {_base.pretty_version(ver)}…")
        if self.progress:
            self.progress.configure(mode="determinate"); self.progress.set(0)

        def worker():
            try:
                self._download_and_install_legacy_bundle(release)
                self.app.after(0, lambda: self._legacy_install_success(ver))
            except Exception as exc:
                self.app.after(0, lambda err=str(exc): self._legacy_install_error(err))
        _base.threading.Thread(target=worker, daemon=True).start()

    def _download_and_install_legacy_bundle(self, release):
        """Download the shared v1-v13 archive and install only the selected Alpha build."""
        ver = str(release.get("version", ""))
        urls = list(release.get("legacy_bundle_b64_chunks") or self.manifest.get("alpha_legacy_bundle_b64_chunks") or [])
        expected = str(release.get("legacy_bundle_sha256") or self.manifest.get("alpha_legacy_bundle_sha256") or "").lower().strip()
        if not ver or not urls or not expected:
            raise RuntimeError("This Alpha release is missing its legacy bundle or checksum.")

        encoded_parts = []
        total = len(urls)
        for i, url in enumerate(urls):
            if not str(url).startswith("https://"):
                raise RuntimeError("Unsafe Alpha archive URL.")
            req = urllib.request.Request(str(url), headers={
                "User-Agent": "RobloxAutoRollSelector-Updater/1.0",
                "Cache-Control": "no-cache",
            })
            with urllib.request.urlopen(req, timeout=20) as resp:
                encoded_parts.append(resp.read().decode("ascii").strip())
            if self.progress:
                self.app.after(0, lambda f=((i + 1) / total) * 0.72: self.progress.set(f))

        try:
            payload = base64.b64decode("".join(encoded_parts), validate=True)
        except Exception as exc:
            raise RuntimeError(f"Alpha archive could not be decoded: {exc}")
        actual = hashlib.sha256(payload).hexdigest().lower()
        if actual != expected:
            raise RuntimeError("Security check failed. Alpha archive SHA-256 mismatch.")

        archive = self.cache_dir / "alpha_legacy_v1-v13.tar.xz"
        archive.write_bytes(payload)
        temp_parent = Path(tempfile.mkdtemp(prefix=f"alpha_{ver}_", dir=str(self.cache_dir)))
        target = self.versions_dir / ver
        staging = self.versions_dir / f".{ver}.staging"
        try:
            with tarfile.open(archive, "r:xz") as tf:
                prefix = f"{ver}/"
                selected = []
                for member in tf.getmembers():
                    # Reject links/devices and path traversal before extracting anything.
                    if member.issym() or member.islnk() or member.isdev():
                        raise RuntimeError("Unsafe entry found inside Alpha archive.")
                    posix = PurePosixPath(member.name)
                    if posix.is_absolute() or ".." in posix.parts:
                        raise RuntimeError("Unsafe path found inside Alpha archive.")
                    if member.name == ver or member.name.startswith(prefix):
                        selected.append(member)
                if not selected:
                    raise RuntimeError(f"Alpha archive does not contain {ver}.")
                tf.extractall(temp_parent, members=selected)

            candidate = temp_parent / ver
            if not (candidate / "main.py").exists() or not (candidate / "update_center.py").exists():
                raise RuntimeError("Selected Alpha build is incomplete.")
            if staging.exists():
                shutil.rmtree(staging, ignore_errors=True)
            shutil.copytree(candidate, staging)

            # Some dashboard-era legacy builds used sounds that were not bundled in the archive.
            # Reuse the current sounds directory when available; templates stay historical.
            current_dir = self.versions_dir / self.app_version
            sound_src = current_dir / "sounds"
            if sound_src.exists() and not (staging / "sounds").exists():
                shutil.copytree(sound_src, staging / "sounds")

            if target.exists():
                shutil.rmtree(target, ignore_errors=True)
            os.replace(staging, target)
            if self.progress:
                self.app.after(0, lambda: self.progress.set(1))
        finally:
            shutil.rmtree(temp_parent, ignore_errors=True)

    def _legacy_install_success(self, ver):
        self.installing = False
        self._legacy_install_no_select = False
        if self.update_status_var:
            self.update_status_var.set(f"Legacy {_base.pretty_version(ver)} installed. Opening…")
        if self.progress:
            self.progress.set(1)
        self._render_releases()
        self._launch_legacy(ver, confirm=False)

    def _legacy_install_error(self, error):
        self.installing = False
        self._legacy_install_no_select = False
        if self.progress:
            self.progress.set(0)
        if self.update_status_var:
            self.update_status_var.set(f"Legacy install failed: {error}")
        _base.messagebox.showerror("Alpha install failed", error)

    def _launch_legacy(self, ver, confirm=True):
        target = self.versions_dir / ver / "main.py"
        if not target.exists():
            _base.messagebox.showerror("Alpha launch failed", "The legacy build is not installed correctly.")
            return
        if confirm and not _base.messagebox.askyesno(
            "Open Alpha legacy build",
            f"Open {_base.pretty_version(ver)} as a one-time legacy session?\n\n"
            "Stable remains selected. When you close the old build, run RUN_APP.bat to return to Stable."
        ):
            return
        env = _base.os.environ.copy()
        env["IDLE_MAFIA_ROOT"] = str(self.root)
        env["IDLE_MAFIA_VERSION"] = ver
        env["IDLE_MAFIA_LAUNCHER_VERSION"] = "1.0.0"
        try:
            _base.subprocess.Popen([_base.sys.executable, str(target)], cwd=str(target.parent), env=env, close_fds=True)
            self.app.destroy()
        except Exception as exc:
            _base.messagebox.showerror("Alpha launch failed", str(exc))


UpdateDialog = getattr(_base, "UpdateDialog", None)
UpdatePopup = getattr(_base, "UpdatePopup", None)
pretty_version = getattr(_base, "pretty_version", lambda v: str(v))
